<?php
/**
 * Wévica Stock Sync — Funciones auxiliares puras.
 *
 * Parseo de precios, resolución de stock, seguridad (hashing, rate-limiting)
 * y utilidades de logging.  No registra hooks.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ═══════════════════════════════════════════════════════════════════
//  PARSEO DE PRECIOS
// ═══════════════════════════════════════════════════════════════════

/**
 * Parsea un valor de precio a float, detectando automáticamente el separador
 * decimal (europeo o americano) para evitar que "12.50" → 1250.
 *
 * Lógica:
 *  - Si tiene punto Y coma: el último separador es el decimal.
 *  - Si solo tiene punto: si hay exactamente 1 punto y ≤2 dígitos tras él → decimal;
 *    si hay 3 dígitos tras el único punto o múltiples puntos → separador de miles.
 *  - Si solo tiene coma: misma lógica simétrica.
 *
 * @param  string     $raw  Valor crudo del CSV/JSON (p. ej. "12.50", "1.234,56").
 * @return float|false      Precio como float, o false si no es un precio válido.
 */
function wevica_sync_parse_price( $raw ) {
    $raw = trim( preg_replace( '/[^\d.,]/', '', (string) $raw ) );
    if ( $raw === '' ) {
        return false;
    }

    $has_dot   = strpos( $raw, '.' ) !== false;
    $has_comma = strpos( $raw, ',' ) !== false;

    if ( $has_dot && $has_comma ) {
        // El último separador es el decimal: "1.234,56" (EU) o "1,234.56" (US).
        if ( strrpos( $raw, ',' ) > strrpos( $raw, '.' ) ) {
            $raw = str_replace( '.', '', $raw );
            $raw = str_replace( ',', '.', $raw );
        } else {
            $raw = str_replace( ',', '', $raw );
        }
    } elseif ( $has_comma && ! $has_dot ) {
        $parts = explode( ',', $raw );
        if ( count( $parts ) === 2 && strlen( end( $parts ) ) <= 2 ) {
            $raw = str_replace( ',', '.', $raw );
        } else {
            $raw = str_replace( ',', '', $raw );
        }
    } elseif ( $has_dot && ! $has_comma ) {
        $parts = explode( '.', $raw );
        if ( ! ( count( $parts ) === 2 && strlen( end( $parts ) ) <= 2 ) ) {
            $raw = str_replace( '.', '', $raw );
        }
    }

    if ( ! is_numeric( $raw ) ) {
        return false;
    }

    $price = (float) $raw;
    return $price > 0 ? $price : false;
}

// ═══════════════════════════════════════════════════════════════════
//  RESOLUCIÓN DE STOCK
// ═══════════════════════════════════════════════════════════════════

/**
 * Unifica la lógica de mapeo de estados de stock (usada por CSV y JSON).
 *
 * @param  string $stock_value   Valor de stock crudo del CSV/JSON.
 * @param  string $stock_unknown Configuración para valores desconocidos ('skip', 'outofstock', 'instock').
 * @return array { status: string|null, quantity: int|null, skip: bool }
 */
function wevica_sync_resolve_stock_status( $stock_value, $stock_unknown = 'skip' ) {
    $stock_value = strtoupper( trim( (string) $stock_value ) );

    $in_stock_values = [ 'SI', 'PROBABLE_SI', '1', 'EN STOCK', 'INSTOCK', 'IN_STOCK' ];
    $no_stock_values = [ 'NO', '0', 'SIN STOCK', 'OUTOFSTOCK', 'OUT_OF_STOCK' ];
    $unknown_values  = [ 'NO_AUTENTICADO', 'DESCONOCIDO', 'UNKNOWN', 'ERROR_HTTP', 'ERROR_REQUEST', 'NO_EXISTE', 'URL_INVALIDA' ];

    if ( in_array( $stock_value, $in_stock_values, true ) ) {
        return [ 'status' => 'instock', 'quantity' => null, 'skip' => false ];
    }

    if ( in_array( $stock_value, $no_stock_values, true ) ) {
        return [ 'status' => 'outofstock', 'quantity' => 0, 'skip' => false ];
    }

    if ( in_array( $stock_value, $unknown_values, true ) ) {
        if ( $stock_unknown === 'skip' ) {
            return [ 'status' => null, 'quantity' => null, 'skip' => true ];
        }
        return [ 'status' => $stock_unknown, 'quantity' => null, 'skip' => false ];
    }

    if ( is_numeric( $stock_value ) ) {
        $qty = (int) $stock_value;
        return [ 'status' => $qty > 0 ? 'instock' : 'outofstock', 'quantity' => $qty, 'skip' => false ];
    }

    if ( $stock_unknown === 'skip' ) {
        return [ 'status' => null, 'quantity' => null, 'skip' => true ];
    }
    return [ 'status' => $stock_unknown, 'quantity' => null, 'skip' => false ];
}

// ═══════════════════════════════════════════════════════════════════
//  SEGURIDAD — MULTI-API KEY + RATE LIMIT
// ═══════════════════════════════════════════════════════════════════

/**
 * Genera un hash moderno de la API key usando password_hash (bcrypt).
 * Incluye prefijo de versión para permitir migraciones futuras.
 *
 * Formato: {version}${salt}${hash}
 * Versión 2 = bcrypt (PHP >= 5.3.7)
 *
 * @param  string $plain_key Clave en texto plano.
 * @return string            Hash bcrypt con prefijo de versión.
 */
function wevica_sync_hash_key( $plain_key ) {
    if ( function_exists( 'password_hash' ) && defined( 'PASSWORD_BCRYPT' ) ) {
        $hash = password_hash( $plain_key, PASSWORD_BCRYPT );
        return 'v2$' . $hash;
    }

    return 'v1$' . hash_hmac( 'sha256', $plain_key, wp_salt( 'auth' ) );
}

/**
 * Verifica una clave contra un hash almacenado.
 * Soporta tanto el nuevo formato (v2=bcrypt) como el legacy (v1=hmac).
 *
 * @param  string $plain_key Clave en texto plano a verificar.
 * @param  string $stored_hash Hash almacenado.
 * @return bool
 */
function wevica_sync_verify_key_hash( string $plain_key, string $stored_hash ): bool {
    if ( str_starts_with( $stored_hash, 'v2$' ) ) {
        $hash_only = substr( $stored_hash, 3 );
        return password_verify( $plain_key, $hash_only );
    }

    if ( str_starts_with( $stored_hash, 'v1$' ) ) {
        $legacy_hash = substr( $stored_hash, 3 );
        return hash_equals( $legacy_hash, wevica_sync_hash_key_legacy( $plain_key ) );
    }

    return false;
}

/**
 * Hash legacy HMAC-SHA256 para compatibilidad.
 *
 * @param  string $plain_key Clave en texto plano.
 * @return string            Hash hexadecimal.
 */
function wevica_sync_hash_key_legacy( $plain_key ) {
    return hash_hmac( 'sha256', $plain_key, wp_salt( 'auth' ) );
}

/**
 * Devuelve todas las claves API almacenadas.
 * Cada clave es un array: [id, name, hash, created_at, last_used].
 *
 * @return array
 */
function ssp_get_api_keys(): array {
    $keys = get_option( 'ssp_api_keys', [] );
    return is_array( $keys ) ? $keys : [];
}

/**
 * Guarda el array de claves.
 *
 * @param array $keys
 */
function ssp_save_api_keys( array $keys ) {
    update_option( 'ssp_api_keys', $keys );
}

/**
 * Crea una nueva clave API con nombre descriptivo.
 * Si $plain_key no se pasa, se genera automáticamente.
 *
 * @param  string $name      Nombre de la clave.
 * @param  string $plain_key Clave en texto plano (opcional).
 * @return string            La clave en texto plano (mostrar solo una vez).
 */
function ssp_create_api_key( string $name, string $plain_key = '' ): string {
    if ( empty( $plain_key ) ) {
        $plain_key = wp_generate_password( 40, false );
    }
    $keys   = ssp_get_api_keys();
    $keys[] = [
        'id'         => 'key_' . wp_generate_password( 12, false ),
        'name'       => sanitize_text_field( $name ),
        'hash'       => wevica_sync_hash_key( $plain_key ),
        'created_at' => current_time( 'mysql' ),
        'last_used'  => null,
    ];
    ssp_save_api_keys( $keys );
    return $plain_key;
}

/**
 * Revoca (elimina) una clave por ID.
 *
 * @param string $key_id
 */
function ssp_revoke_api_key( string $key_id ) {
    $keys = array_filter( ssp_get_api_keys(), fn( $k ) => $k['id'] !== $key_id );
    ssp_save_api_keys( array_values( $keys ) );
}

/**
 * Devuelve los metadatos de la API key designada para el Sync Engine
 * (la que tiene nombre "Motor de Sincronización"), o null si no existe.
 *
 * @return array|null Array con keys: id, name, created_at, last_used.
 */
function ssp_get_syncengine_api_key_meta(): ?array {
    foreach ( ssp_get_api_keys() as $key ) {
        if ( 'Motor de Sincronización' === ( $key['name'] ?? '' ) ) {
            return $key;
        }
    }
    return null;
}

/**
 * Verifica una clave contra el array multi-clave.
 * Actualiza `last_used` si la clave es válida.
 * También acepta la clave legacy (wevica_sync_api_key_hash) como fallback.
 *
 * @param  string $provided_key Clave recibida en la petición.
 * @return bool
 */
function ssp_verify_api_key( string $provided_key ): bool {
    $current_hash = wevica_sync_hash_key( $provided_key );

    // Usar transient como lock para evitar race condition al actualizar last_used.
    // set_transient devuelve false si ya existe, lo que garantiza exclusión mutua.
    $lock_key = 'ssp_api_key_lock';
    $has_lock = set_transient( $lock_key, 1, 5 );

    $keys = ssp_get_api_keys();

    if ( $has_lock ) {
        // Tenemos el lock: validar y actualizar last_used
        $updated = false;
        foreach ( $keys as &$key ) {
            if ( wevica_sync_verify_key_hash( $provided_key, $key['hash'] ) ) {
                $key['last_used'] = current_time( 'mysql' );
                $updated = true;
                break;
            }
        }
        unset( $key );

        if ( $updated ) {
            ssp_save_api_keys( $keys );
            delete_transient( $lock_key );
            return true;
        }

        delete_transient( $lock_key );
    } else {
        // Otro proceso tiene el lock: solo validar sin actualizar last_used
        foreach ( $keys as $key ) {
            if ( wevica_sync_verify_key_hash( $provided_key, $key['hash'] ) ) {
                return true;
            }
        }
    }

    // Fallback: legacy single-key hash (v3.x).
    $stored_hash = get_option( 'wevica_sync_api_key_hash', '' );
    if ( ! empty( $stored_hash ) && hash_equals( $stored_hash, wevica_sync_hash_key_legacy( $provided_key ) ) ) {
        return true;
    }

    // Fallback: legacy plain-text key (v2.x).
    $legacy_key = get_option( 'wevica_sync_api_key', '' );
    if ( ! empty( $legacy_key ) && hash_equals( $legacy_key, $provided_key ) ) {
        return true;
    }

    return false;
}

/**
 * Backward-compat alias.
 *
 * @param  string $provided_key
 * @return bool
 */
function wevica_sync_verify_key( $provided_key ) {
    return ssp_verify_api_key( $provided_key );
}

/**
 * Rate limiting: máximo 120 peticiones por minuto por IP.
 *
 * @return true|\WP_Error
 */
/**
 * Verifica rate limit por API KEY, no por IP.
 * Esto previene que un usuario legítimo sea atacado por otro.
 *
 * @param string $api_key_hash Hash de la API key validada.
 * @param int $max_requests Máximo de requests por minuto (default 120).
 * @return true|WP_Error
 */
function wevica_sync_check_rate_limit( $api_key_hash = '', $max_requests = 120 ) {
    if ( empty( $api_key_hash ) ) {
        // Fallback: rate limit global por IP si no se proporciona clave
        $ip   = wevica_sync_get_client_ip();
        $limiter = 'wevica_rate_ip_' . md5( $ip );
    } else {
        // Rate limit POR API KEY
        $limiter = 'wevica_rate_key_' . substr( $api_key_hash, 0, 8 );
    }

    $attempts = (int) get_transient( $limiter );

    if ( $attempts >= $max_requests ) {
        wevica_sync_log_auth_failure( 'rate_limit' );
        return new WP_Error(
            'wevica_rate_limit',
            'Demasiadas peticiones desde esta clave API. Intenta de nuevo en 1 minuto.',
            [ 'status' => 429 ]
        );
    }

    set_transient( $limiter, $attempts + 1, 60 );
    return true;
}

/**
 * Devuelve la IP del cliente usando únicamente REMOTE_ADDR (no headers spoofables).
 *
 * @return string
 */
function wevica_sync_get_client_ip() {
    return isset( $_SERVER['REMOTE_ADDR'] )
        ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
        : '0.0.0.0';
}

/**
 * Registra un intento de autenticación fallido en el log.
 *
 * @param string $reason Motivo del fallo ('missing_key', 'invalid_key', 'rate_limit').
 */
function wevica_sync_log_auth_failure( $reason = 'unknown' ) {
    $ip = wevica_sync_get_client_ip();
    wevica_sync_log( '', 'auth_fail', 0, 0, 0, 1, [
        [
            'tipo'    => 'error',
            'sku'     => '—',
            'nombre'  => '',
            'mensaje' => "Auth fallida: {$reason} desde IP {$ip}",
        ],
    ] );
}

// ═══════════════════════════════════════════════════════════════════
//  UTILIDADES DE DETALLES
// ═══════════════════════════════════════════════════════════════════

/**
 * Trunca el array de detalles a $limit entradas e inserta un aviso al final
 * cuando se produce truncado, para que el usuario sepa en la vista de detalle
 * que hay registros omitidos.
 *
 * @param  array $detalles Array de items de detalle.
 * @param  int   $limit    Número máximo de entradas.
 * @return array
 */
function wevica_sync_truncate_detalles( array $detalles, int $limit = 500 ): array {
    if ( count( $detalles ) <= $limit ) {
        return $detalles;
    }
    $exceso    = count( $detalles ) - ( $limit - 1 );
    $truncated = array_slice( $detalles, 0, $limit - 1 );
    $truncated[] = [
        'tipo'    => 'aviso',
        'sku'     => '—',
        'nombre'  => '',
        'mensaje' => "Se omitieron {$exceso} registros adicionales por límite de almacenamiento (máx. " . ( $limit - 1 ) . ").",
    ];
    return $truncated;
}

/**
 * Devuelve la clase CSS de badge según el tipo de sincronización.
 *
 * @param  string $tipo Tipo de sync ('api', 'cron', 'auth_fail', 'manual', 'csv', ...).
 * @return string       Clase CSS del badge.
 */
function wevica_sync_badge_class( $tipo ) {
    $map = [
        'api'       => 'wevica-badge-api',
        'cron'      => 'wevica-badge-cron',
        'auth_fail' => 'wevica-badge-err',
    ];
    return $map[ $tipo ] ?? 'wevica-badge-csv';
}

// ═══════════════════════════════════════════════════════════════════
//  NOTIFICACIONES POR EMAIL
// ═══════════════════════════════════════════════════════════════════

/**
 * Envía una notificación de error al email configurado (o admin_email).
 * Solo se envía si la opción ssp_notify_on_error está activa.
 *
 * @param string $subject Asunto corto del email.
 * @param string $body    Cuerpo del mensaje en texto plano.
 */
function ssp_send_error_notification( string $subject, string $body ): void {
    if ( get_option( 'ssp_notify_on_error', '1' ) !== '1' ) {
        return;
    }
    $to = get_option( 'ssp_notify_email', '' );
    if ( empty( $to ) ) {
        $to = get_option( 'admin_email', '' );
    }
    if ( empty( $to ) ) {
        return;
    }

    $site    = get_bloginfo( 'name' );
    $full_subj = sprintf( '[Stock Sync Pro] [%s] %s', $site, $subject );
    $full_body = sprintf(
        "Sitio:  %s\nFecha:  %s\n\n%s\n\n--\nStock Sync Pro · %s",
        home_url(),
        current_time( 'mysql' ),
        $body,
        admin_url( 'admin.php?page=ssp-status' )
    );

    wp_mail( $to, $full_subj, $full_body );
}

/**
 * Envía un email de recordatorio de trial al administrador del sitio.
 *
 * @param string $to        Dirección de destino.
 * @param int    $days_left Días restantes de trial (1 o 2).
 */
function ssp_send_trial_reminder_email( string $to, int $days_left ): void {
    $site        = get_bloginfo( 'name' );
    $billing_url = admin_url( 'admin.php?page=ssp-billing' );
    $subject     = sprintf(
        /* translators: 1: site name, 2: days remaining */
        _x( '[Stock Sync Pro] Tu trial de %1$s expira en %2$d día(s)', 'email subject', 'stock-sync-pro' ),
        $site,
        $days_left
    );
    $day_text = $days_left === 1
        ? __( '<strong>mañana</strong>', 'stock-sync-pro' )
        : sprintf( __( 'en <strong>%d días</strong>', 'stock-sync-pro' ), $days_left );

    $body = sprintf(
        '<html><body style="font-family:sans-serif;color:#1a202c;max-width:560px;margin:0 auto;padding:24px;">
<h2 style="color:#6366f1;">⏳ %s</h2>
<p>Tu período de prueba de <strong>Stock Sync Pro</strong> en <strong>%s</strong> expira %s.</p>
<p>Cuando expire, las sincronizaciones automáticas se pausarán hasta que actives una suscripción.</p>
<a href="%s" style="display:inline-block;margin:20px 0;padding:12px 28px;background:#6366f1;color:#fff;border-radius:6px;text-decoration:none;font-weight:600;">
  Ver planes y activar licencia
</a>
<p style="font-size:13px;color:#6b7280;">Si ya tienes un plan activo, ignora este mensaje.</p>
<hr style="border:none;border-top:1px solid #e5e7eb;margin:24px 0;">
<p style="font-size:12px;color:#9ca3af;">Stock Sync Pro · <a href="%s" style="color:#9ca3af;">%s</a></p>
</body></html>',
        sprintf( __( 'Tu trial expira %s', 'stock-sync-pro' ), $day_text ),
        esc_html( $site ),
        $day_text,
        esc_url( $billing_url ),
        esc_url( home_url() ),
        esc_html( home_url() )
    );

    $set_html = fn() => 'text/html';
    add_filter( 'wp_mail_content_type', $set_html );
    wp_mail( $to, $subject, $body );
    remove_filter( 'wp_mail_content_type', $set_html );
}

/**
 * Envía un email de trial expirado al administrador del sitio.
 *
 * @param string $to Dirección de destino.
 */
function ssp_send_trial_expired_email( string $to ): void {
    $site        = get_bloginfo( 'name' );
    $billing_url = admin_url( 'admin.php?page=ssp-billing' );
    $subject     = sprintf(
        /* translators: %s: site name */
        _x( '[Stock Sync Pro] Tu trial de %s ha expirado — sincronizaciones pausadas', 'email subject', 'stock-sync-pro' ),
        $site
    );

    $body = sprintf(
        '<html><body style="font-family:sans-serif;color:#1a202c;max-width:560px;margin:0 auto;padding:24px;">
<h2 style="color:#dc2626;">🔴 Trial expirado</h2>
<p>El período de prueba de <strong>Stock Sync Pro</strong> en <strong>%s</strong> ha terminado.</p>
<p><strong>Las sincronizaciones automáticas están pausadas.</strong> Tu stock no se actualizará hasta que actives una suscripción.</p>
<a href="%s" style="display:inline-block;margin:20px 0;padding:12px 28px;background:#6366f1;color:#fff;border-radius:6px;text-decoration:none;font-weight:600;">
  Activar licencia ahora
</a>
<table style="width:100%%;border-collapse:collapse;margin:16px 0;font-size:13px;">
  <tr style="background:#f9fafb;">
    <td style="padding:10px;border:1px solid #e5e7eb;font-weight:600;">Starter</td>
    <td style="padding:10px;border:1px solid #e5e7eb;">$29/mes · 5.000 productos/mes</td>
  </tr>
  <tr>
    <td style="padding:10px;border:1px solid #e5e7eb;font-weight:600;">Professional</td>
    <td style="padding:10px;border:1px solid #e5e7eb;">$79/mes · 50.000 productos/mes</td>
  </tr>
  <tr style="background:#f9fafb;">
    <td style="padding:10px;border:1px solid #e5e7eb;font-weight:600;">Enterprise</td>
    <td style="padding:10px;border:1px solid #e5e7eb;">$149/mes · 300.000 productos/mes</td>
  </tr>
</table>
<hr style="border:none;border-top:1px solid #e5e7eb;margin:24px 0;">
<p style="font-size:12px;color:#9ca3af;">Stock Sync Pro · <a href="%s" style="color:#9ca3af;">%s</a></p>
</body></html>',
        esc_html( $site ),
        esc_url( $billing_url ),
        esc_url( home_url() ),
        esc_html( home_url() )
    );

    $set_html = fn() => 'text/html';
    add_filter( 'wp_mail_content_type', $set_html );
    wp_mail( $to, $subject, $body );
    remove_filter( 'wp_mail_content_type', $set_html );
}

/**
 * Envía una notificación cuando un webhook muere definitivamente tras 5 intentos.
 * Solo se envía si la opción ssp_notify_on_webhook_dead está activa.
 *
 * @param array $item Item del webhook que ha agotado los reintentos.
 */
function ssp_send_webhook_dead_notification( array $item ): void {
    if ( get_option( 'ssp_notify_on_webhook_dead', '1' ) !== '1' ) {
        return;
    }
    $to = get_option( 'ssp_notify_email', '' );
    if ( empty( $to ) ) {
        $to = get_option( 'admin_email', '' );
    }
    if ( empty( $to ) ) {
        return;
    }

    $site = get_bloginfo( 'name' );
    $subj = sprintf( '[Stock Sync Pro] [%s] Webhook agotado sin entrega', $site );
    $body = sprintf(
        "Un evento webhook no pudo entregarse tras %d intentos y ha sido descartado.\n\nEvento:     %s\nID:         %s\nÚltimo error: %s\nURL:        %s\n\nRevisa la configuración del webhook en:\n%s",
        $item['attempts'] ?? 0,
        $item['event']      ?? 'desconocido',
        $item['id']         ?? '',
        $item['last_error'] ?? 'desconocido',
        get_option( 'ssp_webhook_url', '' ),
        admin_url( 'admin.php?page=wevica-sync-settings' )
    );

    wp_mail( $to, $subj, $body );
}

// ═══════════════════════════════════════════════════════════════════
//  VALIDACIÓN DE URLs EXTERNAS (SSRF)
// ═══════════════════════════════════════════════════════════════════

/**
 * Valida que una URL es segura para hacer peticiones salientes desde el servidor.
 * Rechaza URLs que apunten a IPs privadas, loopback o reservadas (SSRF).
 *
 * @param  string $url URL a validar.
 * @return bool        true si es segura, false si debe bloquearse.
 */
function ssp_is_safe_url( string $url ): bool {
    $parts = wp_parse_url( $url );
    if ( ! $parts || empty( $parts['host'] ) ) {
        return false;
    }

    // Solo http y https.
    $scheme = strtolower( $parts['scheme'] ?? '' );
    if ( ! in_array( $scheme, [ 'http', 'https' ], true ) ) {
        return false;
    }

    $host = $parts['host'];

    // Eliminar corchetes IPv6.
    $host = trim( $host, '[]' );

    // Rechazar 'localhost' y variantes antes de resolver DNS.
    if ( in_array( strtolower( $host ), [ 'localhost', 'localhost.localdomain', '127.0.0.1', '::1' ], true ) ) {
        return false;
    }

    // Si es una IP, validarla directamente.
    $is_ipv4 = (bool) filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
    $is_ipv6 = (bool) filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 );

    if ( $is_ipv4 || $is_ipv6 ) {
        // Validar que NO sea privada, reservada o multicast
        $flags = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
        if ( $is_ipv6 ) {
            $flags |= FILTER_FLAG_IPV6;
        } else {
            $flags |= FILTER_FLAG_IPV4;
        }

        $is_safe = (bool) filter_var( $host, FILTER_VALIDATE_IP, $flags );

        // Rechazar adicionalmente link-local (169.254.x.x para IPv4, fe80::/10 para IPv6)
        if ( $is_safe && $is_ipv4 ) {
            // Detectar link-local 169.254.x.x
            if ( strpos( $host, '169.254.' ) === 0 ) {
                return false;
            }
        }
        if ( $is_safe && $is_ipv6 ) {
            // Detectar link-local fe80:
            if ( strpos( strtolower( $host ), 'fe80:' ) === 0 ) {
                return false;
            }
        }

        return $is_safe;
    }

    // Resolver hostname → IP y validar.
    // Usar timeout bajo para evitar bloqueos
    $ip = @gethostbyname( $host ); // Silenciar warnings de DNS

    if ( $ip === $host ) {
        // No se pudo resolver el DNS: rechazar para evitar rebinding.
        return false;
    }

    // Validar la IP resuelta
    $flags = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE | FILTER_FLAG_IPV4;
    return (bool) filter_var( $ip, FILTER_VALIDATE_IP, $flags );
}

// ═══════════════════════════════════════════════════════════════════
//  EXCLUSIÓN DE SKUs
// ═══════════════════════════════════════════════════════════════════

/**
 * Devuelve el array de SKUs excluidos de la sincronización.
 * El admin los configura en Ajustes como un SKU por línea.
 *
 * @return string[]
 */
function ssp_get_excluded_skus(): array {
    static $cache = null;
    if ( $cache !== null ) {
        return $cache;
    }
    $raw   = get_option( 'ssp_exclude_skus', '' );
    $cache = array_values( array_unique(
        array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', $raw ) ) )
    ) );
    return $cache;
}

// ═══════════════════════════════════════════════════════════════════
//  ACTUALIZACIONES DESDE GITHUB
// ═══════════════════════════════════════════════════════════════════

/**
 * Obtiene información de actualización desde el servidor Vercel de Wévica.
 * Los usuarios NO necesitan configurar ningún token — el servidor maneja la
 * autenticación con GitHub de forma transparente.
 * Se cachea 12 horas para no saturar el servidor.
 *
 * @return array|null Array con 'version', 'download_url', 'details_url', 'changelog', 'last_updated' o null si falla.
 */
function ssp_fetch_update_info(): ?array {
    $cached = get_transient( 'ssp_update_info_vercel' );
    // Invalidate cache if the cached version is no newer than what's already installed.
    // This prevents showing stale data after a plugin update.
    if ( is_array( $cached ) && version_compare( $cached['version'] ?? '0', WEVICA_SYNC_VERSION, '<=' ) ) {
        delete_transient( 'ssp_update_info_vercel' );
        $cached = false;
    }
    if ( is_array( $cached ) ) {
        return $cached;
    }

    $response = wp_remote_get( WEVICA_UPDATE_URL, [
        'timeout' => 10,
        'headers' => [ 'User-Agent' => 'StockSyncPro/' . WEVICA_SYNC_VERSION ],
    ] );

    if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
        return null;
    }

    $data = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( ! is_array( $data ) || empty( $data['version'] ) || empty( $data['download_url'] ) ) {
        return null;
    }

    // Validar formato de versión para prevenir inyecciones.
    if ( ! preg_match( '/^\d+\.\d+\.\d+/', $data['version'] ) ) {
        return null;
    }

    $info = [
        'version'      => sanitize_text_field( $data['version'] ),
        'download_url' => esc_url_raw( $data['download_url'] ),
        'details_url'  => esc_url_raw( $data['details_url'] ?? '' ),
        'changelog'    => wp_kses_post( $data['changelog'] ?? '' ),
        'last_updated' => sanitize_text_field( $data['last_updated'] ?? '' ),
    ];

    set_transient( 'ssp_update_info_vercel', $info, 12 * HOUR_IN_SECONDS );
    return $info;
}


/**
 * Registra errores del sistema de actualizaciones en wp-content/debug.log
 *
 * @param string $message Mensaje de error.
 */
function ssp_log_update_error( string $message ): void {
    if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
        error_log( '[Stock Sync Pro] Update error: ' . $message );
    }
}

