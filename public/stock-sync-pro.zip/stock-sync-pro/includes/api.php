<?php
/**
 * Wévica Stock Sync — Endpoints REST API.
 *
 * Registra las rutas y sus callbacks. La autenticación y el rate-limiting
 * están en helpers.php; la lógica de sync en sync.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'rest_api_init', 'wevica_sync_register_routes' );

function wevica_sync_register_routes() {
    $routes = [
        [ '/sync',     'POST', 'wevica_sync_api_sync' ],
        [ '/sync-csv', 'POST', 'wevica_sync_api_sync_csv' ],
        [ '/status',   'GET',  'wevica_sync_api_status' ],
        [ '/config',   'GET',  'ssp_api_get_config' ],
    ];

    // Generic namespace (new).
    foreach ( $routes as [$path, $method, $callback] ) {
        register_rest_route( 'stocksync/v1', $path, [
            'methods'             => $method,
            'callback'            => $callback,
            'permission_callback' => 'wevica_sync_api_auth',
        ] );
    }

    // Legacy namespace (backward compat with v3.x integrations).
    foreach ( $routes as [$path, $method, $callback] ) {
        register_rest_route( 'wevica/v1', $path, [
            'methods'             => $method,
            'callback'            => $callback,
            'permission_callback' => 'wevica_sync_api_auth',
        ] );
    }

}

// ── Autenticación ─────────────────────────────────────────────────

add_filter( 'rest_pre_serve_request', 'ssp_add_security_headers' );

function ssp_add_security_headers() {
    header( 'X-Content-Type-Options: nosniff' );
    header( 'X-Robots-Tag: noindex, nofollow' );
}

function wevica_sync_api_auth( WP_REST_Request $request ) {
    // Accept both new generic header and legacy header.
    $provided = $request->get_header( 'X-StockSync-Key' )
             ?: $request->get_header( 'X-Wevica-Key' );

    if ( empty( $provided ) ) {
        wevica_sync_log_auth_failure( 'missing_key' );
        return new WP_Error(
            'ssp_no_key',
            __( 'API key required (header: X-StockSync-Key).', 'stock-sync-pro' ),
            [ 'status' => 401 ]
        );
    }

    // Verificar API key y obtener su hash para rate limiting
    $key_hash = hash( 'sha256', $provided );
    if ( ! ssp_verify_api_key( $provided ) ) {
        wevica_sync_log_auth_failure( 'invalid_key' );
        return new WP_Error(
            'ssp_invalid_key',
            __( 'Invalid API key.', 'stock-sync-pro' ),
            [ 'status' => 403 ]
        );
    }

    // Rate limit POR API KEY, no por IP
    $rate_check = wevica_sync_check_rate_limit( $key_hash, 120 );
    if ( is_wp_error( $rate_check ) ) {
        return $rate_check;
    }

    return true;
}

// ── POST /wevica/v1/sync ──────────────────────────────────────────

function wevica_sync_api_sync( WP_REST_Request $request ) {
    $body          = $request->get_json_params();
    $tienda        = isset( $body['tienda'] )        ? sanitize_text_field( $body['tienda'] )        : '';
    $productos     = isset( $body['productos'] )     ? $body['productos']                            : [];
    $sync_id       = isset( $body['sync_id'] )       ? sanitize_text_field( $body['sync_id'] )       : '';
    $is_last_batch = isset( $body['is_last_batch'] ) ? (bool) $body['is_last_batch']                 : true;

    if ( empty( $productos ) || ! is_array( $productos ) ) {
        return new WP_REST_Response( [
            'success' => false,
            'error'   => 'Se requiere un array "productos" con al menos un elemento.',
        ], 400 );
    }

    $productos_clean = [];
    foreach ( $productos as $p ) {
        if ( ! is_array( $p ) ) continue;
        $clean = [];
        if ( isset( $p['sku'] ) )    $clean['sku']    = sanitize_text_field( $p['sku'] );
        if ( isset( $p['stock'] ) )  $clean['stock']  = sanitize_text_field( $p['stock'] );
        if ( isset( $p['precio'] ) ) $clean['precio'] = sanitize_text_field( $p['precio'] );
        if ( isset( $p['nombre'] ) ) $clean['nombre'] = sanitize_text_field( $p['nombre'] );
        if ( ! empty( $clean['sku'] ) ) {
            $productos_clean[] = $clean;
        }
    }

    $dry_run_req = isset( $body['dry_run'] ) ? (bool) $body['dry_run'] : null;

    // Check plan limits before syncing
    $limit_check = ssp_check_feature_access( 'products', count( $productos_clean ) );
    if ( is_wp_error( $limit_check ) ) {
        return new WP_REST_Response( [
            'success' => false,
            'error'   => $limit_check->get_error_message(),
            'code'    => $limit_check->get_error_code(),
        ], $limit_check->get_error_data()['status'] ?? 403 );
    }

    $result = wevica_sync_process_json( $productos_clean, $tienda, 'api', $sync_id, $is_last_batch, $dry_run_req );

    if ( isset( $result['error'] ) ) {
        return new WP_REST_Response( [ 'success' => false, 'error' => $result['error'] ], 500 );
    }

    // Track usage on success
    if ( ! isset( $result['error'] ) && isset( $result['total'] ) ) {
        ssp_increment_usage( 'products', $result['total'] );
        ssp_increment_usage( 'api_calls', 1 );
    }

    $resp = [
        'success'      => true,
        'total'        => $result['total'],
        'actualizados' => $result['actualizados'],
        'sin_sku'      => $result['sin_sku'],
        'errores'      => $result['errores'],
        'dry_run'      => $result['dry_run'],
    ];
    if ( $result['dry_run'] ) {
        $resp['preview'] = wevica_sync_truncate_detalles( $result['detalles'], 500 );
    }
    return new WP_REST_Response( $resp, 200 );
}

// ── POST /wevica/v1/sync-csv ──────────────────────────────────────

function wevica_sync_api_sync_csv( WP_REST_Request $request ) {
    $csv_content = $request->get_body();
    if ( empty( $csv_content ) ) {
        return new WP_REST_Response( [ 'success' => false, 'error' => 'Body vacío. Envía el contenido CSV.' ], 400 );
    }

    $tienda    = sanitize_text_field( $request->get_header( 'X-Wevica-Tienda' ) ?: '' );
    $col_sku   = sanitize_text_field( $request->get_header( 'X-Wevica-Col-Sku' )   ?: 'sku_ixia' );
    $col_stock = sanitize_text_field( $request->get_header( 'X-Wevica-Col-Stock' ) ?: 'stock' );
    $col_price = sanitize_text_field( $request->get_header( 'X-Wevica-Col-Price' ) ?: 'precio' );

    // Create temporary file (compatible with older WordPress versions)
    $tmp_dir = function_exists( 'wp_get_upload_dir' )
        ? wp_get_upload_dir()['basedir'] . '/wevica-tmp'
        : get_temp_dir();

    if ( ! is_dir( $tmp_dir ) ) {
        wp_mkdir_p( $tmp_dir );
        // Block direct HTTP access to this directory
        file_put_contents( $tmp_dir . '/.htaccess', "Deny from all\n" );
        file_put_contents( $tmp_dir . '/index.php', "<?php // Silence is golden.\n" );
    }

    $tmp = $tmp_dir . '/csv_' . bin2hex( random_bytes( 16 ) ) . '.tmp';
    if ( ! $tmp ) {
        return new WP_REST_Response( [ 'success' => false, 'error' => 'Error creando archivo temporal.' ], 500 );
    }

    $written = file_put_contents( $tmp, $csv_content );
    if ( $written === false ) {
        @unlink( $tmp );
        return new WP_REST_Response( [ 'success' => false, 'error' => 'Error escribiendo archivo temporal.' ], 500 );
    }

    // Check plan limits before syncing
    $limit_check = ssp_check_feature_access( 'api_calls' );
    if ( is_wp_error( $limit_check ) ) {
        @unlink( $tmp );
        return new WP_REST_Response( [
            'success' => false,
            'error'   => $limit_check->get_error_message(),
            'code'    => $limit_check->get_error_code(),
        ], $limit_check->get_error_data()['status'] ?? 403 );
    }

    $dry_run_header = $request->get_header( 'X-Wevica-Dry-Run' );
    $dry_run_req    = ( $dry_run_header && strtolower( $dry_run_header ) !== 'false' ) ? true : null;

    $result = wevica_sync_process_csv( $tmp, $tienda, 'api', $col_sku, $col_stock, $col_price, 'nombre', $dry_run_req );
    @unlink( $tmp );

    if ( isset( $result['error'] ) ) {
        return new WP_REST_Response( [ 'success' => false, 'error' => $result['error'] ], 500 );
    }

    // Track usage on success
    if ( ! isset( $result['error'] ) && isset( $result['total'] ) ) {
        ssp_increment_usage( 'products', $result['total'] );
        ssp_increment_usage( 'api_calls', 1 );
    }

    $resp = [
        'success'      => true,
        'total'        => $result['total'],
        'actualizados' => $result['actualizados'],
        'sin_sku'      => $result['sin_sku'],
        'errores'      => $result['errores'],
        'dry_run'      => $result['dry_run'],
    ];
    if ( $result['dry_run'] ) {
        $resp['preview'] = wevica_sync_truncate_detalles( $result['detalles'], 500 );
    }
    return new WP_REST_Response( $resp, 200 );
}

// ── GET /wevica/v1/status ─────────────────────────────────────────

function wevica_sync_api_status( WP_REST_Request $request ) {
    global $wpdb;
    $table     = $wpdb->prefix . WEVICA_SYNC_TABLE;
    $last_sync = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY fecha DESC LIMIT 1" ) );

    $skus = $wpdb->get_col( $wpdb->prepare(
        "SELECT DISTINCT pm.meta_value
         FROM {$wpdb->postmeta} pm
         INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
         WHERE pm.meta_key = %s
           AND pm.meta_value != %s
           AND p.post_status = %s
           AND p.post_type IN (%s, %s)
         ORDER BY pm.meta_value",
        '_sku',
        '',
        'publish',
        'product',
        'product_variation'
    ) );

    $catalog_sheets_id = get_option( 'ssp_catalog_sheets_id', '' );

    $response = [
        'plugin'      => 'wevica-stock-sync',
        'version'     => WEVICA_SYNC_VERSION,
        'woocommerce' => class_exists( 'WooCommerce' ),
        'skus'        => $skus ? array_values( $skus ) : [],
        'skus_total'  => $skus ? count( $skus ) : 0,
        'last_sync'   => null,
        'catalog'     => [
            'sheets_id'  => $catalog_sheets_id,
            'excel_hoja' => get_option( 'ssp_catalog_excel_hoja', '' ),
        ],
    ];

    if ( $last_sync ) {
        $response['last_sync'] = [
            'fecha'        => $last_sync->fecha,
            'tienda'       => $last_sync->tienda,
            'tipo'         => $last_sync->tipo,
            'total'        => (int) $last_sync->total_productos,
            'actualizados' => (int) $last_sync->actualizados,
            'errores'      => (int) $last_sync->errores,
        ];
    }

    return new WP_REST_Response( $response, 200 );
}

// ── GET /stocksync/v1/config ──────────────────────────────────────

/**
 * Returns the current plugin configuration for the Sync Engine.
 * Used by the Registry to keep site config in sync.
 */
function ssp_api_get_config( WP_REST_Request $request ) {
    return new WP_REST_Response( [
        'site_url'          => home_url(),
        'source_url'        => get_option( 'ssp_cron_source_url', '' ),
        'source_type'       => get_option( 'ssp_cron_source_type', 'auto' ),
        'frequency_minutes' => ssp_cron_interval_to_minutes( (string) get_option( 'ssp_cron_interval', 'off' ) ),
        'col_sku'           => get_option( 'ssp_cron_col_sku', 'sku' ),
        'col_stock'         => get_option( 'ssp_cron_col_stock', 'stock' ),
        'col_price'         => get_option( 'ssp_cron_col_price', 'precio' ),
        'col_name'          => get_option( 'ssp_cron_col_name', 'nombre' ),
        'tienda'            => get_option( 'ssp_cron_tienda', 'cron' ),
        'version'           => WEVICA_SYNC_VERSION,
    ], 200 );
}

