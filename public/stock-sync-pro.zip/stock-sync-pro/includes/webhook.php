<?php
/**
 * Stock Sync Pro — Webhook dispatcher with retry queue.
 *
 * Events are enqueued in a WP option and delivered via a 5-minute cron.
 * Failed deliveries are retried up to 5 times with exponential backoff.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Enqueues a webhook event for delivery.
 * Dry-run payloads are skipped — no point retrying simulated events.
 *
 * @param string $event   Event name: 'sync_complete' | 'sync_error' | ...
 * @param array  $payload Extra data to include.
 */
function ssp_dispatch_webhook( string $event, array $payload ): void {
    $url = get_option( 'ssp_webhook_url', '' );
    if ( empty( $url ) ) {
        return;
    }
    // Skip queuing dry-run events.
    if ( ! empty( $payload['dry_run'] ) ) {
        return;
    }
    ssp_webhook_enqueue( $event, $payload );
}

// ── Queue management ──────────────────────────────────────────────────────────

/**
 * Pushes one item onto the persistent webhook queue.
 * Hard-caps the queue at 100 items to prevent unbounded growth.
 */
function ssp_webhook_enqueue( string $event, array $payload ): void {
    $queue = ssp_webhook_get_queue();
    $queue_limit = 100;
    $queue_warning_threshold = 80;

    // Si cola está llena, eliminar evento más antiguo y notificar
    if ( count( $queue ) >= $queue_limit ) {
        $dropped = array_shift( $queue );

        // Notificar al admin solo una vez cada 6 horas
        $last_warning = get_transient( 'ssp_webhook_queue_overflow_warning' );
        if ( ! $last_warning ) {
            $to = get_option( 'ssp_notify_email', '' );
            if ( empty( $to ) ) {
                $to = get_option( 'admin_email', '' );
            }
            if ( ! empty( $to ) && is_email( $to ) ) {
                wp_mail(
                    $to,
                    '[Stock Sync Pro] Cola de webhooks llena',
                    sprintf(
                        "La cola de webhooks alcanzó el límite de %d eventos.\n\n" .
                        "El evento más antiguo fue descartado:\n" .
                        "  Evento: %s\n" .
                        "  ID: %s\n" .
                        "  Creado: %s\n\n" .
                        "Esto puede indicar que los webhooks no se están entregando correctamente.\n" .
                        "Revisa la configuración del webhook en: %s",
                        $queue_limit,
                        $dropped['event'] ?? 'desconocido',
                        $dropped['id'] ?? 'sin-id',
                        gmdate( 'Y-m-d H:i:s', $dropped['created_at'] ?? 0 ),
                        admin_url( 'admin.php?page=wevica-sync-settings' )
                    )
                );
            }
            set_transient( 'ssp_webhook_queue_overflow_warning', 1, 6 * HOUR_IN_SECONDS );
        }
    } elseif ( count( $queue ) >= $queue_warning_threshold ) {
        // Advertencia si cola está cerca del límite (sin enviar email, solo log)
        error_log( sprintf(
            'Wevica: Webhook queue at %d/%d events. May reach limit soon.',
            count( $queue ),
            $queue_limit
        ) );
    }

    $queue[] = [
        'id'         => 'whk_' . wp_generate_password( 12, false ),
        'event'      => $event,
        'payload'    => $payload,
        'created_at' => time(),
        'attempts'   => 0,
        'next_retry' => time(), // fire immediately on first attempt
        'last_error' => '',
    ];
    ssp_webhook_save_queue( $queue );
}

/** @return array Current queue. */
function ssp_webhook_get_queue(): array {
    $q = get_option( 'ssp_webhook_queue', [] );
    return is_array( $q ) ? $q : [];
}

/** @param array $queue Updated queue to persist (autoload=no). */
function ssp_webhook_save_queue( array $queue ): void {
    update_option( 'ssp_webhook_queue', $queue, false );
}

// ── Delivery ──────────────────────────────────────────────────────────────────

/**
 * Attempts to deliver one queued item (blocking).
 * Updates $item['attempts'] and $item['last_error'] in-place.
 *
 * @param  array  $item   Queue item (passed by reference).
 * @param  string $url    Webhook URL.
 * @param  string $secret HMAC secret.
 * @return bool           true on HTTP 2xx, false otherwise.
 */
function ssp_webhook_fire_once( array &$item, string $url, string $secret ): bool {
    if ( ! ssp_is_safe_url( $url ) ) {
        $item['attempts']++;
        $item['last_error'] = 'URL bloqueada: apunta a una dirección privada o inválida.';
        return false;
    }

    $body = wp_json_encode( array_merge(
        [
            'event'     => $item['event'],
            'site_url'  => home_url(),
            'timestamp' => gmdate( 'c' ),
        ],
        $item['payload']
    ) );

    $headers = [
        'Content-Type'      => 'application/json',
        'X-StockSync-Event' => $item['event'],
        'User-Agent'        => 'StockSyncPro/' . WEVICA_SYNC_VERSION,
    ];
    if ( ! empty( $secret ) ) {
        $headers['X-StockSync-Signature'] = 'sha256=' . hash_hmac( 'sha256', $body, $secret );
    }

    $response = wp_remote_post( $url, [
        'timeout'     => 10,
        'blocking'    => true,
        'redirection' => 3,
        'body'        => $body,
        'headers'     => $headers,
    ] );

    $item['attempts']++;

    if ( is_wp_error( $response ) ) {
        $item['last_error'] = $response->get_error_message();
        return false;
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( $code >= 200 && $code < 300 ) {
        return true;
    }

    $item['last_error'] = "HTTP {$code}";
    return false;
}

// ── Cron retry worker ─────────────────────────────────────────────────────────

add_action( 'ssp_webhook_retry', 'ssp_do_webhook_retry' );

/**
 * Processes the webhook retry queue (up to 20 items per run).
 * Exponential backoff: attempt 1=immediate, 2=1min, 3=5min, 4=30min, 5=2h.
 * Items exceeding 5 attempts are permanently dropped.
 */
function ssp_do_webhook_retry(): void {
    // Atomic lock — prevent overlapping runs with timeout protection.
    $lock_key = 'ssp_webhook_retry_lock_time';
    $lock_timeout = 60; // segundos
    $now = time();
    $lock_time = (int) get_option( $lock_key, 0 );

    // Si hay lock activo y no ha expirado, salir
    if ( $lock_time > 0 && ( $now - $lock_time ) < $lock_timeout ) {
        return;
    }

    // Intentar obtener el lock atómicamente
    if ( ! update_option( $lock_key, $now ) ) {
        // update_option devuelve false si no se puede actualizar (muy raro)
        return;
    }

    $url    = get_option( 'ssp_webhook_url', '' );
    $secret = get_option( 'ssp_webhook_secret', '' );

    if ( empty( $url ) ) {
        ssp_webhook_save_queue( [] );
        delete_option( $lock_key );
        return;
    }

    $backoff  = [ 0, 60, 300, 1800, 7200 ]; // seconds per attempt index
    $max_att  = 5;
    $max_run  = 20;
    $now      = time();
    $processed = 0;
    $queue    = ssp_webhook_get_queue();
    $updated  = [];

    foreach ( $queue as $item ) {
        if ( $processed >= $max_run ) {
            $updated[] = $item;
            continue;
        }
        if ( $item['next_retry'] > $now ) {
            $updated[] = $item;
            continue;
        }

        $success = ssp_webhook_fire_once( $item, $url, $secret );
        $processed++;

        if ( $success ) {
            continue; // delivered — drop from queue
        }
        if ( $item['attempts'] >= $max_att ) {
            ssp_send_webhook_dead_notification( $item );
            continue; // exhausted — drop permanently
        }

        $delay             = $backoff[ min( $item['attempts'], count( $backoff ) - 1 ) ];
        $item['next_retry'] = $now + $delay;
        $updated[]          = $item;
    }

    ssp_webhook_save_queue( $updated );
    delete_option( $lock_key );
}

// ── Test webhook (bypasses queue — direct delivery) ───────────────────────────

/**
 * Sends a ping event directly (blocking). Used from the admin AJAX action.
 *
 * @param  string $url    Webhook URL to test.
 * @param  string $secret Optional HMAC secret.
 * @return array { success: bool, code: int, error: string }
 */
function ssp_test_webhook( string $url, string $secret = '' ): array {
    if ( ! ssp_is_safe_url( $url ) ) {
        return [
            'success' => false,
            'code'    => 0,
            'error'   => __( 'URL bloqueada: apunta a una dirección privada o inválida.', 'stock-sync-pro' ),
        ];
    }

    $body = wp_json_encode( [
        'event'     => 'ping',
        'site_url'  => home_url(),
        'timestamp' => gmdate( 'c' ),
        'message'   => 'Stock Sync Pro webhook test — if you see this, it works!',
    ] );

    $headers = [
        'Content-Type'      => 'application/json',
        'X-StockSync-Event' => 'ping',
        'User-Agent'        => 'StockSyncPro/' . WEVICA_SYNC_VERSION,
    ];
    if ( ! empty( $secret ) ) {
        $headers['X-StockSync-Signature'] = 'sha256=' . hash_hmac( 'sha256', $body, $secret );
    }

    $response = wp_remote_post( $url, [
        'timeout'     => 10,
        'blocking'    => true,
        'redirection' => 3,
        'body'        => $body,
        'headers'     => $headers,
    ] );

    if ( is_wp_error( $response ) ) {
        return [ 'success' => false, 'code' => 0, 'error' => $response->get_error_message() ];
    }

    $code = wp_remote_retrieve_response_code( $response );
    return [
        'success' => ( $code >= 200 && $code < 300 ),
        'code'    => $code,
        'error'   => '',
    ];
}

// ── AJAX — test webhook ───────────────────────────────────────────────────────

add_action( 'wp_ajax_ssp_test_webhook', 'ssp_ajax_test_webhook' );

function ssp_ajax_test_webhook(): void {
    check_ajax_referer( 'ssp_webhook_nonce', 'nonce' );
    if ( ! current_user_can( wevica_sync_capability() ) ) {
        wp_send_json_error( [ 'message' => __( 'Sin permisos.', 'stock-sync-pro' ) ] );
    }

    $url    = sanitize_url( wp_unslash( $_POST['url'] ?? '' ) );
    $secret = sanitize_text_field( wp_unslash( $_POST['secret'] ?? '' ) );

    if ( empty( $url ) ) {
        wp_send_json_error( [ 'message' => __( 'Introduce una URL de webhook.', 'stock-sync-pro' ) ] );
    }

    $result = ssp_test_webhook( $url, $secret );

    if ( $result['success'] ) {
        wp_send_json_success( [
            /* translators: HTTP status code */
            'message' => sprintf( __( 'Webhook recibido correctamente (HTTP %d).', 'stock-sync-pro' ), $result['code'] ),
        ] );
    } else {
        $msg = $result['error']
            ? $result['error']
            /* translators: HTTP status code */
            : sprintf( __( 'El servidor respondió con HTTP %d.', 'stock-sync-pro' ), $result['code'] );
        wp_send_json_error( [ 'message' => $msg ] );
    }
}

// ── AJAX — clear retry queue ──────────────────────────────────────────────────

add_action( 'wp_ajax_ssp_clear_webhook_queue', 'ssp_ajax_clear_webhook_queue' );

function ssp_ajax_clear_webhook_queue(): void {
    check_ajax_referer( 'ssp_webhook_nonce', 'nonce' );
    if ( ! current_user_can( wevica_sync_capability() ) ) {
        wp_send_json_error( [ 'message' => __( 'Sin permisos.', 'stock-sync-pro' ) ] );
    }
    ssp_webhook_save_queue( [] );
    wp_send_json_success( [ 'message' => __( 'Cola de webhooks vaciada.', 'stock-sync-pro' ) ] );
}
