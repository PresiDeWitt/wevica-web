<?php
/**
 * Wévica Stock Sync — Panel de administración.
 *
 * Registra hooks de menú, estilos, avisos y actualizaciones automáticas.
 * Las funciones de página son wrappers que preparan los datos y delegan
 * el renderizado a los archivos de la carpeta views/.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ═══════════════════════════════════════════════════════════════════
//  CAPACIDAD REQUERIDA
// ═══════════════════════════════════════════════════════════════════

/**
 * Devuelve la capacidad necesaria para gestionar el plugin.
 * Usa 'manage_woocommerce' si WooCommerce está activo, o 'manage_options'
 * como fallback para que el admin siempre pueda acceder.
 */
function wevica_sync_capability(): string {
    return class_exists( 'WooCommerce' ) ? 'manage_woocommerce' : 'manage_options';
}

// ═══════════════════════════════════════════════════════════════════
//  AVISOS DE ADMINISTRACIÓN
// ═══════════════════════════════════════════════════════════════════

add_action( 'admin_notices', 'wevica_sync_admin_notices' );

function wevica_sync_admin_notices() {
    if ( get_transient( 'wevica_sync_notice_wc' ) ) {
        echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Stock Sync Pro', 'stock-sync-pro' ) . '</strong> ' . esc_html__( 'requiere WooCommerce activo para funcionar.', 'stock-sync-pro' ) . '</p></div>';
        delete_transient( 'wevica_sync_notice_wc' );
    }

    if ( get_transient( 'wevica_sync_notice_migrated' ) && current_user_can( wevica_sync_capability() ) ) {
        $migrated_key = get_transient( 'wevica_sync_migrated_key' );
        if ( $migrated_key ) {
            echo '<div class="notice notice-warning is-dismissible"><p>';
            echo '<strong>' . esc_html__( 'Stock Sync Pro:', 'stock-sync-pro' ) . '</strong> ' . esc_html__( 'Tu clave API ha sido migrada a almacenamiento seguro (hash).', 'stock-sync-pro' ) . ' ';
            echo '<strong>' . esc_html__( 'Cópiala ahora, no se volverá a mostrar:', 'stock-sync-pro' ) . '</strong><br>';
            echo '<code>' . esc_html( $migrated_key ) . '</code>';
            echo '</p></div>';
            delete_transient( 'wevica_sync_migrated_key' );
        }
        delete_transient( 'wevica_sync_notice_migrated' );
    }
}

// ═══════════════════════════════════════════════════════════════════
//  MIGRACIÓN API KEY v2 → v3 (texto plano → hash)
// ═══════════════════════════════════════════════════════════════════

add_action( 'admin_init', 'wevica_sync_migrate_api_key' );

function wevica_sync_migrate_api_key() {
    $legacy_key = get_option( 'wevica_sync_api_key' );
    if ( $legacy_key && ! get_option( 'wevica_sync_api_key_hash' ) ) {
        update_option( 'wevica_sync_api_key_hash', wevica_sync_hash_key( $legacy_key ) );
        set_transient( 'wevica_sync_migrated_key', $legacy_key, 600 );
        set_transient( 'wevica_sync_notice_migrated', true, 600 );
        delete_option( 'wevica_sync_api_key' );
    }
}

// ═══════════════════════════════════════════════════════════════════
//  MENÚ DE ADMINISTRACIÓN
// ═══════════════════════════════════════════════════════════════════

add_action( 'admin_menu', 'wevica_sync_admin_menu' );

function wevica_sync_admin_menu() {
    $cap = wevica_sync_capability();
    add_menu_page(
        __( 'Stock Sync Pro', 'stock-sync-pro' ),
        __( 'Stock Sync Pro', 'stock-sync-pro' ),
        $cap,
        'wevica-sync',
        'wevica_sync_page_dashboard',
        'dashicons-update',
        56
    );
    add_submenu_page( 'wevica-sync', __( 'Dashboard', 'stock-sync-pro' ),   __( 'Dashboard', 'stock-sync-pro' ),   $cap, 'wevica-sync',              'wevica_sync_page_dashboard' );
    add_submenu_page( 'wevica-sync', __( 'Analytics', 'stock-sync-pro' ),   __( 'Analytics', 'stock-sync-pro' ),   $cap, 'wevica-sync-analytics',    'wevica_sync_page_analytics' );
    add_submenu_page( 'wevica-sync', __( 'Importar CSV', 'stock-sync-pro' ), __( 'Importar CSV', 'stock-sync-pro' ), $cap, 'wevica-sync-import',     'wevica_sync_page_import' );
    add_submenu_page( 'wevica-sync', __( 'Historial', 'stock-sync-pro' ),    __( 'Historial', 'stock-sync-pro' ),   $cap, 'wevica-sync-logs',     'wevica_sync_page_logs' );
    add_submenu_page( 'wevica-sync', __( 'Claves API', 'stock-sync-pro' ),   __( 'Claves API', 'stock-sync-pro' ),  $cap, 'ssp-apikeys',          'ssp_page_apikeys' );
    add_submenu_page( 'wevica-sync', __( 'Ajustes', 'stock-sync-pro' ),      __( 'Ajustes', 'stock-sync-pro' ),     $cap, 'wevica-sync-settings', 'wevica_sync_page_settings' );
    add_submenu_page( 'wevica-sync', __( 'Estado', 'stock-sync-pro' ),       __( 'Estado', 'stock-sync-pro' ),      $cap, 'ssp-status',           'ssp_page_status' );
    add_submenu_page( 'wevica-sync', __( 'Sync Engine', 'stock-sync-pro' ),  __( 'Sync Engine', 'stock-sync-pro' ), $cap, 'ssp-license',          'ssp_page_license' );
    add_submenu_page( 'wevica-sync', __( 'Ayuda', 'stock-sync-pro' ),        __( 'Ayuda', 'stock-sync-pro' ),       $cap, 'ssp-help',             'ssp_page_help' );
    // Página de detalle (oculta del menú).
    add_submenu_page( null, __( 'Detalle de sincronización', 'stock-sync-pro' ), 'Detalle', $cap, 'wevica-sync-detail', 'wevica_sync_page_detail' );
}

add_action( 'admin_init', 'ssp_block_removed_sections' );

function ssp_block_removed_sections() {
    if ( ! is_admin() ) {
        return;
    }

    $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
    if ( in_array( $page, [ 'ssp-scrapers', 'ssp-monitoring' ], true ) ) {
        wp_safe_redirect( admin_url( 'admin.php?page=wevica-sync' ) );
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════════
//  ESTILOS ADMIN
// ═══════════════════════════════════════════════════════════════════

add_action( 'admin_enqueue_scripts', 'wevica_sync_admin_styles' );

function wevica_sync_admin_styles( $hook ) {
    $ssp_pages = [ 'ssp-apikeys', 'ssp-license', 'ssp-help', 'ssp-status', 'ssp-billing' ];
    $page      = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
    if ( strpos( $hook, 'wevica-sync' ) === false && ! in_array( $page, $ssp_pages, true ) ) {
        return;
    }
    wp_enqueue_style(
        'wevica-sync-admin',
        WEVICA_SYNC_URL . 'assets/admin-style.css',
        [],
        WEVICA_SYNC_VERSION
    );
    wp_enqueue_script(
        'wevica-sync-admin',
        WEVICA_SYNC_URL . 'assets/admin-script.js',
        [],
        WEVICA_SYNC_VERSION,
        true
    );
    // Chart.js on analytics.
    $page_slug = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
    if ( $page_slug === 'wevica-sync-analytics' ) {
        wp_enqueue_script(
            'chartjs',
            'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js',
            [],
            '4.4.1',
            true
        );
    }
}

// ═══════════════════════════════════════════════════════════════════
//  POST HANDLERS — run on admin_init (before any output)
// ═══════════════════════════════════════════════════════════════════

add_action( 'admin_init', 'ssp_handle_apikeys_post' );

function ssp_handle_apikeys_post() {
    if ( ! isset( $_POST['ssp_action'] ) ) return;
    if ( ! current_user_can( wevica_sync_capability() ) ) return;

    $action = sanitize_key( $_POST['ssp_action'] );

    if ( $action === 'create_key' ) {
        if ( ! isset( $_POST['ssp_create_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ssp_create_nonce'] ) ), 'ssp_create_key' ) ) {
            wp_die( esc_html__( 'Nonce inválido.', 'stock-sync-pro' ) );
        }
        $name      = sanitize_text_field( wp_unslash( $_POST['ssp_key_name'] ?? '' ) );
        $plain_key = ssp_create_api_key( $name );
        update_option( 'ssp_setup_key', $plain_key, 'no' );
        wp_safe_redirect( admin_url( 'admin.php?page=ssp-apikeys' ) );
        exit;
    }

    if ( $action === 'revoke_key' ) {
        $key_id = sanitize_text_field( wp_unslash( $_POST['ssp_revoke_key_id'] ?? '' ) );
        if ( ! isset( $_POST['ssp_revoke_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ssp_revoke_nonce'] ) ), 'ssp_revoke_key_' . $key_id ) ) {
            wp_die( esc_html__( 'Nonce inválido.', 'stock-sync-pro' ) );
        }
        ssp_revoke_api_key( $key_id );
        wp_safe_redirect( admin_url( 'admin.php?page=ssp-apikeys' ) );
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════════
//  PÁGINAS — WRAPPERS DE DATOS → VISTAS
// ═══════════════════════════════════════════════════════════════════

function wevica_sync_page_dashboard() {
    global $wpdb;
    $table = $wpdb->prefix . WEVICA_SYNC_TABLE;

    // $table is always $wpdb->prefix . WEVICA_SYNC_TABLE (a plugin constant, never user input).
    // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $total_syncs   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
    $last_sync     = $wpdb->get_row( "SELECT * FROM {$table} ORDER BY fecha DESC LIMIT 1" );
    $total_updated = (int) $wpdb->get_var( "SELECT COALESCE(SUM(actualizados),0) FROM {$table}" );
    $total_errors  = (int) $wpdb->get_var( "SELECT COALESCE(SUM(errores),0) FROM {$table}" );
    $tiendas       = $wpdb->get_col( "SELECT DISTINCT tienda FROM {$table} WHERE tienda != ''" );
    // phpcs:enable

    // Comprobar si hay actualización disponible (para mostrar el botón en el dashboard)
    $update_info      = ssp_fetch_update_info();
    $update_available = $update_info && ! empty( $update_info['version'] ) &&
                        version_compare( $update_info['version'], WEVICA_SYNC_VERSION, '>' );
    $update_nonce     = wp_create_nonce( 'ssp_do_update' );

    include WEVICA_SYNC_DIR . 'views/dashboard.php';
}

function wevica_sync_page_analytics() {
    global $wpdb;
    $table = $wpdb->prefix . WEVICA_SYNC_TABLE;

    // $table is always $wpdb->prefix . WEVICA_SYNC_TABLE (a plugin constant, never user input).
    // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $total_syncs     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
    $total_updated   = (int) $wpdb->get_var( "SELECT COALESCE(SUM(actualizados),0) FROM {$table}" );
    $total_processed = (int) $wpdb->get_var( "SELECT COALESCE(SUM(total_productos),0) FROM {$table}" );
    $total_errors    = (int) $wpdb->get_var( "SELECT COALESCE(SUM(errores),0) FROM {$table}" );
    // phpcs:enable
    $avg_per_sync    = $total_syncs > 0 ? round( $total_processed / $total_syncs, 1 ) : 0;
    $error_rate      = $total_processed > 0 ? round( ( $total_errors / $total_processed ) * 100, 1 ) : 0;

    // Validar nombre de tabla para defender contra inyecciones (aunque viene de constante)
    $expected_table = $wpdb->prefix . WEVICA_SYNC_TABLE;
    if ( $table !== $expected_table ) {
        wp_die( 'Error: Invalid table name.' );
    }

    $daily_rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT DATE(fecha) AS day,
                    COUNT(*) AS syncs,
                    COALESCE(SUM(actualizados),0) AS updated
             FROM {$table}
             WHERE fecha >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY DATE(fecha)
             ORDER BY day ASC"
        )
    );

    $type_rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT tipo,
                    COUNT(*) AS syncs,
                    COALESCE(SUM(actualizados),0) AS updated
             FROM {$table}
             WHERE tipo NOT LIKE %s
             GROUP BY tipo
             ORDER BY syncs DESC",
            'dry_run_%'
        )
    );

    include WEVICA_SYNC_DIR . 'views/analytics.php';
}

function wevica_sync_page_import() {
    $resultado = null;

    if ( isset( $_POST['wevica_import_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wevica_import_nonce'] ) ), 'wevica_import_csv' ) ) {
        if ( ! current_user_can( wevica_sync_capability() ) ) {
            wp_die( 'No tienes permisos para realizar esta acción.' );
        }

        $tienda    = isset( $_POST['tienda'] )    ? sanitize_text_field( wp_unslash( $_POST['tienda'] ) )    : 'manual';
        $col_sku   = isset( $_POST['col_sku'] )   ? sanitize_text_field( wp_unslash( $_POST['col_sku'] ) )   : 'sku_ixia';
        $col_stock = isset( $_POST['col_stock'] ) ? sanitize_text_field( wp_unslash( $_POST['col_stock'] ) ) : 'stock';
        $col_price = isset( $_POST['col_price'] ) ? sanitize_text_field( wp_unslash( $_POST['col_price'] ) ) : 'precio';
        $col_name  = isset( $_POST['col_name'] )  ? sanitize_text_field( wp_unslash( $_POST['col_name'] ) )  : 'nombre';

        if ( ! empty( $_FILES['csv_file']['tmp_name'] ) ) {
            $tmp      = $_FILES['csv_file']['tmp_name'];
            $filename = isset( $_FILES['csv_file']['name'] ) ? sanitize_file_name( $_FILES['csv_file']['name'] ) : '';
            $filetype = wp_check_filetype( $filename, [ 'csv' => 'text/csv' ] );

            $max_csv_bytes = 10 * 1024 * 1024; // 10 MB
            if ( isset( $_FILES['csv_file']['size'] ) && (int) $_FILES['csv_file']['size'] > $max_csv_bytes ) {
                $resultado = [ 'error' => 'El archivo CSV supera el límite de 10 MB.' ];
            } elseif ( empty( $filetype['ext'] ) ) {
                $resultado = [ 'error' => 'Tipo de archivo no válido. Sube un archivo CSV.' ];
            } else {
                $dry_run_import = ! empty( $_POST['dry_run_import'] );
                $resultado = wevica_sync_process_csv( $tmp, $tienda, 'manual', $col_sku, $col_stock, $col_price, $col_name, $dry_run_import );
            }
        } else {
            $resultado = [ 'error' => 'No se seleccionó ningún archivo.' ];
        }
    }

    include WEVICA_SYNC_DIR . 'views/import.php';
}

function wevica_sync_page_logs() {
    global $wpdb;
    $table = $wpdb->prefix . WEVICA_SYNC_TABLE;

    $paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
    $per_page = 25;
    $offset   = ( $paged - 1 ) * $per_page;
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
    $logs     = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$table} ORDER BY fecha DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ) );
    $total_pages = (int) ceil( $total / $per_page );

    include WEVICA_SYNC_DIR . 'views/logs.php';
}

function wevica_sync_page_detail() {
    if ( ! current_user_can( wevica_sync_capability() ) ) {
        wp_die( 'No tienes permisos.' );
    }

    $id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
    if ( ! $id ) {
        wp_die( 'ID de sincronización no válido.' );
    }

    global $wpdb;
    $table = $wpdb->prefix . WEVICA_SYNC_TABLE;
    $log   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );

    if ( ! $log ) {
        wp_die( 'Registro no encontrado.' );
    }

    $detalles = json_decode( $log->detalles, true ) ?: [];
    $back_url = admin_url( 'admin.php?page=wevica-sync-logs' );

    // Paginación para evitar memory exhaustion.
    $per_page     = 100;
    $total_items  = count( $detalles );
    $total_pages  = max( 1, (int) ceil( $total_items / $per_page ) );
    $current_page = isset( $_GET['pag'] ) ? max( 1, min( absint( $_GET['pag'] ), $total_pages ) ) : 1;
    $offset       = ( $current_page - 1 ) * $per_page;
    $page_items   = array_slice( $detalles, $offset, $per_page );

    // Contadores globales (sobre todos los detalles, sin cargar objetos WC).
    $count_actualizados = 0;
    $count_errores      = 0;
    $count_sin_sku      = 0;
    $count_dry_run      = 0;
    foreach ( $detalles as $d ) {
        if ( ! is_array( $d ) ) continue;
        $t = $d['tipo'] ?? '';
        if ( $t === 'actualizado' )        $count_actualizados++;
        elseif ( $t === 'error' )          $count_errores++;
        elseif ( $t === 'no_encontrado' )  $count_sin_sku++;
        elseif ( $t === 'sin_sku' )        $count_sin_sku++;
        elseif ( $t === 'dry_run_preview' ) $count_dry_run++;
    }

    // Pre-carga de datos de productos en bulk (solo para la página actual).
    $product_data_map = wevica_sync_load_product_data( $page_items );

    // Liberar el array completo; solo necesitamos la página actual.
    unset( $detalles );

    include WEVICA_SYNC_DIR . 'views/detail.php';
}

function wevica_sync_page_settings() {
    $saved = false;

    if ( isset( $_POST['wevica_settings_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wevica_settings_nonce'] ) ), 'wevica_save_settings' ) ) {
        if ( ! current_user_can( wevica_sync_capability() ) ) {
            wp_die( esc_html__( 'Sin permisos.', 'stock-sync-pro' ) );
        }

        // Stock behavior
        $allowed_unknown = [ 'skip', 'outofstock', 'instock' ];
        $unknown_val     = isset( $_POST['stock_unknown'] ) ? sanitize_text_field( wp_unslash( $_POST['stock_unknown'] ) ) : 'skip';
        if ( in_array( $unknown_val, $allowed_unknown, true ) ) {
            update_option( 'wevica_sync_stock_unknown', $unknown_val );
        }
        update_option( 'wevica_sync_dry_run',      ! empty( $_POST['dry_run'] ) ? '1' : '0' );
        update_option( 'wevica_sync_update_price', ! empty( $_POST['update_price'] ) ? '1' : '0' );

        $retention = isset( $_POST['log_retention'] ) ? absint( $_POST['log_retention'] ) : 90;
        update_option( 'wevica_sync_log_retention', max( 7, $retention ) );

        // Cron settings — only writable when Sync Engine service is active.
        $valid_intervals = [ 'off', 'ssp_30min', 'ssp_2hours', 'hourly', 'twicedaily', 'daily', 'weekly' ];
        if ( ssp_autosync_is_active() ) {
            $cron_interval = isset( $_POST['ssp_cron_interval'] ) ? sanitize_text_field( wp_unslash( $_POST['ssp_cron_interval'] ) ) : 'off';
            if ( in_array( $cron_interval, $valid_intervals, true ) ) {
                $prev_interval = get_option( 'ssp_cron_interval', 'off' );
                update_option( 'ssp_cron_interval', $cron_interval );
                if ( $prev_interval !== $cron_interval ) {
                    ssp_setup_cron();
                }
            }
            update_option( 'ssp_cron_source_url',  sanitize_url( wp_unslash( $_POST['ssp_cron_source_url'] ?? '' ) ) );
            $valid_types = [ 'auto', 'json', 'csv' ];
            $src_type    = isset( $_POST['ssp_cron_source_type'] ) ? sanitize_text_field( wp_unslash( $_POST['ssp_cron_source_type'] ) ) : 'auto';
            update_option( 'ssp_cron_source_type', in_array( $src_type, $valid_types, true ) ? $src_type : 'auto' );
            update_option( 'ssp_cron_tienda',      sanitize_text_field( wp_unslash( $_POST['ssp_cron_tienda'] ?? 'cron' ) ) );
            update_option( 'ssp_cron_col_sku',     sanitize_text_field( wp_unslash( $_POST['ssp_cron_col_sku'] ?? 'sku' ) ) );
            update_option( 'ssp_cron_col_stock',   sanitize_text_field( wp_unslash( $_POST['ssp_cron_col_stock'] ?? 'stock' ) ) );
            update_option( 'ssp_cron_col_price',   sanitize_text_field( wp_unslash( $_POST['ssp_cron_col_price'] ?? 'precio' ) ) );
        } else {
            // Sync Engine not active — ensure auto-sync cron is cleared.
            $ts = wp_next_scheduled( 'ssp_auto_sync' );
            if ( $ts ) {
                wp_unschedule_event( $ts, 'ssp_auto_sync' );
            }
        }

        // Webhook settings
        update_option( 'ssp_webhook_url',    sanitize_url( wp_unslash( $_POST['ssp_webhook_url'] ?? '' ) ) );
        update_option( 'ssp_webhook_secret', sanitize_text_field( wp_unslash( $_POST['ssp_webhook_secret'] ?? '' ) ) );

        // Email notification settings
        update_option( 'ssp_notify_on_error',        ! empty( $_POST['ssp_notify_on_error'] )        ? '1' : '0' );
        update_option( 'ssp_notify_on_webhook_dead', ! empty( $_POST['ssp_notify_on_webhook_dead'] ) ? '1' : '0' );
        update_option( 'ssp_notify_email',           sanitize_email( wp_unslash( $_POST['ssp_notify_email'] ?? '' ) ) );

        // SKU exclusions
        update_option( 'ssp_exclude_skus', sanitize_textarea_field( wp_unslash( $_POST['ssp_exclude_skus'] ?? '' ) ) );

        // Proveedor — datos de onboarding
        update_option( 'ssp_supplier_url', sanitize_url( wp_unslash( $_POST['ssp_supplier_url'] ?? '' ) ) );

        $allowed_types = [ 'web_scraper', 'csv_url', 'google_sheets', 'ftp', 'api_rest', 'otro' ];
        $supplier_type = sanitize_text_field( wp_unslash( $_POST['ssp_supplier_type'] ?? '' ) );
        update_option( 'ssp_supplier_type', in_array( $supplier_type, $allowed_types, true ) ? $supplier_type : '' );

        update_option( 'ssp_supplier_notes', sanitize_textarea_field( wp_unslash( $_POST['ssp_supplier_notes'] ?? '' ) ) );

        // Catálogo del proveedor (Google Sheets)
        $sheets_raw = sanitize_text_field( wp_unslash( $_POST['ssp_catalog_sheets_url'] ?? '' ) );
        // Extraer ID de Google Sheets URL, Google Drive URL, o usar directamente si ya es un ID
        if ( preg_match( '#/spreadsheets/d/([a-zA-Z0-9_\-]+)#', $sheets_raw, $m ) ) {
            // https://docs.google.com/spreadsheets/d/{ID}/edit
            $sheets_raw = $m[1];
        } elseif ( preg_match( '#/file/d/([a-zA-Z0-9_\-]+)#', $sheets_raw, $m ) ) {
            // https://drive.google.com/file/d/{ID}/view
            $sheets_raw = $m[1];
        }
        // Si no matchea ningún patrón de URL, se asume que ya es un ID directo
        update_option( 'ssp_catalog_sheets_id',  $sheets_raw );
        update_option( 'ssp_catalog_excel_hoja', sanitize_text_field( wp_unslash( $_POST['ssp_catalog_excel_hoja'] ?? '' ) ) );

        $saved = true;

        // Enviar solicitud de configuración de scraper al propietario.
        if ( ! empty( $_POST['ssp_send_onboarding'] ) ) {
            $onboarding_ok = ssp_send_onboarding_to_owner();
            if ( $onboarding_ok ) {
                update_option( 'ssp_onboarding_submitted', current_time( 'mysql' ) );
            } else {
                $saved = false;
                set_transient( 'ssp_settings_error', __( 'No se pudo enviar la solicitud al servidor. Inténtalo de nuevo o contacta con soporte.', 'stock-sync-pro' ), 60 );
            }
        }

        // Sync updated config to Registry if Sync Engine is active.
        if ( ssp_autosync_is_active() ) {
            ssp_sync_config_to_registry();
        }
    }

    $stock_unknown = get_option( 'wevica_sync_stock_unknown', 'skip' );
    $dry_run       = get_option( 'wevica_sync_dry_run', '0' );
    $update_price  = get_option( 'wevica_sync_update_price', '0' );
    $retention     = get_option( 'wevica_sync_log_retention', '90' );

    // Cron data for view
    $cron_interval    = get_option( 'ssp_cron_interval', 'off' );
    $cron_source_url  = get_option( 'ssp_cron_source_url', '' );
    $cron_source_type = get_option( 'ssp_cron_source_type', 'auto' );
    $cron_tienda      = get_option( 'ssp_cron_tienda', 'cron' );
    $cron_col_sku     = get_option( 'ssp_cron_col_sku', 'sku' );
    $cron_col_stock   = get_option( 'ssp_cron_col_stock', 'stock' );
    $cron_col_price   = get_option( 'ssp_cron_col_price', 'precio' );
    $cron_next_run    = wp_next_scheduled( 'ssp_auto_sync' );

    // Webhook data for view
    $webhook_url         = get_option( 'ssp_webhook_url', '' );
    $webhook_secret      = get_option( 'ssp_webhook_secret', '' );
    $webhook_queue       = ssp_webhook_get_queue();
    $webhook_queue_count = count( $webhook_queue );
    $webhook_queue_next  = $webhook_queue_count > 0 ? min( array_column( $webhook_queue, 'next_retry' ) ) : 0;

    // Notification + exclusion data for view
    $notify_on_error        = get_option( 'ssp_notify_on_error', '1' );
    $notify_on_webhook_dead = get_option( 'ssp_notify_on_webhook_dead', '1' );
    $notify_email           = get_option( 'ssp_notify_email', '' );
    $exclude_skus           = get_option( 'ssp_exclude_skus', '' );

    // Sync Engine service state for feature-gating in view
    $cron_locked = ! ssp_autosync_is_active();

    // Proveedor — onboarding
    $supplier_url      = get_option( 'ssp_supplier_url', '' );
    $supplier_type   = get_option( 'ssp_supplier_type', '' );
    $supplier_notes  = get_option( 'ssp_supplier_notes', '' );
    $onboarding_sent = get_option( 'ssp_onboarding_submitted', '' );

    // Catalog source for view
    $catalog_sheets_id  = get_option( 'ssp_catalog_sheets_id', '' );
    $catalog_excel_hoja = get_option( 'ssp_catalog_excel_hoja', '' );
    $catalog_sheets_url = $catalog_sheets_id
        ? 'https://docs.google.com/spreadsheets/d/' . $catalog_sheets_id . '/edit'
        : '';

    include WEVICA_SYNC_DIR . 'views/settings.php';
}

/**
 * Envía los datos de onboarding del cliente al endpoint del propietario
 * para que pueda configurar el scraper personalizado.
 */
function ssp_send_onboarding_to_owner(): bool {
    $payload = [
        'site_url'          => home_url(),
        'supplier_url'      => get_option( 'ssp_supplier_url', '' ),
        'supplier_type'     => get_option( 'ssp_supplier_type', '' ),
        'notes'             => get_option( 'ssp_supplier_notes', '' ),
        'contact_email'     => get_bloginfo( 'admin_email' ),
        'catalog_sheets_id' => get_option( 'ssp_catalog_sheets_id', '' ),
    ];

    $response = wp_remote_post(
        SSP_ONBOARDING_URL,
        [
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
            'timeout' => 10,
        ]
    );

    if ( is_wp_error( $response ) ) {
        error_log( '[Stock Sync Pro] onboarding send failed: ' . $response->get_error_message() );
        return false;
    }

    return wp_remote_retrieve_response_code( $response ) === 200;
}

// ─────────────────────────────────────────────────────────────────
//  PÁGINA — CLAVES API (multi-key)
// ─────────────────────────────────────────────────────────────────

function ssp_page_apikeys() {
    if ( ! current_user_can( wevica_sync_capability() ) ) {
        wp_die( esc_html__( 'Sin permisos.', 'stock-sync-pro' ) );
    }
    $keys = ssp_get_api_keys();
    include WEVICA_SYNC_DIR . 'views/apikeys.php';
}

// ─────────────────────────────────────────────────────────────────
//  PÁGINA — LICENCIA
// ─────────────────────────────────────────────────────────────────

function ssp_page_license() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Sin permisos.', 'stock-sync-pro' ) );
    }
    include WEVICA_SYNC_DIR . 'views/license.php';
}

// ─────────────────────────────────────────────────────────────────
//  PÁGINA — ESTADO (health check)
// ─────────────────────────────────────────────────────────────────

function ssp_page_status() {
    if ( ! current_user_can( wevica_sync_capability() ) ) {
        wp_die( esc_html__( 'Sin permisos.', 'stock-sync-pro' ) );
    }

    global $wpdb;

    $checks = [];

    // WooCommerce
    $checks['woocommerce'] = [
        'label'  => 'WooCommerce',
        'ok'     => class_exists( 'WooCommerce' ),
        'detail' => class_exists( 'WooCommerce' ) ? ( 'v' . WC()->version ) : __( 'No instalado o inactivo', 'stock-sync-pro' ),
    ];

    // PHP version
    $php_ok = version_compare( PHP_VERSION, '7.4', '>=' );
    $checks['php'] = [
        'label'  => 'PHP',
        'ok'     => $php_ok,
        'detail' => PHP_VERSION,
    ];

    // WordPress version
    global $wp_version;
    $wp_ok = version_compare( $wp_version, '5.8', '>=' );
    $checks['wordpress'] = [
        'label'  => 'WordPress',
        'ok'     => $wp_ok,
        'detail' => 'v' . $wp_version,
    ];

    // DB table
    $table      = $wpdb->prefix . WEVICA_SYNC_TABLE;
    $table_ok   = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
    $checks['db_table'] = [
        'label'  => __( 'Tabla de logs', 'stock-sync-pro' ),
        'ok'     => $table_ok,
        'detail' => $table_ok ? $table : __( 'No existe — reactiva el plugin', 'stock-sync-pro' ),
    ];

    // Cron: auto-sync
    $cron_interval = get_option( 'ssp_cron_interval', 'off' );
    $cron_next     = wp_next_scheduled( 'ssp_auto_sync' );
    $cron_ok       = ( $cron_interval === 'off' ) || ( $cron_next !== false );
    $checks['cron_sync'] = [
        'label'  => __( 'Cron auto-sync', 'stock-sync-pro' ),
        'ok'     => $cron_ok,
        'detail' => $cron_interval === 'off'
            ? __( 'Desactivado', 'stock-sync-pro' )
            : ( $cron_next
                ? sprintf( __( 'Próx. ejecución: %s', 'stock-sync-pro' ), wp_date( 'd/m/Y H:i', $cron_next ) )
                : __( 'No programado — guarda los ajustes del cron', 'stock-sync-pro' ) ),
    ];

    // Cron: webhook retry
    $retry_next = wp_next_scheduled( 'ssp_webhook_retry' );
    $checks['cron_webhook'] = [
        'label'  => __( 'Cron webhook retry', 'stock-sync-pro' ),
        'ok'     => $retry_next !== false,
        'detail' => $retry_next
            ? sprintf( __( 'Próx. ejecución: %s', 'stock-sync-pro' ), wp_date( 'd/m/Y H:i', $retry_next ) )
            : __( 'No programado — guarda los ajustes para reprogramar', 'stock-sync-pro' ),
    ];

    // Webhook queue size
    $queue_size = count( ssp_webhook_get_queue() );
    $checks['webhook_queue'] = [
        'label'  => __( 'Cola de webhooks', 'stock-sync-pro' ),
        'ok'     => $queue_size < 10,
        'detail' => sprintf( _n( '%d pendiente', '%d pendientes', $queue_size, 'stock-sync-pro' ), $queue_size ),
    ];

    // License
    $licensed = ssp_is_licensed();
    $checks['license'] = [
        'label'  => __( 'Licencia', 'stock-sync-pro' ),
        'ok'     => $licensed,
        'detail' => $licensed ? __( 'Activa', 'stock-sync-pro' ) : __( 'Sin licencia activa (modo trial/expirado)', 'stock-sync-pro' ),
    ];

    // Memory limit
    $mem_limit  = ini_get( 'memory_limit' );
    $mem_bytes  = wp_convert_hr_to_bytes( $mem_limit );
    $checks['memory'] = [
        'label'  => __( 'Límite de memoria PHP', 'stock-sync-pro' ),
        'ok'     => $mem_bytes >= 64 * MB_IN_BYTES,
        'detail' => $mem_limit,
    ];

    // Sync Engine state & last sync
    $se_active  = ssp_autosync_is_active();
    $table      = $wpdb->prefix . WEVICA_SYNC_TABLE;
    $last_sync  = $wpdb->get_row( "SELECT * FROM {$table} ORDER BY fecha DESC LIMIT 1" );

    include WEVICA_SYNC_DIR . 'views/status.php';
}

// ─────────────────────────────────────────────────────────────────
//  PÁGINA — AYUDA
// ─────────────────────────────────────────────────────────────────

function ssp_page_help() {
    if ( ! current_user_can( wevica_sync_capability() ) ) {
        wp_die( esc_html__( 'Sin permisos.', 'stock-sync-pro' ) );
    }
    include WEVICA_SYNC_DIR . 'views/help.php';
}

// ═══════════════════════════════════════════════════════════════════
//  AJAX — EXPORTAR / IMPORTAR CONFIGURACIÓN
// ═══════════════════════════════════════════════════════════════════

add_action( 'wp_ajax_ssp_export_settings', 'ssp_ajax_export_settings' );

function ssp_ajax_export_settings(): void {
    check_ajax_referer( 'ssp_settings_io', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Sin permisos.', 'stock-sync-pro' ) ] );
    }

    $export_keys = [
        'wevica_sync_stock_unknown', 'wevica_sync_dry_run', 'wevica_sync_update_price',
        'wevica_sync_log_retention', 'wevica_sync_timeout_normal', 'wevica_sync_timeout_final',
        'wevica_sync_detail_limit', 'wevica_sync_json_max_size', 'ssp_cron_interval',
        'ssp_cron_source_url', 'ssp_cron_source_type', 'ssp_cron_tienda', 'ssp_cron_col_sku',
        'ssp_cron_col_stock', 'ssp_cron_col_price', 'ssp_webhook_url',
        'ssp_webhook_secret', 'ssp_notify_on_error', 'ssp_notify_on_webhook_dead',
        'ssp_notify_email', 'ssp_exclude_skus',
    ];

    $data = [ '_version' => WEVICA_SYNC_VERSION, '_exported_at' => gmdate( 'c' ) ];
    foreach ( $export_keys as $key ) {
        $data[ $key ] = get_option( $key, '' );
    }

    wp_send_json_success( [ 'json' => wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ] );
}

add_action( 'wp_ajax_ssp_import_settings', 'ssp_ajax_import_settings' );

function ssp_ajax_import_settings(): void {
    check_ajax_referer( 'ssp_settings_io', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Sin permisos.', 'stock-sync-pro' ) ] );
    }

    // wp_unslash only — sanitize_text_field strips tags and collapses whitespace,
    // which can corrupt valid JSON. Each individual value is sanitized below after decode.
    $raw  = wp_unslash( $_POST['json'] ?? '' );
    $data = json_decode( $raw, true );
    if ( ! is_array( $data ) ) {
        wp_send_json_error( [ 'message' => __( 'JSON inválido.', 'stock-sync-pro' ) ] );
    }

    $allowed = [
        'wevica_sync_stock_unknown' => 'text',
        'wevica_sync_dry_run'       => 'text',
        'wevica_sync_update_price'  => 'text',
        'wevica_sync_log_retention' => 'int',
        'ssp_cron_interval'         => 'text',
        'ssp_cron_source_url'       => 'url',
        'ssp_cron_source_type'      => 'text',
        'ssp_cron_tienda'           => 'text',
        'ssp_cron_col_sku'          => 'text',
        'ssp_cron_col_stock'        => 'text',
        'ssp_cron_col_price'        => 'text',
        'ssp_webhook_url'           => 'url',
        'ssp_webhook_secret'        => 'text',
        'ssp_notify_on_error'       => 'text',
        'ssp_notify_on_webhook_dead'=> 'text',
        'ssp_notify_email'          => 'email',
        'ssp_exclude_skus'          => 'textarea',
    ];

    foreach ( $allowed as $key => $type ) {
        if ( ! array_key_exists( $key, $data ) ) continue;
        $val = $data[ $key ];
        switch ( $type ) {
            case 'int':      $val = absint( $val ); break;
            case 'url':      $val = sanitize_url( $val ); break;
            case 'email':    $val = sanitize_email( $val ); break;
            case 'textarea': $val = sanitize_textarea_field( $val ); break;
            default:         $val = sanitize_text_field( $val );
        }
        update_option( $key, $val );
    }

    // Re-schedule cron if interval changed.
    ssp_setup_cron();

    wp_send_json_success( [ 'message' => __( 'Configuración importada correctamente.', 'stock-sync-pro' ) ] );
}

// ═══════════════════════════════════════════════════════════════════
//  HELPER — CARGA EN BULK DE DATOS DE PRODUCTOS (para vista detalle)
// ═══════════════════════════════════════════════════════════════════

/**
 * Carga en una sola pasada precios, thumbnails y títulos de los productos
 * referenciados en los items de la página actual del detalle.
 *
 * @param  array $page_items Items de la página actual (arrays con clave 'sku').
 * @return array             Mapa sku => [ pid, price, link, thumb_url, title ].
 */
function wevica_sync_load_product_data( array $page_items ): array {
    global $wpdb;

    $skus_to_load = [];
    foreach ( $page_items as $item ) {
        if ( is_array( $item ) && ! empty( $item['sku'] ) ) {
            $skus_to_load[] = $item['sku'];
        }
    }

    if ( empty( $skus_to_load ) ) {
        return [];
    }

    $placeholders = implode( ',', array_fill( 0, count( $skus_to_load ), '%s' ) );
    $query        = $wpdb->prepare(
        "SELECT pm.meta_value AS sku, pm.post_id
         FROM {$wpdb->postmeta} pm
         INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
         WHERE pm.meta_key = '_sku'
           AND pm.meta_value IN ($placeholders)
           AND p.post_status IN ('publish','draft','private')
         GROUP BY pm.meta_value",
        $skus_to_load
    );
    $sku_rows = $wpdb->get_results( $query );

    $pid_map = [];
    foreach ( $sku_rows as $row ) {
        $pid_map[ $row->sku ] = (int) $row->post_id;
    }

    if ( empty( $pid_map ) ) {
        return [];
    }

    $pids              = array_values( $pid_map );
    $pids_placeholders = implode( ',', array_fill( 0, count( $pids ), '%d' ) );

    // Precios.
    $price_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT post_id, meta_value FROM {$wpdb->postmeta}
         WHERE meta_key = '_price' AND post_id IN ($pids_placeholders)",
        $pids
    ) );
    $prices = [];
    foreach ( $price_rows as $pr ) {
        $prices[ (int) $pr->post_id ] = $pr->meta_value;
    }

    // Thumbnail IDs.
    $thumb_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT post_id, meta_value FROM {$wpdb->postmeta}
         WHERE meta_key = '_thumbnail_id' AND post_id IN ($pids_placeholders)",
        $pids
    ) );
    $thumb_ids = [];
    foreach ( $thumb_rows as $tr ) {
        $thumb_ids[ (int) $tr->post_id ] = (int) $tr->meta_value;
    }

    // URLs de thumbnails (una sola query).
    $thumb_urls    = [];
    $all_thumb_ids = array_unique( array_values( $thumb_ids ) );
    if ( ! empty( $all_thumb_ids ) ) {
        $thumb_placeholders = implode( ',', array_fill( 0, count( $all_thumb_ids ), '%d' ) );
        $thumb_url_rows     = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, meta_value FROM {$wpdb->postmeta}
             WHERE meta_key = '_wp_attached_file' AND post_id IN ($thumb_placeholders)",
            $all_thumb_ids
        ) );
        $upload_dir = wp_get_upload_dir();
        foreach ( $thumb_url_rows as $tur ) {
            $thumb_urls[ (int) $tur->post_id ] = $upload_dir['baseurl'] . '/' . $tur->meta_value;
        }
    }

    // Títulos.
    $title_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT ID, post_title FROM {$wpdb->posts} WHERE ID IN ($pids_placeholders)",
        $pids
    ) );
    $titles = [];
    foreach ( $title_rows as $trow ) {
        $titles[ (int) $trow->ID ] = $trow->post_title;
    }

    // Construir mapa final.
    $product_data_map = [];
    foreach ( $pid_map as $sku => $pid ) {
        $tid = $thumb_ids[ $pid ] ?? 0;
        $product_data_map[ $sku ] = [
            'pid'       => $pid,
            'price'     => $prices[ $pid ] ?? '',
            'link'      => get_permalink( $pid ),
            'thumb_url' => $tid ? ( $thumb_urls[ $tid ] ?? '' ) : '',
            'title'     => $titles[ $pid ] ?? '',
        ];
    }

    return $product_data_map;
}

// ═══════════════════════════════════════════════════════════════════
//  LIMPIEZA AUTOMÁTICA DE LOGS ANTIGUOS
// ═══════════════════════════════════════════════════════════════════

add_action( 'wp', 'wevica_sync_schedule_cleanup' );

function wevica_sync_schedule_cleanup() {
    if ( ! wp_next_scheduled( 'wevica_sync_cleanup_logs' ) ) {
        wp_schedule_event( time(), 'daily', 'wevica_sync_cleanup_logs' );
    }
}

add_action( 'wevica_sync_cleanup_logs', 'wevica_sync_do_cleanup' );

function wevica_sync_do_cleanup() {
    global $wpdb;
    $table     = $wpdb->prefix . WEVICA_SYNC_TABLE;
    $retention = (int) get_option( 'wevica_sync_log_retention', 90 );

    $wpdb->query( $wpdb->prepare(
        "DELETE FROM {$table} WHERE fecha < DATE_SUB(NOW(), INTERVAL %d DAY)",
        $retention
    ) );
}

// ═══════════════════════════════════════════════════════════════════
//  ENLACE DE AJUSTES DESDE LA LISTA DE PLUGINS
// ═══════════════════════════════════════════════════════════════════

add_filter( 'plugin_action_links_' . plugin_basename( WEVICA_SYNC_FILE ), 'wevica_sync_action_links' );

function wevica_sync_action_links( $links ) {
    $settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=wevica-sync-settings' ) ) . '">Ajustes</a>';
    array_unshift( $links, $settings_link );
    return $links;
}

// ═══════════════════════════════════════════════════════════════════
//  AUTO-ACTUALIZACIÓN
// ═══════════════════════════════════════════════════════════════════

// ── Capa 1: forzar filesystem 'direct' para nuestro plugin ────────
// Evita que WP pida credenciales FTP cuando los archivos son del usuario web.
add_filter( 'filesystem_method', function( $method, $args, $context ) {
    $context = (string) $context;
    if ( $context !== '' && (
        strpos( $context, WP_CONTENT_DIR . '/upgrade' ) === 0 ||
        strpos( $context, WP_PLUGIN_DIR ) === 0
    ) ) {
        return 'direct';
    }
    return $method;
}, 10, 3 );

// ── Capa 2: neutralizar el error "upgrade-temp-backup" de WP 6.3+ ─
// WordPress 6.3 introdujo un paso de backup previo a la actualización
// que mueve el plugin a wp-content/upgrade-temp-backup/. En hosts con
// permisos restrictivos esta operación falla y bloquea toda actualización.
// Este filtro hace que el backup de nuestro plugin siempre "tenga éxito"
// sin mover nada, saltándose el paso problemático.
add_filter( 'pre_move_dir', function( $move, $from, $to, $overwrite ) {
    if (
        strpos( (string) $to,   'upgrade-temp-backup' ) !== false &&
        strpos( (string) $from, 'wevica-stock-sync'   ) !== false
    ) {
        return true; // Simular éxito — skip backup
    }
    return $move;
}, 10, 4 );

// ── Capa 3: updater propio con ZipArchive ─────────────────────────
// Bypassa WP_Filesystem completamente. Descarga el ZIP y lo extrae
// con ZipArchive nativo de PHP, que corre con el mismo usuario que
// los archivos del plugin, eliminando cualquier problema de permisos.
function ssp_do_direct_update( string $download_url ): true|WP_Error {
    // 1. Descargar ZIP a archivo temporal
    $tmp = wp_tempnam( 'ssp-update' );
    $response = wp_remote_get( $download_url, [
        'timeout'  => 60,
        'stream'   => true,
        'filename' => $tmp,
    ] );

    if ( is_wp_error( $response ) ) {
        @unlink( $tmp );
        return new WP_Error( 'download_failed', 'Error descargando la actualización: ' . $response->get_error_message() );
    }

    $code = (int) wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
        @unlink( $tmp );
        return new WP_Error( 'download_failed', "El servidor de actualizaciones devolvió HTTP {$code}." );
    }

    // 2. Extraer con ZipArchive (sin WP_Filesystem — usa el usuario de PHP directamente)
    if ( ! class_exists( 'ZipArchive' ) ) {
        @unlink( $tmp );
        return new WP_Error( 'no_zip', 'La extensión ZipArchive no está disponible en este servidor. Contacta con tu hosting.' );
    }

    $zip    = new ZipArchive();
    $opened = $zip->open( $tmp );
    if ( $opened !== true ) {
        @unlink( $tmp );
        return new WP_Error( 'zip_open_failed', 'No se pudo abrir el archivo ZIP de actualización (código: ' . $opened . ').' );
    }

    $extracted = $zip->extractTo( WP_PLUGIN_DIR );
    $zip->close();
    @unlink( $tmp );

    if ( ! $extracted ) {
        return new WP_Error( 'extract_failed', 'No se pudieron extraer los archivos. Verifica los permisos de wp-content/plugins/.' );
    }

    // 3. Limpiar cachés de WordPress
    delete_transient( 'ssp_update_info_vercel' );
    wp_clean_plugins_cache( true );

    return true;
}

// AJAX handler: actualización manual desde el panel de Stock Sync Pro
add_action( 'wp_ajax_ssp_do_update', function () {
    check_ajax_referer( 'ssp_do_update', 'nonce' );

    if ( ! current_user_can( 'update_plugins' ) ) {
        wp_send_json_error( [ 'message' => 'No tienes permisos para actualizar plugins.' ] );
    }

    $info = ssp_fetch_update_info();
    if ( ! $info || empty( $info['download_url'] ) ) {
        wp_send_json_error( [ 'message' => 'No hay actualización disponible en este momento.' ] );
    }

    $result = ssp_do_direct_update( $info['download_url'] );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    wp_send_json_success( [
        'message' => 'Plugin actualizado a v' . esc_html( $info['version'] ) . '. La página se recargará.',
        'version' => $info['version'],
    ] );
} );

// Interceptar upgrader nativo: si el ZIP ya está descargado por WP,
// usar ZipArchive para la extracción en vez de WP_Filesystem.
add_filter( 'upgrader_pre_install', function( $response, $hook_extra ) {
    $plugin_file = plugin_basename( WEVICA_SYNC_FILE );
    if ( ( $hook_extra['plugin'] ?? '' ) !== $plugin_file ) {
        return $response;
    }
    // Asegurar que upgrade-temp-backup existe y tiene permisos
    $backup_dir = WP_CONTENT_DIR . '/upgrade-temp-backup/plugins';
    if ( ! file_exists( $backup_dir ) ) {
        wp_mkdir_p( $backup_dir );
    }
    return $response;
}, 10, 2 );

add_filter( 'pre_set_site_transient_update_plugins', 'wevica_sync_check_update' );

function wevica_sync_check_update( $transient ) {
    if ( empty( $transient->checked ) ) {
        return $transient;
    }

    $plugin_file = plugin_basename( WEVICA_SYNC_FILE );

    // Verificar que nuestra versión esté en la lista de revisados
    if ( ! isset( $transient->checked[ $plugin_file ] ) ) {
        return $transient;
    }

    // Usa el servidor Vercel: no requiere token por usuario, autenticación server-side.
    $info = ssp_fetch_update_info();
    if ( ! $info || empty( $info['version'] ) || empty( $info['download_url'] ) ) {
        return $transient;
    }

    // Comparar versiones: si hay una versión más nueva, agregar al transient
    if ( version_compare( $info['version'], WEVICA_SYNC_VERSION, '>' ) ) {
        // Asegurar que response sea un array
        if ( ! is_object( $transient->response ) && ! is_array( $transient->response ) ) {
            $transient->response = [];
        }

        $transient->response[ $plugin_file ] = (object) [
            'id'           => 'wevica-stock-sync/wevica-stock-sync',
            'slug'         => 'wevica-stock-sync',
            'plugin'       => $plugin_file,
            'new_version'  => $info['version'],
            'url'          => $info['details_url'],
            'package'      => $info['download_url'],
            'icons'        => [],
            'banners'      => [],
            'requires'     => '5.8',
            'tested'       => '6.7',
            'requires_php' => '7.4',
        ];
    } else {
        // Si estamos al día, eliminar de response si existe
        if ( isset( $transient->response[ $plugin_file ] ) ) {
            unset( $transient->response[ $plugin_file ] );
        }
    }

    return $transient;
}

add_filter( 'plugins_api', 'wevica_sync_plugin_info', 20, 3 );

function wevica_sync_plugin_info( $result, $action, $args ) {
    if ( $action !== 'plugin_information' || ( $args->slug ?? '' ) !== 'wevica-stock-sync' ) {
        return $result;
    }

    $info = ssp_fetch_update_info();
    if ( ! $info ) {
        // Retornar un objeto con la versión actual si GitHub falla
        return (object) [
            'name'          => 'Stock Sync Pro',
            'slug'          => 'wevica-stock-sync',
            'version'       => WEVICA_SYNC_VERSION,
            'author'        => 'Alejandro Chacón',
            'homepage'      => 'https://wevica.com',
            'download_link' => '',
            'sections'      => [
                'description' => 'Sync WooCommerce stock from any external source via a secure REST API, CSV import, configurable cron and webhooks.',
                'changelog'   => 'No changelog available. Check GitHub releases at https://github.com/PresiDeWitt/wevica-plugin/releases',
            ],
            'last_updated'  => gmdate( 'Y-m-d H:i:s' ),
            'requires'      => '5.8',
            'tested'        => '6.7',
        ];
    }

    return (object) [
        'name'          => 'Stock Sync Pro',
        'slug'          => 'wevica-stock-sync',
        'version'       => $info['version'],
        'author'        => '<a href="https://wevica.com">Alejandro Chacón — Wévica</a>',
        'homepage'      => 'https://stocksyncpro.com',
        'last_updated'  => $info['last_updated'],
        'download_link' => $info['download_url'],
        'requires'      => '5.8',
        'tested'        => '6.7',
        'requires_php'  => '7.4',
        'sections'      => [
            'description' => '<p>Stock Sync Pro sincroniza automáticamente el stock de WooCommerce desde cualquier fuente externa (scrapers, ERPs, feeds de precio, CSV/Excel) via REST API segura con multi-clave, cron, webhooks y plan de suscripción.</p>',
            'changelog'   => $info['changelog'],
        ],
    ];
}

// Limpiar caché de actualización tras instalar el plugin.
add_action( 'upgrader_process_complete', function ( $upgrader, $hook_extra ) {
    if ( isset( $hook_extra['plugins'] ) && in_array( plugin_basename( WEVICA_SYNC_FILE ), $hook_extra['plugins'], true ) ) {
        delete_transient( 'ssp_update_info_vercel' );
    }
}, 10, 2 );
