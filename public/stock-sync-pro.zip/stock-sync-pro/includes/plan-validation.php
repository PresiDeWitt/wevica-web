<?php
/**
 * Stock Sync Pro — Plan Validation & Access Control.
 *
 * Middleware for API endpoints to enforce plan limits and feature access.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Plan-based Access Control ────────────────────────────────────────────────

/**
 * Check if current site has access to a specific feature.
 *
 * @param  string $feature Feature slug (api_calls, webhooks, custom_scrapers, etc.).
 * @param  int    $amount  Amount to check (for lookahead validation).
 * @return WP_Error|true WP_Error if feature unavailable or limit exceeded, true otherwise.
 */
function ssp_check_feature_access( string $feature, int $amount = 1 ) {
	$plan = ssp_get_current_plan();

	// Check if feature exists in plan
	if ( ! ssp_plan_has_feature( $plan, $feature ) ) {
		return new WP_Error(
			'plan_feature_unavailable',
			sprintf(
				__( 'The %s feature is not available in your %s plan. Please upgrade to access this feature.', 'stock-sync-pro' ),
				$feature,
				ucfirst( $plan )
			),
			[ 'status' => 403 ]
		);
	}

	// Check usage limits
	if ( ! ssp_check_usage_limit( $feature, $amount ) ) {
		$config = ssp_get_plan_config( $plan );
		$limit  = $config[ "{$feature}_monthly" ] ?? 0;
		$used   = ssp_get_usage( $feature );

		return new WP_Error(
			'plan_limit_exceeded',
			sprintf(
				__( 'Your %s plan limit has been exceeded. Used: %d/%d. Please upgrade or wait for your billing cycle to reset.', 'stock-sync-pro' ),
				ucfirst( $plan ),
				$used,
				$limit
			),
			[ 'status' => 429 ]
		);
	}

	return true;
}

/**
 * REST API middleware - validate plan for endpoint.
 * Add to permission_callback in register_rest_route.
 *
 * @param  string $feature Feature to require.
 * @return callable Permission callback function.
 */
function ssp_get_plan_permission_callback( string $feature ): callable {
	return function () use ( $feature ) {
		// Already authenticated via API key in wevica_sync_api_auth()
		// This just checks plan limits

		$check = ssp_check_feature_access( $feature );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		return true;
	};
}

// ── API Endpoint Wrappers ──────────────────────────────────────────────────

/**
 * Wrapper for sync endpoints - tracks usage and enforces limits.
 *
 * @param  array $productos Products to sync.
 * @param  string $tienda Store name.
 * @return WP_Error|array Error or sync result.
 */
function ssp_api_sync_with_limits( array $productos, string $tienda = '' ): array|WP_Error {
	$product_count = count( $productos );

	// Check if we can sync this amount
	$can_sync = ssp_check_feature_access( 'products', $product_count );
	if ( is_wp_error( $can_sync ) ) {
		return $can_sync;
	}

	// Perform sync
	$result = wevica_sync_process_json( $productos, $tienda, 'api' );

	// Track usage if successful
	if ( ! isset( $result['error'] ) && isset( $result['actualizados'] ) ) {
		ssp_increment_usage( 'products', $product_count );
		ssp_increment_usage( 'api_calls', 1 );
	}

	return $result;
}

/**
 * Wrapper for CSV sync - tracks usage and enforces limits.
 *
 * @param  string $csv_path Path to CSV file.
 * @param  string $tienda Store name.
 * @return WP_Error|array Error or sync result.
 */
function ssp_api_sync_csv_with_limits( string $csv_path, string $tienda = '' ): array|WP_Error {
	// Check CSV feature access
	$can_sync = ssp_check_feature_access( 'api_calls' );
	if ( is_wp_error( $can_sync ) ) {
		return $can_sync;
	}

	// Perform sync
	$result = wevica_sync_process_csv( $csv_path, $tienda, 'api' );

	// Track usage if successful
	if ( ! isset( $result['error'] ) && isset( $result['total'] ) ) {
		ssp_increment_usage( 'products', $result['total'] );
		ssp_increment_usage( 'api_calls', 1 );
	}

	return $result;
}

// ── Dashboard Helper Functions ────────────────────────────────────────────

/**
 * Get usage stats for dashboard.
 *
 * @return array Usage data with percentages.
 */
function ssp_get_usage_stats(): array {
	$plan   = ssp_get_current_plan();
	$config = ssp_get_plan_config( $plan );

	if ( ! $config ) {
		return [];
	}

	$stats = [
		'plan'     => $plan,
		'features' => [],
	];

	$tracked_features = [ 'products', 'api_calls', 'api_keys' ];

	foreach ( $tracked_features as $feature ) {
		$limit_key = "{$feature}_monthly";
		$limit     = $config[ $limit_key ] ?? 0;

		if ( $limit === 0 ) {
			continue;
		}

		$used       = ssp_get_usage( $feature );
		$percentage = round( ( $used / $limit ) * 100, 1 );

		$stats['features'][ $feature ] = [
			'used'       => $used,
			'limit'      => $limit,
			'percentage' => $percentage,
			'status'     => $percentage >= 90 ? 'critical' : ( $percentage >= 70 ? 'warning' : 'ok' ),
		];
	}

	return $stats;
}

/**
 * Get formatted usage message for admin notice.
 *
 * @return string|null HTML message or null if plan is free.
 */
function ssp_get_usage_notice(): ?string {
	$plan = ssp_get_current_plan();

	if ( $plan === 'free' ) {
		return null;
	}

	$stats = ssp_get_usage_stats();

	if ( empty( $stats['features'] ) ) {
		return null;
	}

	$html = '<div class="notice notice-info"><p>';
	$html .= '📊 <strong>Usage this month:</strong><br>';

	foreach ( $stats['features'] as $feature => $data ) {
		$color = $data['status'] === 'critical' ? '#dc2626' : ( $data['status'] === 'warning' ? '#ea580c' : '#16a34a' );
		$html .= sprintf(
			'%s: <span style="color: %s;"><strong>%d/%d</strong> (%d%%)</span><br>',
			esc_html( ucfirst( str_replace( '_', ' ', $feature ) ) ),
			esc_attr( $color ),
			(int) $data['used'],
			(int) $data['limit'],
			(int) $data['percentage']
		);
	}

	$html .= '</p></div>';

	return $html;
}

// ── API Key Management by Plan ─────────────────────────────────────────────

/**
 * Check if site can create new API key based on plan.
 *
 * @return WP_Error|true WP_Error if limit reached, true if allowed.
 */
function ssp_can_create_api_key(): WP_Error|bool {
	$plan   = ssp_get_current_plan();
	$config = ssp_get_plan_config( $plan );
	$limit  = $config['api_keys'] ?? 1;

	$keys  = ssp_get_api_keys();
	$count = count( $keys );

	if ( $count >= $limit ) {
		return new WP_Error(
			'api_key_limit_exceeded',
			sprintf(
				__( 'You can only create %d API key(s) in your %s plan.', 'stock-sync-pro' ),
				$limit,
				ucfirst( $plan )
			)
		);
	}

	return true;
}

/**
 * Check if site can use webhooks based on plan.
 *
 * @return WP_Error|true WP_Error if feature unavailable, true if allowed.
 */
function ssp_can_use_webhooks(): WP_Error|bool {
	return ssp_check_feature_access( 'webhooks' );
}

/**
 * Check if site can use custom scrapers based on plan.
 *
 * @return WP_Error|true WP_Error if feature unavailable, true if allowed.
 */
function ssp_can_use_custom_scrapers(): WP_Error|bool {
	return ssp_check_feature_access( 'custom_scrapers' );
}

// ── Display Plan Info in Admin ────────────────────────────────────────────

/**
 * Display plan info in dashboard.
 */
function ssp_display_plan_info_in_dashboard() {
	$plan = ssp_get_current_plan();
	$sub  = ssp_get_subscription();

	if ( $plan === 'free' ) {
		return;
	}

	$config = ssp_get_plan_config( $plan );
	?>
	<div class="wv-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; margin-bottom: 30px;">
		<div style="display: flex; justify-content: space-between; align-items: center;">
			<div>
				<h2 style="color: white; margin: 0 0 10px 0;">
					🎉 <?php echo esc_html( ucfirst( $plan ) ); ?> Plan Active
				</h2>
				<p style="margin: 0; opacity: 0.9;">
					<?php
					if ( $sub && $sub->next_billing_date ) {
						printf(
							'Next billing: %s',
							date_i18n( 'Y-m-d', strtotime( $sub->next_billing_date ) )
						);
					}
					?>
				</p>
			</div>
			<div style="text-align: right;">
				<div style="font-size: 32px; margin-bottom: 5px;">
					<?php echo $plan === 'pro' ? '👑' : '⭐'; // phpcs:ignore WordPress.Security.EscapeOutput -- emoji literal ?>
				</div>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-billing' ) ); ?>" class="button button-primary" style="background: white; color: #667eea; border: none;">
					Manage Subscription
				</a>
			</div>
		</div>
	</div>
	<?php
}

add_action( 'wevica_sync_dashboard_top', 'ssp_display_plan_info_in_dashboard' );

// ── Upgrade Prompts ────────────────────────────────────────────────────────

/**
 * Show upgrade prompt when feature is unavailable.
 *
 * @param  string $feature Feature name.
 * @param  string $plan_required Plan needed for feature.
 */
function ssp_show_upgrade_prompt( string $feature, string $plan_required = 'starter' ) {
	$config = ssp_get_plan_config( $plan_required );
	if ( ! $config ) {
		return;
	}

	?>
	<div class="notice notice-warning">
		<p>
			<strong>🚀 Upgrade to access <?php echo esc_html( ucfirst( $feature ) ); ?></strong><br>
			Your current plan doesn't support this feature. Upgrade to <?php echo esc_html( ucfirst( $plan_required ) ); ?> or higher to enable it.
			<br><br>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-billing' ) ); ?>" class="button button-primary">
				View Plans & Pricing
			</a>
		</p>
	</div>
	<?php
}

