<?php
/**
 * Stock Sync Pro — Sync Engine Billing Dashboard.
 *
 * Shows the Sync Engine subscription status.
 * The plugin itself is free — no plugin license required.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Register billing page
add_action( 'admin_menu', function() {
	add_submenu_page(
		'wevica-sync',
		'Facturación',
		'Facturación',
		'manage_options',
		'ssp-billing',
		'ssp_render_billing_page'
	);
}, 999 );

/**
 * Render Sync Engine billing dashboard.
 */
function ssp_render_billing_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'No tienes permisos.', 'stock-sync-pro' ) );
	}

	$autosync_active = ssp_autosync_is_active();
	$se_key          = get_option( 'ssp_syncengine_key', '' );
	?>

	<div class="wevica-wrap">
		<!-- Page Header -->
		<div class="wv-page-header">
			<div class="wv-page-header-left">
				<div>
					<h1 class="wv-page-title"><?php esc_html_e( 'Sync Engine', 'stock-sync-pro' ); ?></h1>
					<p class="wv-page-subtitle"><?php esc_html_e( 'Gestiona tu suscripción al servicio de sincronización automática', 'stock-sync-pro' ); ?></p>
				</div>
			</div>
		</div>

		<!-- Sync Engine Status Card -->
		<div class="wv-panel wv-fade-in" style="margin-bottom: 28px;">
			<div class="wv-panel-header">
				<h2 class="wv-panel-title">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 20 20" fill="currentColor" style="color:var(--wv-primary)"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
					<?php esc_html_e( 'Estado del Sync Engine', 'stock-sync-pro' ); ?>
				</h2>
				<?php if ( $autosync_active ) : ?>
					<span class="wv-badge" style="background:#f0fdf4;color:#16a34a;">
						<?php esc_html_e( 'ACTIVO', 'stock-sync-pro' ); ?>
					</span>
				<?php else : ?>
					<span class="wv-badge" style="background:#fef2f2;color:#dc2626;">
						<?php esc_html_e( 'NO ACTIVO', 'stock-sync-pro' ); ?>
					</span>
				<?php endif; ?>
			</div>
			<div class="wv-info-grid">
				<div class="wv-info-grid-item">
					<div class="wv-info-label"><?php esc_html_e( 'Servicio', 'stock-sync-pro' ); ?></div>
					<div class="wv-info-value" style="font-size: 18px; font-weight: 600; color: <?php echo $autosync_active ? 'var(--wv-success)' : 'var(--wv-error)'; ?>;">
						<?php echo $autosync_active ? esc_html__( 'Activo', 'stock-sync-pro' ) : esc_html__( 'Inactivo', 'stock-sync-pro' ); ?>
					</div>
				</div>
				<?php if ( $autosync_active && $se_key ) : ?>
				<div class="wv-info-grid-item">
					<div class="wv-info-label"><?php esc_html_e( 'Clave activada', 'stock-sync-pro' ); ?></div>
					<div class="wv-info-value" style="font-family: monospace; font-size: 13px; color: var(--wv-gray-700);">
						<?php echo esc_html( substr( $se_key, 0, 8 ) . str_repeat( '•', max( 0, strlen( $se_key ) - 12 ) ) . substr( $se_key, -4 ) ); ?>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>

		<!-- Info Alert -->
		<div style="background: var(--wv-primary-light); border-left: 4px solid var(--wv-primary); border-radius: var(--wv-radius-lg); padding: 20px; margin-bottom: 28px;">
			<h3 style="margin: 0 0 8px; color: var(--wv-gray-900); font-size: 16px; font-weight: 600;">
				<?php esc_html_e( 'El plugin es gratuito', 'stock-sync-pro' ); ?>
			</h3>
			<p style="margin: 0 0 8px; color: var(--wv-gray-700); font-size: 14px; line-height: 1.6;">
				<?php esc_html_e( 'Stock Sync Pro no requiere licencia. Puedes usarlo libremente para sincronizar stock vía API.', 'stock-sync-pro' ); ?>
			</p>
			<p style="margin: 0; color: var(--wv-gray-700); font-size: 14px; line-height: 1.6;">
				<?php esc_html_e( 'El Sync Engine es un servicio de pago opcional que automatiza la extracción de stock desde tu proveedor. Contrata un plan y recibirás tu clave por email.', 'stock-sync-pro' ); ?>
			</p>
		</div>

		<!-- CTA Buttons -->
		<div style="display: flex; gap: 12px; flex-wrap: wrap;">
			<?php if ( $autosync_active ) : ?>
			<a href="https://app.lemonsqueezy.com/billing" target="_blank" class="wv-btn wv-btn-primary">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width: 16px; height: 16px;"><path d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z"/></svg>
				<?php esc_html_e( 'Portal de facturación', 'stock-sync-pro' ); ?>
			</a>
			<?php else : ?>
			<a href="<?php echo esc_url( SSP_SYNCENGINE_PURCHASE_URL ); ?>" target="_blank" class="wv-btn wv-btn-primary">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width: 16px; height: 16px;"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3z"/></svg>
				<?php esc_html_e( 'Ver planes del Sync Engine →', 'stock-sync-pro' ); ?>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-license' ) ); ?>" class="wv-btn wv-btn-secondary">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width: 16px; height: 16px;"><path fill-rule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 2 2 0 012 2 1 1 0 102 0 4 4 0 00-4-4z" clip-rule="evenodd"/></svg>
				<?php esc_html_e( 'Activar Sync Engine', 'stock-sync-pro' ); ?>
			</a>
			<?php endif; ?>
		</div>
	</div>
	<?php
}
