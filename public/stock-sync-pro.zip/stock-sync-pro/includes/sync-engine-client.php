<?php
/**
 * Sync Engine Client — Comunicación con el Python engine en VPS.
 *
 * Este archivo maneja toda la comunicación con el motor de sincronización
 * en Python que corre en un VPS externo. El plugin NO procesa datos,
 * solo orquesta llamadas al engine.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** URL del Registry en Vercel. */
const SSP_REGISTRY_URL = 'https://wevica-plugin.vercel.app';

/**
 * Obtener la configuración del motor desde el Registry de Vercel.
 *
 * Llama a /api/config/engine con site_url + se_key + site_hash y recibe
 * { engine_url, engine_key }.
 * El resultado se cachea en un transient de 23 horas para no llamar al Registry
 * en cada request. Si el Registry no está disponible, retorna el último valor
 * cacheado o array vacío.
 *
 * @param  bool $force_refresh Forzar una nueva llamada al Registry ignorando la caché.
 * @return array { engine_url: string, engine_key: string } o array vacío si no disponible.
 */
function ssp_get_engine_config( bool $force_refresh = false ): array {
    if ( ! $force_refresh ) {
        $cached = get_transient( 'ssp_engine_config' );
        if ( is_array( $cached ) && ! empty( $cached['engine_url'] ) ) {
            return $cached;
        }
    }

    $se_key    = (string) get_option( 'ssp_syncengine_key', '' );
    $site_hash = (string) get_option( 'ssp_registry_site_hash', '' );
    if ( empty( $se_key ) || empty( $site_hash ) ) {
        return [];
    }

    $response = wp_remote_post(
        SSP_REGISTRY_URL . '/api/config/engine',
        [
            'timeout'   => 10,
            'sslverify' => true,
            'headers'   => [ 'Content-Type' => 'application/json' ],
            'body'      => wp_json_encode( [
                'site_url'  => home_url(),
                'se_key'    => $se_key,
                'site_hash' => $site_hash,
            ] ),
        ]
    );

    if ( is_wp_error( $response ) ) {
        return [];
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( 200 !== $code ) {
        // Trial expirado u otro error — no cachear, retornar vacío.
        return [];
    }

    $data = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( empty( $data['engine_url'] ) || empty( $data['engine_key'] ) ) {
        return [];
    }

    $config = [
        'engine_url' => $data['engine_url'],
        'engine_key' => $data['engine_key'],
    ];

    set_transient( 'ssp_engine_config', $config, 23 * HOUR_IN_SECONDS );
    return $config;
}

/**
 * Obtener la URL del motor de sincronización.
 *
 * @return string|null URL sin trailing slash, o null si no disponible.
 */
function ssp_get_syncengine_url(): ?string {
    $config = ssp_get_engine_config();
    if ( empty( $config['engine_url'] ) ) {
        return null;
    }
    return untrailingslashit( $config['engine_url'] );
}

/**
 * Obtener la clave de autenticación del motor.
 *
 * @return string Clave, o cadena vacía si no disponible.
 */
function ssp_get_engine_api_key(): string {
    $config = ssp_get_engine_config();
    return $config['engine_key'] ?? '';
}

/**
 * Verificar si el motor de sincronización está configurado y disponible.
 *
 * @return bool
 */
function ssp_has_syncengine_configured(): bool {
    return ! empty( ssp_get_syncengine_url() );
}

/**
 * Probar la conexión con el motor de sincronización.
 *
 * @return array ['success' => bool, 'message' => string, 'version' => string|null]
 */
function ssp_test_syncengine_connection() {
    $url = ssp_get_syncengine_url();
    if ( empty( $url ) ) {
        return [
            'success' => false,
            'message' => 'Motor de sincronización no configurado.',
            'version' => null,
        ];
    }

    $response = wp_remote_post(
        $url . '/health',
        [
            'timeout'   => 10,
            'sslverify' => true,
            'headers'   => [
                'Content-Type' => 'application/json',
            ],
        ]
    );

    if ( is_wp_error( $response ) ) {
        return [
            'success' => false,
            'message' => 'Error de conexión: ' . $response->get_error_message(),
            'version' => null,
        ];
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = wp_remote_retrieve_body( $response );

    if ( 200 !== $code ) {
        return [
            'success' => false,
            'message' => "Respuesta del servidor: HTTP $code",
            'version' => null,
        ];
    }

    $data = json_decode( $body, true );
    if ( ! is_array( $data ) || empty( $data['version'] ) ) {
        return [
            'success' => false,
            'message' => 'Respuesta inválida del motor.',
            'version' => null,
        ];
    }

    return [
        'success' => true,
        'message' => 'Motor accesible.',
        'version' => $data['version'],
    ];
}

/**
 * Sincronizar productos mediante JSON al motor de sincronización.
 *
 * @param array  $productos   Array de productos con sku, stock, precio, etc.
 * @param string $tienda      Nombre de la tienda.
 * @param string $tipo        Tipo de sync ('api', 'cron', 'manual').
 * @param bool   $dry_run     Si es true, no actualizar, solo previsualizar.
 * @return array Resultado con claves: total, actualizados, sin_sku, errores, detalles, dry_run.
 */
function ssp_sync_via_engine_json( $productos, $tienda = '', $tipo = 'api', $dry_run = false ) {
    $url = ssp_get_syncengine_url();
    if ( empty( $url ) ) {
        return [
            'error' => 'Motor de sincronización no configurado. Contacta al administrador.',
        ];
    }

    if ( ! function_exists( 'wc_get_product_id_by_sku' ) ) {
        return [ 'error' => 'WooCommerce no está activo.' ];
    }

    $payload = [
        'tienda'    => $tienda,
        'tipo'      => $tipo,
        'dry_run'   => (bool) $dry_run,
        'productos' => $productos,
    ];

    $response = wp_remote_post(
        $url . '/sync',
        [
            'timeout'   => 300, // 5 minutos
            'sslverify' => true,
            'headers'   => [
                'Content-Type'    => 'application/json',
                'User-Agent'      => 'WordPress Stock Sync Pro / ' . WEVICA_SYNC_VERSION,
                'X-StockSync-Key' => ssp_get_engine_api_key(),
            ],
            'body'      => wp_json_encode( $payload ),
        ]
    );

    if ( is_wp_error( $response ) ) {
        return [
            'error' => 'Error de conexión con motor: ' . $response->get_error_message(),
        ];
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = wp_remote_retrieve_body( $response );

    if ( 200 !== $code ) {
        $error_msg = "HTTP $code";
        $data = json_decode( $body, true );
        if ( is_array( $data ) && ! empty( $data['error'] ) ) {
            $error_msg .= ': ' . $data['error'];
        }
        return [ 'error' => $error_msg ];
    }

    $result = json_decode( $body, true );
    if ( ! is_array( $result ) ) {
        return [
            'error' => 'Respuesta inválida del motor de sincronización.',
        ];
    }

    return $result;
}

/**
 * Sincronizar productos mediante CSV al motor de sincronización.
 *
 * @param string $csv_path    Ruta absoluta al archivo CSV.
 * @param string $tienda      Nombre de la tienda.
 * @param string $tipo        Tipo de sync ('manual', 'api', 'cron').
 * @param array  $col_map     Mapeo de columnas: ['sku' => 'col_name', 'stock' => 'col_name', ...]
 * @param bool   $dry_run     Si es true, no actualizar, solo previsualizar.
 * @return array Resultado con claves: total, actualizados, sin_sku, errores, detalles, dry_run.
 */
function ssp_sync_via_engine_csv( $csv_path, $tienda = '', $tipo = 'manual', $col_map = [], $dry_run = null ) {
    $url = ssp_get_syncengine_url();
    if ( empty( $url ) ) {
        return [
            'error' => 'Motor de sincronización no configurado. Contacta al administrador.',
        ];
    }

    // Validar que el archivo esté dentro del directorio de uploads de WordPress
    // para prevenir path traversal (lectura de wp-config.php, /etc/passwd, etc.)
    $real_path   = realpath( $csv_path );
    $upload_dir  = realpath( wp_upload_dir()['basedir'] );
    if ( ! $real_path || ! $upload_dir || strncmp( $real_path, $upload_dir, strlen( $upload_dir ) ) !== 0 ) {
        return [ 'error' => 'Ruta de archivo CSV no permitida.' ];
    }

    if ( ! is_readable( $real_path ) ) {
        return [ 'error' => 'No se puede leer el archivo CSV.' ];
    }
    $csv_path = $real_path;

    if ( empty( $col_map ) ) {
        $col_map = [
            'sku'   => 'sku',
            'stock' => 'stock',
            'price' => 'price',
            'name'  => 'name',
        ];
    }

    // Preparar archivo para multipart upload
    $csv_content = file_get_contents( $csv_path );
    if ( false === $csv_content ) {
        return [ 'error' => 'Error al leer el archivo CSV.' ];
    }

    // Crear multipart body manualmente
    $boundary = 'WP' . uniqid();
    $body = '';

    // Agregar campos
    $fields = [
        'tienda'   => $tienda,
        'tipo'     => $tipo,
        'dry_run'  => $dry_run ? 'true' : 'false',
        'col_map'  => wp_json_encode( $col_map ),
    ];

    foreach ( $fields as $name => $value ) {
        // Sanitize field name to prevent MIME injection in multipart headers.
        $safe_name = preg_replace( '/[^\w\-]/', '', $name );
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"{$safe_name}\"\r\n\r\n";
        $body .= $value . "\r\n";
    }

    // Agregar archivo CSV — strip path separators and control characters from filename.
    $filename      = basename( $csv_path );
    $safe_filename = preg_replace( '/[^\w\-.]/', '_', $filename );
    $body .= "--{$boundary}\r\n";
    $body .= "Content-Disposition: form-data; name=\"csv_file\"; filename=\"{$safe_filename}\"\r\n";
    $body .= "Content-Type: text/csv\r\n\r\n";
    $body .= $csv_content . "\r\n";
    $body .= "--{$boundary}--\r\n";

    $response = wp_remote_post(
        $url . '/sync-csv',
        [
            'timeout'   => 300,
            'sslverify' => true,
            'headers'   => [
                'Content-Type'    => "multipart/form-data; boundary=$boundary",
                'User-Agent'      => 'WordPress Stock Sync Pro / ' . WEVICA_SYNC_VERSION,
                'X-StockSync-Key' => ssp_get_engine_api_key(),
            ],
            'body'      => $body,
        ]
    );

    if ( is_wp_error( $response ) ) {
        return [
            'error' => 'Error de conexión con motor: ' . $response->get_error_message(),
        ];
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body_response = wp_remote_retrieve_body( $response );

    if ( 200 !== $code ) {
        $error_msg = "HTTP $code";
        $data = json_decode( $body_response, true );
        if ( is_array( $data ) && ! empty( $data['error'] ) ) {
            $error_msg .= ': ' . $data['error'];
        }
        return [ 'error' => $error_msg ];
    }

    $result = json_decode( $body_response, true );
    if ( ! is_array( $result ) ) {
        return [
            'error' => 'Respuesta inválida del motor de sincronización.',
        ];
    }

    return $result;
}

/**
 * Obtener SKUs disponibles del motor de sincronización.
 *
 * @return array SKUs listados en WooCommerce.
 */
function ssp_get_available_skus() {
    if ( ! function_exists( 'wc_get_products' ) ) {
        return [];
    }

    $products = wc_get_products( [
        'limit' => -1,
        'return' => 'ids',
    ] );

    $skus = [];
    foreach ( $products as $product_id ) {
        $product = wc_get_product( $product_id );
        if ( $product ) {
            $sku = $product->get_sku();
            if ( ! empty( $sku ) ) {
                $skus[] = $sku;
            }
            // Si es variable, incluir SKUs de variaciones
            if ( $product->is_type( 'variable' ) ) {
                $variations = $product->get_children();
                foreach ( $variations as $var_id ) {
                    $variation = wc_get_product( $var_id );
                    if ( $variation ) {
                        $var_sku = $variation->get_sku();
                        if ( ! empty( $var_sku ) ) {
                            $skus[] = $var_sku;
                        }
                    }
                }
            }
        }
    }

    return array_unique( $skus );
}

/**
 * Auto-provisionar este sitio en el motor de sincronización del VPS.
 *
 * Crea una API key dedicada para el motor (si no existe ya) y la envía al VPS
 * junto con la URL del sitio. El VPS añade la entrada en config.yaml (activa: false)
 * y notifica al proveedor por Telegram para que configure el scraper.
 *
 * Se llama automáticamente al activar una suscripción. Idempotente: no hace nada
 * si ya se provisionó con éxito.
 *
 * @return bool True si el VPS confirmó el registro (o ya estaba registrado).
 */
function ssp_autoprovision_client(): bool {
	if ( get_option( 'ssp_vps_provisioned' ) ) {
		return true;
	}

	// Reutilizar la clave si ya se generó en un intento anterior fallido.
	$plain_key = get_transient( 'ssp_vps_provision_key' );
	if ( empty( $plain_key ) ) {
		$plain_key = ssp_create_api_key( 'Motor de Sincronización' );
		// TTL corto: si el envío al VPS falla, la clave en texto plano
		// no persiste más tiempo del necesario en la base de datos.
		set_transient( 'ssp_vps_provision_key', $plain_key, HOUR_IN_SECONDS );
	}

	$body = wp_json_encode( [
		'woo_url'     => home_url(),
		'woo_api_key' => $plain_key,
		'plan'        => function_exists( 'ssp_get_current_plan' ) ? ssp_get_current_plan() : 'starter',
		'admin_email' => get_option( 'admin_email', '' ),
	] );

	$engine_url = ssp_get_syncengine_url();
	if ( empty( $engine_url ) ) {
		return false;
	}

	$response = wp_remote_post(
		$engine_url . '/api/clients/register',
		[
			'timeout'   => 15,
			'sslverify' => true,
			'headers'   => [
				'Content-Type'    => 'application/json',
				'X-StockSync-Key' => ssp_get_engine_api_key(),
			],
			'body'      => $body,
		]
	);

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$code = wp_remote_retrieve_response_code( $response );
	if ( $code >= 200 && $code < 300 ) {
		delete_transient( 'ssp_vps_provision_key' );
		update_option( 'ssp_vps_provisioned', true );
		return true;
	}

	return false;
}
