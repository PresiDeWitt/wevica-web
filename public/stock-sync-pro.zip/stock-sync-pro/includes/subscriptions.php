<?php
/**
 * Stock Sync Pro — Subscription Management.
 *
 * Handles all subscription logic:
 * - Lemon Squeezy webhook verification and processing
 * - Plan limits and feature access control
 * - Billing status tracking
 * - Email notifications for lifecycle events
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Database Setup ────────────────────────────────────────────────────────────

/**
 * Creates subscription tables on plugin activation.
 * Called by register_activation_hook in main plugin file.
 */
function ssp_create_subscription_tables() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();

	// Main subscriptions table
	$table_subscriptions = $wpdb->prefix . 'ssp_subscriptions';
	$sql_subscriptions   = "CREATE TABLE IF NOT EXISTS $table_subscriptions (
		id BIGINT AUTO_INCREMENT PRIMARY KEY,
		site_url VARCHAR(255) NOT NULL UNIQUE,
		plan VARCHAR(50) NOT NULL DEFAULT 'free', -- free, starter, pro, enterprise
		lemon_squeezy_subscription_id VARCHAR(255) UNIQUE,
		lemon_squeezy_customer_id VARCHAR(255),
		status VARCHAR(50) NOT NULL DEFAULT 'active', -- active, past_due, cancelled, expired
		next_billing_date DATETIME,
		trial_expires_at DATETIME,
		cancelled_at DATETIME,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		INDEX idx_plan (plan),
		INDEX idx_status (status),
		INDEX idx_ls_subscription (lemon_squeezy_subscription_id)
	) $charset_collate;";

	// Usage tracking table (for rate limiting by plan)
	$table_usage   = $wpdb->prefix . 'ssp_usage';
	$sql_usage     = "CREATE TABLE IF NOT EXISTS $table_usage (
		id BIGINT AUTO_INCREMENT PRIMARY KEY,
		site_url VARCHAR(255) NOT NULL,
		feature VARCHAR(100) NOT NULL, -- api_calls, products_synced, api_keys, etc.
		count BIGINT DEFAULT 0,
		period_year INT NOT NULL,
		period_month INT NOT NULL,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		UNIQUE KEY unique_usage (site_url, feature, period_year, period_month),
		INDEX idx_site (site_url),
		INDEX idx_period (period_year, period_month)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql_subscriptions );
	dbDelta( $sql_usage );

	// Store table names for reference
	update_option( 'ssp_table_subscriptions', $table_subscriptions );
	update_option( 'ssp_table_usage', $table_usage );
}

// ── Plan Configuration ────────────────────────────────────────────────────────

/**
 * Returns plan configuration with limits and features.
 *
 * @param  string $plan Plan slug (free, starter, pro, enterprise).
 * @return array Plan configuration or null if not found.
 */
function ssp_get_plan_config( string $plan ): ?array {
	$plans = [
		'free'       => [
			'name'              => 'Free',
			'price'             => 0,
			'billing_cycle'     => null,
			'api_calls_monthly' => 1000,
			'products_monthly'  => 500,
			'api_keys'          => 1,
			'webhooks'          => false,
			'custom_scrapers'   => false,
			'priority_support'  => false,
			'dedicated_onboarding' => false,
		],
		'starter'    => [
			'name'              => 'Starter',
			'price'             => 79,
			'currency'          => 'EUR',
			'billing_cycle'     => 'monthly',
			'api_calls_monthly' => 25000,
			'products_monthly'  => 5000,
			'api_keys'          => 3,
			'webhooks'          => true,
			'custom_scrapers'   => false,
			'priority_support'  => false,
			'dedicated_onboarding' => false,
		],
		'pro'        => [
			'name'              => 'Pro',
			'price'             => 149,
			'currency'          => 'EUR',
			'billing_cycle'     => 'monthly',
			'api_calls_monthly' => 100000,
			'products_monthly'  => 50000,
			'api_keys'          => 10,
			'webhooks'          => true,
			'custom_scrapers'   => true,
			'priority_support'  => true,
			'dedicated_onboarding' => false,
		],
		'enterprise' => [
			'name'              => 'Business',
			'price'             => 299,
			'currency'          => 'EUR',
			'billing_cycle'     => 'monthly',
			'api_calls_monthly' => 1000000,
			'products_monthly'  => 300000,
			'api_keys'          => 999,
			'webhooks'          => true,
			'custom_scrapers'   => true,
			'priority_support'  => true,
			'dedicated_onboarding' => true,
		],
	];

	return $plans[ $plan ] ?? null;
}

/**
 * Get all plans with their config.
 *
 * @return array Array of plans.
 */
function ssp_get_all_plans(): array {
	return [
		'free'       => ssp_get_plan_config( 'free' ),
		'starter'    => ssp_get_plan_config( 'starter' ),
		'pro'        => ssp_get_plan_config( 'pro' ),
		'enterprise' => ssp_get_plan_config( 'enterprise' ),
	];
}

// ── Subscription Retrieval ────────────────────────────────────────────────────

/**
 * Get current site's subscription.
 *
 * @return object|null Subscription object or null if not found.
 */
function ssp_get_subscription(): ?object {
	global $wpdb;
	$table = $wpdb->prefix . 'ssp_subscriptions';
	$site  = home_url();

	$subscription = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT * FROM {$table} WHERE site_url = %s LIMIT 1",
			$site
		)
	);

	return $subscription ?: null;
}

/**
 * Get subscription by Lemon Squeezy subscription ID.
 *
 * @param  string $ls_subscription_id Lemon Squeezy subscription ID.
 * @return object|null Subscription object.
 */
function ssp_get_subscription_by_ls_id( string $ls_subscription_id ): ?object {
	global $wpdb;
	$table = $wpdb->prefix . 'ssp_subscriptions';

	$subscription = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT * FROM {$table} WHERE lemon_squeezy_subscription_id = %s LIMIT 1",
			$ls_subscription_id
		)
	);

	return $subscription ?: null;
}

/**
 * Get current plan for this site.
 *
 * @return string Plan slug (free, starter, pro, enterprise).
 */
function ssp_get_current_plan(): string {
	$subscription = ssp_get_subscription();
	if ( $subscription ) {
		// past_due gets a grace period — still keep their plan active.
		if ( ! in_array( $subscription->status, [ 'active', 'past_due' ], true ) ) {
			return 'free';
		}

		// Check if trial has expired
		if ( $subscription->plan === 'free' && $subscription->trial_expires_at ) {
			if ( strtotime( $subscription->trial_expires_at ) < time() ) {
				return 'free';
			}
		}

		return $subscription->plan;
	}

	// Fallback: plan assigned via Sync Engine activation (no Lemon Squeezy DB row needed).
	$se_plan = get_option( 'ssp_plan_slug', '' );
	if ( $se_plan && function_exists( 'ssp_autosync_is_active' ) && ssp_autosync_is_active() ) {
		return $se_plan;
	}

	return 'free';
}

/**
 * Check if site has active subscription to specific plan or higher.
 *
 * @param  string $plan Plan to check (free, starter, pro, enterprise).
 * @return bool True if subscribed to plan or higher.
 */
function ssp_has_plan( string $plan ): bool {
	$current = ssp_get_current_plan();

	$hierarchy = [ 'free' => 0, 'starter' => 1, 'pro' => 2, 'enterprise' => 3 ];

	return ( $hierarchy[ $current ] ?? 0 ) >= ( $hierarchy[ $plan ] ?? 0 );
}

/**
 * Check if plan has specific feature.
 *
 * @param  string $plan Plan to check.
 * @param  string $feature Feature slug.
 * @return bool True if plan includes feature.
 */
function ssp_plan_has_feature( string $plan, string $feature ): bool {
	$config = ssp_get_plan_config( $plan );
	if ( ! $config ) {
		return false;
	}

	if ( isset( $config[ $feature ] ) ) {
		return (bool) $config[ $feature ];
	}

	if ( isset( $config[ "{$feature}_monthly" ] ) ) {
		return $config[ "{$feature}_monthly" ] > 0;
	}

	return false;
}

// ── Usage Tracking ────────────────────────────────────────────────────────────

/**
 * Increment usage counter for current month.
 *
 * @param  string $feature Feature to track.
 * @param  int    $amount Amount to increment (default 1).
 * @return bool True on success.
 */
function ssp_increment_usage( string $feature, int $amount = 1 ): bool {
	global $wpdb;
	$table = $wpdb->prefix . 'ssp_usage';
	$site  = home_url();
	$year  = (int) gmdate( 'Y' );
	$month = (int) gmdate( 'm' );

	$wpdb->query(
		$wpdb->prepare(
			"INSERT INTO {$table} (site_url, feature, count, period_year, period_month)
			VALUES (%s, %s, %d, %d, %d)
			ON DUPLICATE KEY UPDATE count = count + %d",
			$site,
			$feature,
			$amount,
			$year,
			$month,
			$amount
		)
	);

	return ! $wpdb->last_error;
}

/**
 * Get usage for current month.
 *
 * @param  string $feature Feature to check.
 * @return int Current month usage.
 */
function ssp_get_usage( string $feature ): int {
	global $wpdb;
	$table = $wpdb->prefix . 'ssp_usage';
	$site  = home_url();
	$year  = (int) gmdate( 'Y' );
	$month = (int) gmdate( 'm' );

	$count = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT count FROM {$table} WHERE site_url = %s AND feature = %s AND period_year = %d AND period_month = %d",
			$site,
			$feature,
			$year,
			$month
		)
	);

	return (int) $count;
}

/**
 * Check if feature usage is within plan limits.
 *
 * @param  string $feature Feature to check.
 * @param  int    $amount Amount to check (optional, for lookahead).
 * @return bool True if within limits.
 */
function ssp_check_usage_limit( string $feature, int $amount = 1 ): bool {
	$plan   = ssp_get_current_plan();
	$config = ssp_get_plan_config( $plan );

	if ( ! $config ) {
		return false;
	}

	$feature_key = "{$feature}_monthly";
	$limit       = $config[ $feature_key ] ?? 0;

	if ( $limit === 0 ) {
		return false; // Feature not available in plan
	}

	$current_usage = ssp_get_usage( $feature );

	return ( $current_usage + $amount ) <= $limit;
}

/**
 * Create or update subscription.
 *
 * @param  array $data Subscription data.
 * @return int|false Subscription ID or false on failure.
 */
function ssp_save_subscription( array $data ): int|false {
	global $wpdb;
	$table = $wpdb->prefix . 'ssp_subscriptions';
	$site  = $data['site_url'] ?? home_url();

	// Ensure we have required fields
	if ( empty( $data['plan'] ) || empty( $data['lemon_squeezy_subscription_id'] ) ) {
		return false;
	}

	// Check if subscription exists
	$existing = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT id FROM {$table} WHERE site_url = %s",
			$site
		)
	);

	// Whitelist explícita de columnas para evitar que campos extra del webhook
	// de Lemon Squeezy muten columnas no intencionadas (p.ej. id, created_at).
	$allowed_columns = [
		'lemon_squeezy_subscription_id',
		'lemon_squeezy_customer_id',
		'plan',
		'status',
		'next_billing_date',
		'trial_expires_at',
	];
	$safe_data = array_intersect_key( $data, array_flip( $allowed_columns ) );

	if ( $existing ) {
		$wpdb->update( $table, $safe_data, [ 'site_url' => $site ] );
		return $existing->id;
	} else {
		$safe_data['site_url'] = $site;
		$result                = $wpdb->insert( $table, $safe_data );
		return $result ? $wpdb->insert_id : false;
	}
}

// ── Lemon Squeezy Webhook ────────────────────────────────────────────────────

/**
 * Verify Lemon Squeezy webhook signature.
 *
 * @param  string $body Request body.
 * @param  string $signature X-Signature header value.
 * @return bool True if signature is valid.
 */
function ssp_verify_lemon_squeezy_signature( string $body, string $signature ): bool {
	$secret = get_option( 'ssp_lemon_squeezy_webhook_secret', '' );

	if ( empty( $secret ) ) {
		return false;
	}

	// Reject signatures that don't match the expected hex format (64 hex chars for sha256).
	if ( ! preg_match( '/^[a-f0-9]{64}$/', $signature ) ) {
		return false;
	}

	$hash = hash_hmac( 'sha256', $body, $secret );

	return hash_equals( $hash, $signature );
}

/**
 * Handle Lemon Squeezy webhook events.
 * Registered via add_action( 'rest_api_init' ).
 */
function ssp_register_lemon_squeezy_webhook() {
	register_rest_route( 'ssp/v1', '/webhooks/lemon-squeezy', [
		'methods'             => 'POST',
		'callback'            => 'ssp_handle_lemon_squeezy_webhook',
		'permission_callback' => '__return_true', // Verify by signature instead
	] );
}

add_action( 'rest_api_init', 'ssp_register_lemon_squeezy_webhook' );

/**
 * Process Lemon Squeezy webhook payload.
 *
 * @param  WP_REST_Request $request Webhook request.
 * @return WP_REST_Response Response.
 */
function ssp_handle_lemon_squeezy_webhook( WP_REST_Request $request ): WP_REST_Response {
	$body      = $request->get_body();
	$signature = $request->get_header( 'X-Signature' );

	// Signature is required
	if ( empty( $signature ) ) {
		error_log( 'Lemon Squeezy webhook missing X-Signature header' );
		return new WP_REST_Response( [ 'error' => 'Missing X-Signature header' ], 401 );
	}

	// Verify webhook signature
	if ( ! ssp_verify_lemon_squeezy_signature( $body, $signature ) ) {
		error_log( 'Lemon Squeezy webhook signature verification failed' );
		return new WP_REST_Response( [ 'error' => 'Invalid signature' ], 401 );
	}

	$payload = json_decode( $body, true );

	if ( ! $payload || ! isset( $payload['meta']['event_name'] ) ) {
		return new WP_REST_Response( [ 'error' => 'Invalid payload' ], 400 );
	}

	$event = $payload['meta']['event_name'];

	// Log webhook receipt
	error_log( "Lemon Squeezy webhook: {$event}" );

	switch ( $event ) {
		case 'subscription_created':
			ssp_handle_subscription_created( $payload['data'] );
			break;

		case 'subscription_updated':
			ssp_handle_subscription_updated( $payload['data'] );
			break;

		case 'subscription_cancelled':
			ssp_handle_subscription_cancelled( $payload['data'] );
			break;

		case 'subscription_expired':
			ssp_handle_subscription_expired( $payload['data'] );
			break;

		case 'subscription_resumed':
			ssp_handle_subscription_resumed( $payload['data'] );
			break;
	}

	return new WP_REST_Response( [ 'success' => true ], 200 );
}

/**
 * Handle new subscription created.
 *
 * @param array $data Subscription data from Lemon Squeezy.
 */
function ssp_handle_subscription_created( array $data ) {
	$attributes = $data['attributes'] ?? [];

	$subscription = ssp_save_subscription( [
		'lemon_squeezy_subscription_id' => $data['id'],
		'lemon_squeezy_customer_id'     => $data['relationships']['customer']['data']['id'] ?? '',
		'plan'                          => ssp_map_lemon_squeezy_plan( $attributes['product_id'] ?? 0 ),
		'status'                        => 'active',
		'next_billing_date'             => $attributes['renews_at'] ?? null,
		'trial_expires_at'              => $attributes['trial_ends_at'] ?? null,
	] );

	if ( $subscription ) {
		// Send welcome email
		ssp_send_email_subscription_created( ssp_get_subscription_by_ls_id( $data['id'] ) );

		// Registrar automáticamente este sitio en el motor VPS.
		ssp_autoprovision_client();
	}
}

/**
 * Handle subscription updated.
 *
 * @param array $data Subscription data from Lemon Squeezy.
 */
function ssp_handle_subscription_updated( array $data ) {
	$attributes = $data['attributes'] ?? [];

	ssp_save_subscription( [
		'lemon_squeezy_subscription_id' => $data['id'],
		'plan'                          => ssp_map_lemon_squeezy_plan( $attributes['product_id'] ?? 0 ),
		'status'                        => ssp_map_lemon_squeezy_status( $attributes['status'] ?? 'active' ),
		'next_billing_date'             => $attributes['renews_at'] ?? null,
	] );
}

/**
 * Handle subscription cancellation.
 *
 * @param array $data Subscription data from Lemon Squeezy.
 */
function ssp_handle_subscription_cancelled( array $data ) {
	$subscription = ssp_get_subscription_by_ls_id( $data['id'] );

	if ( $subscription ) {
		ssp_save_subscription( [
			'lemon_squeezy_subscription_id' => $data['id'],
			'plan'                          => $subscription->plan,
			'status'                        => 'cancelled',
			'cancelled_at'                  => gmdate( 'Y-m-d H:i:s' ),
		] );

		// Send cancellation email
		ssp_send_email_subscription_cancelled( $subscription );
	}
}

/**
 * Handle subscription expiration.
 *
 * @param array $data Subscription data from Lemon Squeezy.
 */
function ssp_handle_subscription_expired( array $data ) {
	ssp_save_subscription( [
		'lemon_squeezy_subscription_id' => $data['id'],
		'status'                        => 'expired',
		'plan'                          => 'free',
	] );
}

/**
 * Handle subscription resumption.
 *
 * @param array $data Subscription data from Lemon Squeezy.
 */
function ssp_handle_subscription_resumed( array $data ) {
	$attributes = $data['attributes'] ?? [];

	ssp_save_subscription( [
		'lemon_squeezy_subscription_id' => $data['id'],
		'status'                        => 'active',
		'plan'                          => ssp_map_lemon_squeezy_plan( $attributes['product_id'] ?? 0 ),
		'next_billing_date'             => $attributes['renews_at'] ?? null,
	] );

	$subscription = ssp_get_subscription_by_ls_id( $data['id'] );
	if ( $subscription ) {
		ssp_send_email_subscription_resumed( $subscription );
	}
}

/**
 * Map Lemon Squeezy product ID to plan slug.
 *
 * @param  int $product_id Lemon Squeezy product ID.
 * @return string Plan slug.
 */
function ssp_map_lemon_squeezy_plan( int $product_id ): string {
	$mapping = get_option( 'ssp_lemon_squeezy_plan_mapping', [] );

	// Return mapped plan or default to free
	return $mapping[ $product_id ] ?? 'free';
}

/**
 * Map Lemon Squeezy status to our status.
 *
 * @param  string $ls_status Lemon Squeezy status.
 * @return string Our status.
 */
function ssp_map_lemon_squeezy_status( string $ls_status ): string {
	$map = [
		'active'    => 'active',
		'past_due'  => 'past_due',
		'paused'    => 'paused',
		'cancelled' => 'cancelled',
		'expired'   => 'expired',
	];

	if ( ! isset( $map[ $ls_status ] ) ) {
		// Estado desconocido: denegar acceso por defecto (fail closed).
		return 'cancelled';
	}
	return $map[ $ls_status ];
}

// ── Email Notifications ────────────────────────────────────────────────────────

/**
 * Send welcome email for new subscription.
 *
 * @param object $subscription Subscription object.
 */
function ssp_send_email_subscription_created( object $subscription ) {
	$to      = get_option( 'admin_email' );
	$subject = sprintf( '[Stock Sync Pro] Welcome to %s Plan!', ucfirst( $subscription->plan ) );

	$body = sprintf(
		"Welcome to Stock Sync Pro!\n\n" .
		"Plan: %s\n" .
		"Status: Active\n" .
		"Next Billing: %s\n\n" .
		"Thank you for choosing Stock Sync Pro. Your subscription is now active.\n\n" .
		"Access your dashboard: %s",
		ucfirst( $subscription->plan ),
		$subscription->next_billing_date,
		admin_url( 'admin.php?page=ssp-subscriptions' )
	);

	wp_mail( $to, $subject, $body );
}

/**
 * Send subscription cancelled email.
 *
 * @param object $subscription Subscription object.
 */
function ssp_send_email_subscription_cancelled( object $subscription ) {
	$to      = get_option( 'admin_email' );
	$subject = '[Stock Sync Pro] Subscription Cancelled';

	$body = sprintf(
		"Your Stock Sync Pro subscription has been cancelled.\n\n" .
		"Your account will revert to the Free plan.\n" .
		"You can reactivate anytime from your dashboard: %s\n\n" .
		"We'd love to hear feedback: hello@wevica.com",
		admin_url( 'admin.php?page=ssp-subscriptions' )
	);

	wp_mail( $to, $subject, $body );
}

/**
 * Send subscription resumed email.
 *
 * @param object $subscription Subscription object.
 */
function ssp_send_email_subscription_resumed( object $subscription ) {
	$to      = get_option( 'admin_email' );
	$subject = '[Stock Sync Pro] Subscription Resumed';

	$body = sprintf(
		"Your Stock Sync Pro subscription has been reactivated!\n\n" .
		"Plan: %s\n" .
		"Status: Active\n\n" .
		"Welcome back! Your full feature set is now available.",
		ucfirst( $subscription->plan )
	);

	wp_mail( $to, $subject, $body );
}
