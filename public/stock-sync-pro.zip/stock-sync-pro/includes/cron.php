<?php
/**
 * Stock Sync Pro — Auto-sync Cron.
 *
 * Registers custom WP-Cron intervals, schedules/unschedules the sync event
 * based on the configured interval, and fetches + processes the source URL
 * when the cron fires.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Custom cron intervals ─────────────────────────────────────────────────────

add_filter( 'cron_schedules', 'ssp_cron_add_intervals' );

function ssp_cron_add_intervals( array $schedules ): array {
    $schedules['ssp_5min'] = [
        'interval' => 5 * MINUTE_IN_SECONDS,
        'display'  => __( 'Every 5 minutes', 'stock-sync-pro' ),
    ];
    $schedules['ssp_30min'] = [
        'interval' => 30 * MINUTE_IN_SECONDS,
        'display'  => __( 'Cada 30 minutos', 'stock-sync-pro' ),
    ];
    $schedules['ssp_2hours'] = [
        'interval' => 2 * HOUR_IN_SECONDS,
        'display'  => __( 'Cada 2 horas', 'stock-sync-pro' ),
    ];
    // 'hourly', 'twicedaily', 'daily', 'weekly' are built-in WP intervals.
    return $schedules;
}

// ── Setup / teardown ──────────────────────────────────────────────────────────

/**
 * Schedule or unschedule the auto-sync cron event based on current settings.
 * Call this whenever the interval setting changes.
 */
function ssp_setup_cron() {
    $hook     = 'ssp_auto_sync';
    $interval = get_option( 'ssp_cron_interval', 'off' );

    // Clear any existing schedule first.
    $ts = wp_next_scheduled( $hook );
    if ( $ts ) {
        wp_unschedule_event( $ts, $hook );
    }

    if ( $interval === 'off' ) {
        return;
    }

    $valid = [ 'ssp_30min', 'ssp_2hours', 'hourly', 'twicedaily', 'daily', 'weekly' ];
    if ( ! in_array( $interval, $valid, true ) ) {
        return;
    }

    wp_schedule_event( time() + 60, $interval, $hook );
}

// Schedule event on 'wp' hook so it's registered on every page load.
add_action( 'wp', 'ssp_ensure_cron_scheduled' );
add_action( 'admin_init', 'ssp_ensure_cron_scheduled' );

function ssp_ensure_cron_scheduled() {
    $interval = get_option( 'ssp_cron_interval', 'off' );
    if ( $interval === 'off' ) {
        // Make sure there's nothing scheduled.
        $ts = wp_next_scheduled( 'ssp_auto_sync' );
        if ( $ts ) {
            wp_unschedule_event( $ts, 'ssp_auto_sync' );
        }
    } elseif ( ! wp_next_scheduled( 'ssp_auto_sync' ) ) {
        $valid = [ 'ssp_30min', 'ssp_2hours', 'hourly', 'twicedaily', 'daily', 'weekly' ];
        if ( in_array( $interval, $valid, true ) ) {
            wp_schedule_event( time() + 60, $interval, 'ssp_auto_sync' );
        }
    }

    // Webhook retry queue — always runs every 5 minutes, independent of auto-sync.
    if ( ! wp_next_scheduled( 'ssp_webhook_retry' ) ) {
        wp_schedule_event( time() + 30, 'ssp_5min', 'ssp_webhook_retry' );
    }

    // Trial reminder — runs once per day to email admin before/after trial expiry.
    if ( ! wp_next_scheduled( 'ssp_trial_reminder_check' ) ) {
        wp_schedule_event( time() + 60, 'daily', 'ssp_trial_reminder_check' );
    }

    // Cleanup orphaned transients — runs hourly to clean stale sync batch transients.
    if ( ! wp_next_scheduled( 'ssp_cleanup_orphans' ) ) {
        wp_schedule_event( time() + 120, 'hourly', 'ssp_cleanup_orphans' );
    }
}

// ── Cron callback ─────────────────────────────────────────────────────────────

add_action( 'ssp_auto_sync', 'ssp_do_auto_sync' );

function ssp_do_auto_sync() {
    // Plugin is free; ssp_is_licensed() always returns true — this check is a no-op.
    if ( ! ssp_is_licensed() ) {
        return;
    }

    $source_url  = get_option( 'ssp_cron_source_url', '' );
    $tienda      = get_option( 'ssp_cron_tienda', 'cron' );
    $source_type = get_option( 'ssp_cron_source_type', 'auto' ); // json | csv | auto
    $col_sku     = get_option( 'ssp_cron_col_sku', 'sku' );
    $col_stock   = get_option( 'ssp_cron_col_stock', 'stock' );
    $col_price   = get_option( 'ssp_cron_col_price', 'precio' );

    if ( empty( $source_url ) ) {
        return;
    }

    if ( ! ssp_is_safe_url( $source_url ) ) {
        ssp_send_error_notification(
            __( 'URL de cron bloqueada (SSRF)', 'stock-sync-pro' ),
            sprintf( "La URL configurada fue rechazada por apuntar a una dirección privada o inválida:\n%s", $source_url )
        );
        return;
    }

    $response = wp_remote_get( $source_url, [
        'timeout'    => 30,
        'user-agent' => 'StockSyncPro/' . WEVICA_SYNC_VERSION . ' (+' . home_url() . ')',
    ] );

    if ( is_wp_error( $response ) ) {
        $err_msg = $response->get_error_message();
        ssp_dispatch_webhook( 'sync_error', [
            'tienda' => $tienda,
            'tipo'   => 'cron',
            'error'  => $err_msg,
        ] );
        ssp_send_error_notification(
            __( 'Error en el cron de sincronización', 'stock-sync-pro' ),
            sprintf( "Tienda: %s\nError: %s", $tienda, $err_msg )
        );
        return;
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
        $err_msg = "HTTP {$code} al obtener la URL de datos.";
        ssp_dispatch_webhook( 'sync_error', [
            'tienda' => $tienda,
            'tipo'   => 'cron',
            'error'  => $err_msg,
        ] );
        ssp_send_error_notification(
            __( 'Error en el cron de sincronización', 'stock-sync-pro' ),
            sprintf( "Tienda: %s\nURL: %s\nError: %s", $tienda, $source_url, $err_msg )
        );
        return;
    }

    $body         = wp_remote_retrieve_body( $response );
    $content_type = wp_remote_retrieve_header( $response, 'content-type' );
    $result       = null;

    // Auto-detect format.
    $looks_like_json = ( $source_type === 'json' ) || (
        $source_type === 'auto' && (
            strpos( $content_type, 'json' ) !== false ||
            in_array( substr( ltrim( $body ), 0, 1 ), [ '[', '{' ], true )
        )
    );

    if ( $looks_like_json ) {
        $data      = json_decode( $body, true );
        $productos = [];
        if ( is_array( $data ) ) {
            // Accept both [{sku,stock,...}] and {productos:[...]}
            $productos = isset( $data['productos'] ) ? $data['productos'] : $data;
        }
        $result = wevica_sync_process_json( $productos, $tienda, 'cron' );
    } else {
        // CSV path.
        $tmp = wp_tempnam( 'ssp_cron_' );
        if ( $tmp ) {
            $written = file_put_contents( $tmp, $body );
            if ( $written === false ) {
                wp_delete_file( $tmp );
                ssp_dispatch_webhook( 'sync_error', [
                    'tienda' => $tienda,
                    'tipo'   => 'cron',
                    'error'  => 'Error al escribir archivo temporal CSV',
                ] );
                return;
            }
            $result = wevica_sync_process_csv( $tmp, $tienda, 'cron', $col_sku, $col_stock, $col_price );
            wp_delete_file( $tmp );
        }
    }

    if ( ! $result ) {
        ssp_dispatch_webhook( 'sync_error', [
            'tienda' => $tienda,
            'tipo'   => 'cron',
            'error'  => 'No se pudo procesar la respuesta de la URL de datos.',
        ] );
        return;
    }

    if ( isset( $result['error'] ) ) {
        ssp_dispatch_webhook( 'sync_error', [
            'tienda' => $tienda,
            'tipo'   => 'cron',
            'error'  => $result['error'],
        ] );
        ssp_send_error_notification(
            __( 'Error procesando datos en el cron', 'stock-sync-pro' ),
            sprintf( "Tienda: %s\nError: %s", $tienda, $result['error'] )
        );
    } else {
        ssp_dispatch_webhook( 'sync_complete', array_merge(
            [ 'tienda' => $tienda, 'tipo' => 'cron' ],
            [
                'total'        => $result['total'],
                'actualizados' => $result['actualizados'],
                'sin_sku'      => $result['sin_sku'],
                'errores'      => $result['errores'],
            ]
        ) );
    }
}

// ── Trial reminder ────────────────────────────────────────────────────────────

add_action( 'ssp_trial_reminder_check', 'ssp_do_trial_reminder' );

/**
 * No-op: trial reminders are no longer sent since the plugin is free.
 * Kept as a stub so existing scheduled events don't cause fatal errors.
 */
function ssp_do_trial_reminder(): void {
    // Plugin is free — no trial period, nothing to remind.
}

// ── AJAX — trigger manual cron run ────────────────────────────────────────────

add_action( 'wp_ajax_ssp_run_cron_now', 'ssp_ajax_run_cron_now' );

function ssp_ajax_run_cron_now() {
    check_ajax_referer( 'ssp_cron_nonce', 'nonce' );
    if ( ! current_user_can( wevica_sync_capability() ) ) {
        wp_send_json_error( [ 'message' => __( 'Sin permisos.', 'stock-sync-pro' ) ] );
    }

    if ( ! ssp_is_licensed() ) {
        wp_send_json_error( [ 'message' => __( 'Licencia expirada. Activa una licencia para usar el cron.', 'stock-sync-pro' ) ] );
    }

    $source_url = get_option( 'ssp_cron_source_url', '' );
    if ( empty( $source_url ) ) {
        wp_send_json_error( [ 'message' => __( 'Configura una URL de datos en los ajustes del cron antes de ejecutar.', 'stock-sync-pro' ) ] );
    }

    ssp_do_auto_sync();
    wp_send_json_success( [ 'message' => __( 'Sincronización cron ejecutada. Revisa el historial para ver el resultado.', 'stock-sync-pro' ) ] );
}

// ── Cleanup orphaned transients ─────────────────────────────────────────────────

add_action( 'ssp_cleanup_orphans', 'ssp_do_cleanup_orphans' );

/**
 * Limpia transients huérfanos de sincronizaciones incompletas.
 * Elimina transients de tipo 'wevica_batch_*' que tengan más de 24 horas.
 *
 * Esto previene acumulación de datos huérfanos cuando un sync con sync_id
 * falla y no llega el último batch (is_last_batch=true).
 */
function ssp_do_cleanup_orphans(): void {
    global $wpdb;

    $cutoff_time = time() - DAY_IN_SECONDS;

    // Buscar los timeouts de transients de batch que ya han caducado (>24h).
    // WordPress almacena el timeout como un entero Unix en _transient_timeout_*.
    $expired_timeout_options = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options}
             WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) < %d",
            '_transient_timeout_wevica_batch_%',
            $cutoff_time
        )
    );

    $deleted = 0;
    foreach ( $expired_timeout_options as $timeout_option ) {
        // Derivar el nombre del transient quitando el prefijo de timeout.
        $transient_name = str_replace( '_transient_timeout_', '', $timeout_option );
        // delete_transient() borra tanto el valor como el timeout en una sola operación.
        if ( delete_transient( $transient_name ) ) {
            $deleted++;
        }
    }

    if ( $deleted > 0 ) {
        error_log( "[Stock Sync Pro] Cleaned {$deleted} orphaned sync transients." );
    }
}
