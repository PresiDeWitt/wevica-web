<?php
/**
 * Wévica Stock Sync — Lógica central de sincronización.
 *
 * Procesa CSV y JSON para actualizar stock en WooCommerce, y guarda
 * el resultado en el historial.  No registra hooks.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ═══════════════════════════════════════════════════════════════════
//  HELPER — ACTUALIZAR UN PRODUCTO (simple o variación)
// ═══════════════════════════════════════════════════════════════════

/**
 * Aplica cambios de stock y precio a un producto WooCommerce.
 * Compatible con productos simples y variaciones de productos variables.
 *
 * @param  \WC_Product     $product      Producto o variación.
 * @param  string          $new_status   'instock' | 'outofstock'.
 * @param  int|null        $new_quantity Cantidad, o null para no cambiarla.
 * @param  string|null     $price_raw    Precio crudo (se parsea internamente), o null para omitir.
 */
function wevica_sync_apply_stock( \WC_Product $product, string $new_status, $new_quantity, $price_raw ): void {
    if ( $new_quantity !== null ) {
        // Con cantidad: activar gestión de inventario y actualizar stock
        $product->set_manage_stock( true );
        $product->set_stock_quantity( $new_quantity );
    } else {
        // Sin cantidad (solo SI/NO): desactivar gestión de inventario para que
        // WooCommerce respete el stock_status sin sobreescribirlo con qty=0
        $product->set_manage_stock( false );
    }
    $product->set_stock_status( $new_status );

    if ( $price_raw !== null && get_option( 'wevica_sync_update_price', '0' ) === '1' ) {
        $parsed = wevica_sync_parse_price( $price_raw );
        if ( $parsed !== false ) {
            $product->set_regular_price( (string) $parsed );
            // Para variaciones, sincronizar precio efectivo
            if ( $product->is_type( 'variation' ) ) {
                $product->set_price( (string) $parsed );
            }
        }
    }

    $product->save();

    // Sincronizar el estado del producto padre tras guardar la variación.
    if ( $product->is_type( 'variation' ) && class_exists( 'WC_Product_Variable' ) ) {
        WC_Product_Variable::sync_stock( $product->get_parent_id() );
    }
}

// ═══════════════════════════════════════════════════════════════════
//  PROCESAR CSV
// ═══════════════════════════════════════════════════════════════════

/**
 * Lee un archivo CSV y actualiza el stock de los productos en WooCommerce.
 *
 * @param  string $csv_path  Ruta absoluta al archivo CSV.
 * @param  string $tienda    Identificador de la tienda.
 * @param  string $tipo      Tipo de sync ('manual', 'api', 'cron').
 * @param  string $col_sku   Nombre de columna para el SKU.
 * @param  string $col_stock Nombre de columna para el stock.
 * @param  string $col_price Nombre de columna para el precio (opcional).
 * @param  string $col_name  Nombre de columna para el nombre del producto (opcional).
 * @return array             Resultado con claves: total, actualizados, sin_sku, errores, detalles, dry_run.
 *                           O ['error' => string] si hay un error fatal.
 */
function wevica_sync_process_csv( $csv_path, $tienda = '', $tipo = 'manual', $col_sku = 'sku_ixia', $col_stock = 'stock', $col_price = 'precio', $col_name = 'nombre', $dry_run = null ) {
    if ( ! function_exists( 'wc_get_product_id_by_sku' ) ) {
        return [ 'error' => 'WooCommerce no está activo.' ];
    }

    if ( ! is_readable( $csv_path ) ) {
        return [ 'error' => 'No se puede leer el archivo CSV.' ];
    }

    $dry_run       = $dry_run ?? ( get_option( 'wevica_sync_dry_run', '0' ) === '1' );
    $stock_unknown = get_option( 'wevica_sync_stock_unknown', 'skip' );
    $update_price  = get_option( 'wevica_sync_update_price', '0' ) === '1';
    $excluded_skus = ssp_get_excluded_skus();

    $handle = fopen( $csv_path, 'r' );
    if ( ! $handle ) {
        return [ 'error' => 'Error al abrir el archivo CSV.' ];
    }

    $headers = fgetcsv( $handle );
    if ( ! $headers ) {
        fclose( $handle );
        return [ 'error' => 'CSV vacío o sin encabezados.' ];
    }

    // Limpiar BOM UTF-8.
    $headers[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $headers[0] );
    $headers     = array_map( 'trim', $headers );

    $idx_sku   = array_search( $col_sku,   $headers, true );
    $idx_stock = array_search( $col_stock, $headers, true );
    $idx_price = array_search( $col_price, $headers, true );
    $idx_name  = array_search( $col_name,  $headers, true );

    if ( $idx_sku === false ) {
        fclose( $handle );
        return [ 'error' => "Columna SKU '" . esc_html( $col_sku ) . "' no encontrada en el CSV. Columnas disponibles: " . implode( ', ', array_map( 'esc_html', $headers ) ) ];
    }

    $total        = 0;
    $actualizados = 0;
    $sin_sku      = 0;
    $errores      = 0;
    $detalles     = [];

    while ( ( $row = fgetcsv( $handle ) ) !== false ) {
        $total++;

        $sku_value = isset( $row[ $idx_sku ] ) ? trim( $row[ $idx_sku ] ) : '';
        if ( empty( $sku_value ) ) {
            $sin_sku++;
            continue;
        }

        if ( in_array( $sku_value, $excluded_skus, true ) ) {
            continue;
        }

        $product_id = wc_get_product_id_by_sku( $sku_value );
        if ( ! $product_id ) {
            $sin_sku++;
            $detalles[] = [
                'tipo'    => 'no_encontrado',
                'sku'     => $sku_value,
                'nombre'  => '',
                'mensaje' => 'SKU no encontrado en WooCommerce',
            ];
            continue;
        }

        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            $errores++;
            continue;
        }

        $stock_value = ( $idx_stock !== false && isset( $row[ $idx_stock ] ) ) ? $row[ $idx_stock ] : '';
        $resolved    = wevica_sync_resolve_stock_status( $stock_value, $stock_unknown );

        if ( $resolved['skip'] ) {
            continue;
        }

        $new_status   = $resolved['status'];
        $new_quantity = $resolved['quantity'];

        if ( ! $dry_run && $new_status ) {
            try {
                $price_raw = ( $idx_price !== false && isset( $row[ $idx_price ] ) ) ? $row[ $idx_price ] : null;
                wevica_sync_apply_stock( $product, $new_status, $new_quantity, $price_raw );
                $actualizados++;
                $detalles[] = [
                    'tipo'   => 'actualizado',
                    'sku'    => $sku_value,
                    'nombre' => $product->get_name(),
                    'stock'  => $new_status,
                ];
            } catch ( \Throwable $e ) {
                $errores++;
                error_log( 'Wevica sync CSV error on SKU ' . $sku_value . ': ' . $e->getMessage() );
                $detalles[] = [
                    'tipo'    => 'error',
                    'sku'     => $sku_value,
                    'nombre'  => '',
                    'mensaje' => 'Error al actualizar el producto. Revisa el log del servidor para más detalles.',
                ];
            }
        } elseif ( $dry_run && $new_status ) {
            $current = $product->get_stock_status();
            $actualizados++;
            $detalles[] = [
                'tipo'          => 'dry_run_preview',
                'sku'           => $sku_value,
                'nombre'        => $product->get_name(),
                'current_stock' => $current,
                'stock'         => $new_status,
                'action'        => ( $current !== $new_status ) ? 'update' : 'no_change',
            ];
        }
    }

    fclose( $handle );

    wevica_sync_log( $tienda, $tipo, $total, $actualizados, $sin_sku, $errores, $detalles );

    // Dispatch webhook (fire-and-forget).
    ssp_dispatch_webhook( 'sync_complete', [
        'tienda'       => $tienda,
        'tipo'         => $tipo,
        'total'        => $total,
        'actualizados' => $actualizados,
        'sin_sku'      => $sin_sku,
        'errores'      => $errores,
        'dry_run'      => $dry_run,
    ] );

    return [
        'total'        => $total,
        'actualizados' => $actualizados,
        'sin_sku'      => $sin_sku,
        'errores'      => $errores,
        'detalles'     => $detalles,
        'dry_run'      => $dry_run,
    ];
}

// ═══════════════════════════════════════════════════════════════════
//  PROCESAR JSON (API)
// ═══════════════════════════════════════════════════════════════════

/**
 * Procesa un array de productos (JSON) y actualiza stock en WooCommerce.
 *
 * Si se pasa $sync_id, los contadores de todos los lotes se acumulan en un
 * transient y solo se graba una entrada en el historial cuando $is_last_batch=true.
 * Sin $sync_id funciona igual que antes (retrocompatible).
 *
 * @param  array  $productos     Array de ['sku' => ..., 'stock' => ..., ...].
 * @param  string $tienda        Identificador de la tienda.
 * @param  string $tipo          Tipo de sync ('api', 'cron').
 * @param  string $sync_id       ID único de la sincronización multi-lote (opcional).
 * @param  bool   $is_last_batch true si este es el último lote del sync_id.
 * @return array                 Resultado con claves: total, actualizados, sin_sku, errores, detalles, dry_run.
 */
function wevica_sync_process_json( $productos, $tienda = '', $tipo = 'api', $sync_id = '', $is_last_batch = true, $dry_run = null ) {
    if ( ! function_exists( 'wc_get_product_id_by_sku' ) ) {
        return [ 'error' => 'WooCommerce no está activo.' ];
    }

    // Configuración de timeouts.
    $timeout_normal = (int) get_option( 'wevica_sync_timeout_normal', 300 );
    $timeout_final  = (int) get_option( 'wevica_sync_timeout_final', 600 );
    set_time_limit( $is_last_batch ? $timeout_final : $timeout_normal );

    $dry_run       = $dry_run ?? ( get_option( 'wevica_sync_dry_run', '0' ) === '1' );
    $stock_unknown = get_option( 'wevica_sync_stock_unknown', 'skip' );
    $excluded_skus = ssp_get_excluded_skus();
    $total         = count( $productos );
    $actualizados  = 0;
    $sin_sku       = 0;
    $errores       = 0;
    $detalles      = [];

    // ── Optimización: suspender caches y conteos durante el bulk update ──
    // Esto evita que WordPress recalcule caches por cada save(),
    // reduciendo drásticamente la carga en el servidor.
    if ( ! $dry_run ) {
        wp_defer_term_counting( true );
        wp_suspend_cache_invalidation( true );
    }

    foreach ( $productos as $item ) {
        $sku = isset( $item['sku'] ) ? trim( $item['sku'] ) : '';
        if ( empty( $sku ) ) {
            $sin_sku++;
            continue;
        }

        if ( in_array( $sku, $excluded_skus, true ) ) {
            continue;
        }

        $product_id = wc_get_product_id_by_sku( $sku );
        if ( ! $product_id ) {
            $sin_sku++;
            $detalles[] = [
                'tipo'    => 'no_encontrado',
                'sku'     => $sku,
                'nombre'  => '',
                'mensaje' => 'SKU no encontrado en WooCommerce',
            ];
            continue;
        }

        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            $errores++;
            continue;
        }

        $stock_val = isset( $item['stock'] ) ? $item['stock'] : '';
        $resolved  = wevica_sync_resolve_stock_status( $stock_val, $stock_unknown );

        if ( $resolved['skip'] ) {
            continue;
        }

        $new_status = $resolved['status'];
        $new_qty    = $resolved['quantity'];

        if ( ! $dry_run && $new_status ) {
            try {
                wevica_sync_apply_stock( $product, $new_status, $new_qty, $item['precio'] ?? null );
                $actualizados++;
                $detalles[] = [
                    'tipo'   => 'actualizado',
                    'sku'    => $sku,
                    'nombre' => $product->get_name(),
                    'stock'  => $new_status,
                ];
            } catch ( \Throwable $e ) {
                $errores++;
                error_log( 'Wevica sync JSON error on SKU ' . $sku . ': ' . $e->getMessage() );
                $detalles[] = [
                    'tipo'    => 'error',
                    'sku'     => $sku,
                    'nombre'  => '',
                    'mensaje' => 'Error al actualizar el producto. Revisa el log del servidor para más detalles.',
                ];
            }
        } elseif ( $dry_run && $new_status ) {
            $current = $product->get_stock_status();
            $actualizados++;
            $detalles[] = [
                'tipo'          => 'dry_run_preview',
                'sku'           => $sku,
                'nombre'        => $product->get_name(),
                'current_stock' => $current,
                'stock'         => $new_status,
                'action'        => ( $current !== $new_status ) ? 'update' : 'no_change',
            ];
        }
    }

    // ── Restaurar caches y conteos ──
    if ( ! $dry_run ) {
        wp_suspend_cache_invalidation( false );
        wp_defer_term_counting( false );
    }

    // ── Agrupación por sync_id ─────────────────────────────────────────
    if ( ! empty( $sync_id ) ) {
        $transient_key = 'wevica_batch_' . $sync_id;
        $acum = get_transient( $transient_key );
        if ( ! is_array( $acum ) ) {
            $acum = [ 'total' => 0, 'actualizados' => 0, 'sin_sku' => 0, 'errores' => 0, 'detalles' => [] ];
        }
        $acum['total']        += $total;
        $acum['actualizados'] += $actualizados;
        $acum['sin_sku']      += $sin_sku;
        $acum['errores']      += $errores;

        // Acumular detalles: máximo 100 para no explotar la memoria.
        $acum['detalles'] = wevica_sync_truncate_detalles(
            array_merge( $acum['detalles'], $detalles ),
            100
        );

        if ( $is_last_batch ) {
            set_time_limit( $timeout_final );

            // Logging robusto: intentar el log completo, si falla intentar mínimo.
            $log_ok = false;
            try {
                wevica_sync_log( $tienda, $tipo, $acum['total'], $acum['actualizados'], $acum['sin_sku'], $acum['errores'], $acum['detalles'] );
                $log_ok = true;
            } catch ( \Throwable $e ) {
                error_log( 'Wevica sync_log error: ' . $e->getMessage() );
            }

            // Si el log completo falló, intentar sin detalles.
            if ( ! $log_ok ) {
                try {
                    wevica_sync_log( $tienda, $tipo, $acum['total'], $acum['actualizados'], $acum['sin_sku'], $acum['errores'], [] );
                    $log_ok = true;
                } catch ( \Throwable $e ) {
                    error_log( 'Wevica sync_log fallback also failed: ' . $e->getMessage() );
                }
            }

            // Solo eliminar el transient si el logging fue exitoso
            if ( $log_ok ) {
                delete_transient( $transient_key );
            }

            $total        = $acum['total'];
            $actualizados = $acum['actualizados'];
            $sin_sku      = $acum['sin_sku'];
            $errores      = $acum['errores'];

            try {
                ssp_dispatch_webhook( 'sync_complete', [
                    'tienda'       => $tienda,
                    'tipo'         => $tipo,
                    'total'        => $total,
                    'actualizados' => $actualizados,
                    'sin_sku'      => $sin_sku,
                    'errores'      => $errores,
                    'dry_run'      => $dry_run,
                ] );
            } catch ( \Throwable $e ) {
                error_log( 'Wevica webhook error: ' . $e->getMessage() );
            }
        } else {
            // Transient timeout debe ser mayor que timeout_final para evitar perder datos si un batch toma mucho tiempo
            $transient_timeout = max( 2 * HOUR_IN_SECONDS, 2 * $timeout_final );
            set_transient( $transient_key, $acum, $transient_timeout );
        }
    } else {
        // Sin sync_id: comportamiento original, una entrada por lote.
        try {
            wevica_sync_log( $tienda, $tipo, $total, $actualizados, $sin_sku, $errores, $detalles );
        } catch ( \Throwable $e ) {
            error_log( 'Wevica sync_log error (single batch): ' . $e->getMessage() );
        }

        try {
            ssp_dispatch_webhook( 'sync_complete', [
                'tienda'       => $tienda,
                'tipo'         => $tipo,
                'total'        => $total,
                'actualizados' => $actualizados,
                'sin_sku'      => $sin_sku,
                'errores'      => $errores,
                'dry_run'      => $dry_run,
            ] );
        } catch ( \Throwable $e ) {
            error_log( 'Wevica webhook error (single batch): ' . $e->getMessage() );
        }
    }

    return [
        'total'        => $total,
        'actualizados' => $actualizados,
        'sin_sku'      => $sin_sku,
        'errores'      => $errores,
        'detalles'     => $detalles,
        'dry_run'      => $dry_run,
    ];
}

// ═══════════════════════════════════════════════════════════════════
//  LOGGING
// ═══════════════════════════════════════════════════════════════════

/**
 * Graba una entrada en el historial de sincronizaciones.
 *
 * @param string $tienda        Nombre de la tienda.
 * @param string $tipo          Tipo de sync.
 * @param int    $total         Total de productos procesados.
 * @param int    $actualizados  Número de productos actualizados.
 * @param int    $sin_sku       Número de filas sin SKU o SKU no encontrado.
 * @param int    $errores       Número de errores.
 * @param array  $detalles      Array de detalles item a item.
 */
function wevica_sync_log( $tienda, $tipo, $total, $actualizados, $sin_sku, $errores, $detalles = [] ) {
    global $wpdb;
    $table = $wpdb->prefix . WEVICA_SYNC_TABLE;

    // Configuración del límite de detalles y tamaño JSON
    $detail_limit = (int) get_option( 'wevica_sync_detail_limit', 200 );
    $json_max_size = (int) get_option( 'wevica_sync_json_max_size', 65000 );
    $detail_fallback = max( 10, (int) ( $detail_limit / 4 ) ); // Fallback a 1/4 del límite normal

    $detalles_truncados = wevica_sync_truncate_detalles( $detalles, $detail_limit );
    $json = wp_json_encode( $detalles_truncados, JSON_UNESCAPED_UNICODE );

    // Limitar tamaño del JSON para evitar exceder la columna.
    // Reintentar con límites progresivamente menores hasta que quepa
    $truncation_attempts = 0;
    $current_limit = $detail_limit;
    while ( strlen( $json ) > $json_max_size && $truncation_attempts < 5 ) {
        $current_limit = max( 1, (int) ( $current_limit / 2 ) );
        $detalles_truncados = wevica_sync_truncate_detalles( $detalles, $current_limit );
        $json = wp_json_encode( $detalles_truncados, JSON_UNESCAPED_UNICODE );
        $truncation_attempts++;
    }

    // Si aún no cabe, usar solo resumen sin detalles
    if ( strlen( $json ) > $json_max_size ) {
        $json = wp_json_encode( [
            'resumido' => true,
            'total'    => count( $detalles ),
            'nota'     => 'Detalles excedieron límite de almacenamiento',
        ], JSON_UNESCAPED_UNICODE );
    }

    $result = $wpdb->insert( $table, [
        'tienda'          => sanitize_text_field( $tienda ),
        'tipo'            => sanitize_text_field( $tipo ),
        'total_productos' => (int) $total,
        'actualizados'    => (int) $actualizados,
        'sin_sku'         => (int) $sin_sku,
        'errores'         => (int) $errores,
        'detalles'        => $json,
        'fecha'           => current_time( 'mysql' ),
    ] );

    if ( false === $result ) {
        error_log( 'Wevica sync_log INSERT failed: ' . $wpdb->last_error );
    }
}
