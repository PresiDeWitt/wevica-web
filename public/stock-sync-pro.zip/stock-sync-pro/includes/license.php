<?php
/**
 * Stock Sync Pro — Sync Engine license & registry.
 *
 * El plugin es gratuito y no requiere licencia propia.
 * La licencia se aplica únicamente al servicio Wévica Sync Engine.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Constants ────────────────────────────────────────────────────────────────

define( 'SSP_REGISTRY_REGISTER',       'https://wevica-plugin.vercel.app/api/registry/register' );
define( 'SSP_REGISTRY_UNREGISTER',     'https://wevica-plugin.vercel.app/api/registry/unregister' );
define( 'SSP_SYNCENGINE_API',          'https://wevica-plugin.vercel.app/api/syncengine/validate' );
define( 'SSP_SYNCENGINE_ACTIVATE',     'https://wevica-plugin.vercel.app/api/syncengine/activate' );
define( 'SSP_SYNCENGINE_DEACTIVATE',   'https://wevica-plugin.vercel.app/api/syncengine/deactivate' );
define( 'SSP_ONBOARDING_URL',          'https://wevica-plugin.vercel.app/api/onboarding' );
define( 'SSP_PURCHASE_URL',            'https://stocksync.es/pricing' );
define( 'SSP_SYNCENGINE_PURCHASE_URL', 'https://stocksync.es/pricing#sync-engine-heading' );
define( 'SSP_VALIDATION_GRACE_HOURS',  72 );
define( 'SSP_VALIDATION_GRACE_SECONDS', SSP_VALIDATION_GRACE_HOURS * HOUR_IN_SECONDS );

// ── Plugin siempre libre ──────────────────────────────────────────────────────

/**
 * El plugin es siempre gratuito — no requiere licencia propia.
 * Los límites de plan solo aplican si el sitio no tiene Sync Engine activo.
 *
 * @return bool Always true.
 */
function ssp_is_licensed(): bool {
    return true;
}

// ── Sync Engine ───────────────────────────────────────────────────────────────

/**
 * Returns true if the Wévica Sync Engine service is active for this site.
 * Validates the stored Sync Engine key remotely once per day (cached in transient).
 * Uses a grace window if the validation server is temporarily unreachable.
 *
 * @return bool
 */
function ssp_autosync_is_active(): bool {
    $key = get_option( 'ssp_syncengine_key', '' );
    if ( empty( $key ) ) {
        return false;
    }

    // Check transient cache (24 h for active, 1 h for inactive).
    $cached = get_transient( 'ssp_syncengine_status' );
    if ( $cached === 'active' ) {
        return true;
    }
    if ( $cached === 'inactive' ) {
        return false;
    }

    // Remote validation.
    $instance_id = get_option( 'ssp_syncengine_instance_id', '' );
    $remote      = ssp_validate_syncengine_remote( $key, $instance_id );

    if ( $remote === 'active' ) {
        update_option( 'ssp_autosync_active', '1' );
        update_option( 'ssp_syncengine_last_validated_at', time() );
        set_transient( 'ssp_syncengine_status', 'active', DAY_IN_SECONDS );
        return true;
    }

    if ( $remote === 'invalid' ) {
        update_option( 'ssp_autosync_active', '0' );
        delete_option( 'ssp_syncengine_last_validated_at' );
        set_transient( 'ssp_syncengine_status', 'inactive', HOUR_IN_SECONDS );
        return false;
    }

    // Remote unavailable: allow only during grace window to preserve UX without indefinite bypass.
    $last_ok = (int) get_option( 'ssp_syncengine_last_validated_at', 0 );
    if ( get_option( 'ssp_autosync_active', '0' ) === '1' && $last_ok > 0 && ( time() - $last_ok ) <= SSP_VALIDATION_GRACE_SECONDS ) {
        return true;
    }

    update_option( 'ssp_autosync_active', '0' );
    set_transient( 'ssp_syncengine_status', 'inactive', HOUR_IN_SECONDS );
    return false;
}

/**
 * Calls the remote Sync Engine validation server.
 *
 * @param  string $key         Sync Engine license key.
 * @param  string $instance_id Instance ID returned on activation.
 * @return string 'active', 'invalid', or 'unavailable'.
 */
function ssp_validate_syncengine_remote( string $key, string $instance_id = '' ): string {
    $payload = [ 'key' => $key ];
    if ( ! empty( $instance_id ) ) {
        $payload['instance_id'] = $instance_id;
    }

    $response = wp_remote_post( SSP_SYNCENGINE_API, [
        'timeout' => 10,
        'headers' => [ 'Content-Type' => 'application/json' ],
        'body'    => wp_json_encode( $payload ),
    ] );

    if ( is_wp_error( $response ) ) {
        return 'unavailable';
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
        return 'unavailable';
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( isset( $body['status'] ) && $body['status'] === 'active' ) {
        // Refresh plan info on each successful remote validation.
        if ( ! empty( $body['plan'] ) ) {
            update_option( 'ssp_plan_slug', sanitize_key( $body['plan'] ) );
        }
        if ( ! empty( $body['plan_name'] ) ) {
            update_option( 'ssp_plan_name', sanitize_text_field( $body['plan_name'] ) );
        }
        if ( ! empty( $body['limits'] ) && is_array( $body['limits'] ) ) {
            update_option( 'ssp_plan_limits', $body['limits'] );
        }
        return 'active';
    }

    return 'invalid';
}

/**
 * Activates the Sync Engine service on this site via the remote server.
 *
 * @param  string $key Plain-text Sync Engine license key.
 * @return array{ status: string, instance_id: string, message: string }
 */
function ssp_activate_syncengine_remote( string $key ): array {
    $response = wp_remote_post( SSP_SYNCENGINE_ACTIVATE, [
        'timeout' => 15,
        'headers' => [ 'Content-Type' => 'application/json' ],
        'body'    => wp_json_encode( [
            'key'      => $key,
            'site_url' => home_url(),
        ] ),
    ] );

    if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
        return [ 'status' => 'invalid', 'instance_id' => '', 'message' => 'Connection error.' ];
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    return [
        'status'      => $body['status']      ?? 'invalid',
        'instance_id' => $body['instance_id'] ?? '',
        'message'     => $body['message']     ?? '',
        'plan'        => $body['plan']        ?? '',
        'plan_name'   => $body['plan_name']   ?? '',
        'limits'      => $body['limits']      ?? [],
    ];
}

/**
 * Deactivates the Sync Engine service on this site, freeing the activation slot.
 *
 * @param  string $key         Sync Engine license key.
 * @param  string $instance_id Instance ID stored on activation.
 * @return bool True if deactivated successfully.
 */
function ssp_deactivate_syncengine_remote( string $key, string $instance_id ): bool {
    if ( empty( $key ) ) {
        return true;
    }

    $response = wp_remote_post( SSP_SYNCENGINE_DEACTIVATE, [
        'timeout' => 10,
        'headers' => [ 'Content-Type' => 'application/json' ],
        'body'    => wp_json_encode( [
            'key'         => $key,
            'instance_id' => $instance_id,
        ] ),
    ] );

    if ( is_wp_error( $response ) ) {
        return false;
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    return ( isset( $body['status'] ) && $body['status'] === 'deactivated' );
}

// ── AJAX — activar Sync Engine ────────────────────────────────────────────────

add_action( 'wp_ajax_ssp_activate_syncengine', 'ssp_ajax_activate_syncengine' );

function ssp_ajax_activate_syncengine() {
    check_ajax_referer( 'ssp_license_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Sin permisos.', 'stock-sync-pro' ) ] );
    }

    $key = sanitize_text_field( wp_unslash( $_POST['syncengine_key'] ?? '' ) );
    if ( empty( $key ) ) {
        wp_send_json_error( [ 'message' => __( 'Introduce una clave de Sync Engine.', 'stock-sync-pro' ) ] );
    }

    $result = ssp_activate_syncengine_remote( $key );

    if ( $result['status'] === 'active' ) {
        update_option( 'ssp_syncengine_key', $key );
        update_option( 'ssp_syncengine_instance_id', $result['instance_id'] );
        update_option( 'ssp_autosync_active', '1' );
        delete_transient( 'ssp_syncengine_status' );

        // Store plan info from activation response.
        if ( ! empty( $result['plan'] ) ) {
            update_option( 'ssp_plan_slug', sanitize_key( $result['plan'] ) );
        }
        if ( ! empty( $result['plan_name'] ) ) {
            update_option( 'ssp_plan_name', sanitize_text_field( $result['plan_name'] ) );
        }
        if ( ! empty( $result['limits'] ) && is_array( $result['limits'] ) ) {
            update_option( 'ssp_plan_limits', $result['limits'] );
        }

        // Auto-generar API key dedicada para el Sync Engine si no existe ya.
        $se_plain_key = ssp_provision_syncengine_api_key();

        // Registrar en el Registry (automático) + Telegram como backup.
        ssp_register_with_registry();
        if ( ! empty( $se_plain_key ) ) {
            ssp_notify_syncengine_developer( $key, $se_plain_key );
        }

        wp_send_json_success( [ 'message' => __( '¡Sync Engine activado! La sección de Auto-sync está desbloqueada.', 'stock-sync-pro' ) ] );
    } else {
        wp_send_json_error( [ 'message' => __( 'Clave de Sync Engine inválida o ya usada en otro sitio.', 'stock-sync-pro' ) ] );
    }
}

// ── Sync Engine onboarding ────────────────────────────────────────────────────

/**
 * Crea (o reutiliza) una API key dedicada para el Wévica Sync Engine.
 * Guarda la clave en texto plano en un transient de 24 h para que el admin
 * pueda verla. Devuelve la clave en texto plano, o '' si ya existía.
 *
 * @return string Clave en texto plano (solo disponible justo después de crearla).
 */
function ssp_provision_syncengine_api_key(): string {
    // Si ya hay una key designada para sync engine y todavía existe en el array, no crear otra.
    $existing_id = get_option( 'ssp_syncengine_woo_key_id', '' );
    if ( $existing_id ) {
        foreach ( ssp_get_api_keys() as $k ) {
            if ( $k['id'] === $existing_id ) {
                return ''; // Ya existe; no volvemos a mostrarla (fue hasheada).
            }
        }
    }

    // Crear nueva API key nombrada "Wévica Sync Engine".
    $plain_key = ssp_create_api_key( 'Wévica Sync Engine' );

    // Guardar el ID de la key recién creada para identificarla en el futuro.
    $keys = ssp_get_api_keys();
    $new  = end( $keys );
    if ( $new ) {
        update_option( 'ssp_syncengine_woo_key_id', $new['id'] );
    }

    // Guardar en transient 24 h para mostrarla en el panel de licencia.
    set_transient( 'ssp_syncengine_setup_key', $plain_key, DAY_IN_SECONDS );

    return $plain_key;
}

/**
 * Notifica al desarrollador de forma asíncrona (non-blocking) cuando un cliente
 * activa el Sync Engine. Envía la URL del sitio, la API key de WooCommerce y
 * el email del admin para que el dev pueda configurar el scraper sin preguntar.
 *
 * @param string $se_license_key  Clave de licencia del Sync Engine (valida que es cliente real).
 * @param string $woo_api_key     API key de WooCommerce generada para el Sync Engine.
 */
function ssp_notify_syncengine_developer( string $se_license_key, string $woo_api_key ): void {
    $notify_url = 'https://wevica-plugin.vercel.app/api/syncengine/notify';

    wp_remote_post( $notify_url, [
        'timeout'  => 8,
        'blocking' => false, // Non-blocking: no esperar respuesta, continuar inmediatamente.
        'headers'  => [ 'Content-Type' => 'application/json' ],
        'body'     => wp_json_encode( [
            'se_key'           => $se_license_key,
            'site_url'         => home_url(),
            'plugin_endpoint'  => home_url( '/wp-json/stocksync/v1/sync' ),
            'woo_api_key'      => $woo_api_key,
            'admin_email'      => get_option( 'admin_email', '' ),
            'supplier_url'     => get_option( 'ssp_supplier_url', '' ),
        ] ),
    ] );
}

// ── AJAX — desactivar Sync Engine ─────────────────────────────────────────────

add_action( 'wp_ajax_ssp_deactivate_syncengine', 'ssp_ajax_deactivate_syncengine' );

function ssp_ajax_deactivate_syncengine() {
    check_ajax_referer( 'ssp_license_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error();
    }

    $key         = get_option( 'ssp_syncengine_key', '' );
    $instance_id = get_option( 'ssp_syncengine_instance_id', '' );

    if ( ! empty( $key ) ) {
        ssp_deactivate_syncengine_remote( $key, $instance_id );
        ssp_unregister_from_registry();
    }

    delete_option( 'ssp_syncengine_key' );
    delete_option( 'ssp_syncengine_instance_id' );
    delete_option( 'ssp_registry_site_hash' );
    delete_option( 'ssp_registry_woo_api_key' );
    delete_option( 'ssp_registry_subscription_id' );
    update_option( 'ssp_autosync_active', '0' );
    delete_transient( 'ssp_syncengine_status' );
    wp_send_json_success( [ 'message' => __( 'Sync Engine desactivado.', 'stock-sync-pro' ) ] );
}

// ── Registry API ──────────────────────────────────────────────────────────────

/**
 * Computes the HMAC-SHA256 signature for a registry request body.
 * Uses the stored Sync Engine key as the HMAC secret.
 *
 * @param  string $body Raw JSON request body.
 * @return string Hex HMAC-SHA256 digest, or '' if no SE key is stored.
 */
function ssp_registry_hmac( string $body ): string {
    $se_key = get_option( 'ssp_syncengine_key', '' );
    if ( empty( $se_key ) ) {
        return '';
    }
    return hash_hmac( 'sha256', $body, $se_key );
}

/**
 * Registers this site with the central Registry API.
 * Called automatically after Sync Engine activation.
 */
function ssp_register_with_registry(): void {
    $se_key = get_option( 'ssp_syncengine_key', '' );
    if ( empty( $se_key ) ) {
        return;
    }

    $woo_api_key = get_option( 'ssp_registry_woo_api_key', '' );
    if ( empty( $woo_api_key ) ) {
        // Retrieve the dedicated SE key plain text from transient (24 h window).
        $woo_api_key = (string) get_transient( 'ssp_syncengine_setup_key' );
    }

    $payload = [
        'site_url'         => home_url(),
        'plugin_endpoint'  => home_url( '/wp-json/stocksync/v1/sync' ),
        'se_key'           => $se_key,
        'woo_api_key'      => $woo_api_key,
        'admin_email'      => get_option( 'admin_email', '' ),
        'version'          => defined( 'WEVICA_SYNC_VERSION' ) ? WEVICA_SYNC_VERSION : '',
        'source_url'       => get_option( 'ssp_cron_source_url', '' ),
        'source_type'      => get_option( 'ssp_cron_source_type', 'auto' ),
        'frequency_minutes'=> ssp_cron_interval_to_minutes( (string) get_option( 'ssp_cron_interval', 'off' ) ),
    ];
    $body = wp_json_encode( $payload );
    $sig  = ssp_registry_hmac( $body );

    $response = wp_remote_post( SSP_REGISTRY_REGISTER, [
        'timeout' => 15,
        'headers' => [
            'Content-Type'   => 'application/json',
            'X-SE-Signature' => $sig,
        ],
        'body' => $body,
    ] );

    if ( is_wp_error( $response ) ) {
        return;
    }

    $resp_body = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( ! empty( $resp_body['site_hash'] ) ) {
        update_option( 'ssp_registry_site_hash', $resp_body['site_hash'] );
    }
    if ( ! empty( $resp_body['subscription_id'] ) ) {
        update_option( 'ssp_registry_subscription_id', $resp_body['subscription_id'] );
    }
    if ( ! empty( $woo_api_key ) ) {
        update_option( 'ssp_registry_woo_api_key', $woo_api_key );
    }
}

/**
 * Unregisters this site from the central Registry API.
 * Called on Sync Engine deactivation or plugin uninstall.
 */
function ssp_unregister_from_registry(): void {
    $se_key    = get_option( 'ssp_syncengine_key', '' );
    $site_hash = get_option( 'ssp_registry_site_hash', '' );

    if ( empty( $se_key ) ) {
        return;
    }

    $payload = [
        'site_url'  => home_url(),
        'se_key'    => $se_key,
        'site_hash' => $site_hash,
    ];
    $body = wp_json_encode( $payload );
    $sig  = ssp_registry_hmac( $body );

    wp_remote_post( SSP_REGISTRY_UNREGISTER, [
        'timeout'  => 10,
        'blocking' => false,
        'headers'  => [
            'Content-Type'   => 'application/json',
            'X-SE-Signature' => $sig,
        ],
        'body' => $body,
    ] );
}

/**
 * Converts a WordPress cron interval slug to the equivalent number of minutes.
 *
 * @param  string $interval Cron interval slug (e.g. 'hourly', 'ssp_30min').
 * @return int Minutes per interval. Returns 0 for 'off' or unknown slugs.
 */
function ssp_cron_interval_to_minutes( string $interval ): int {
    $map = [
        'ssp_5min'    => 5,
        'ssp_30min'   => 30,
        'ssp_2hours'  => 120,
        'hourly'      => 60,
        'twicedaily'  => 720,
        'daily'       => 1440,
        'weekly'      => 10080,
        'off'         => 0,
    ];
    return $map[ $interval ] ?? 0;
}
