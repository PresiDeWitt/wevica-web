<?php
/**
 * Plugin Name:       Stock Sync Pro
 * Plugin URI:        https://stocksync.es
 * Description:       Syncs WooCommerce stock automatically from any external source (scrapers, ERPs, price feeds) via a secure REST API with multi-key support, cron, and webhooks.
 * Version:           4.9.2
 * Author:            Alejandro Chacón
 * Author URI:        https://wevica.com
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 5.0
 * License:           GPL-2.0-or-later
 * Text Domain:       stock-sync-pro
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ═══════════════════════════════════════════════════════════════════
//  COMPATIBILIDAD — comprobar PHP y WooCommerce ANTES de cargar nada
//  Evita errores fatales que harían que WordPress desactivase el plugin.
// ═══════════════════════════════════════════════════════════════════
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
    add_action( 'admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>Stock Sync Pro</strong> requiere PHP 7.4 o superior. Versión actual: ' . esc_html( PHP_VERSION ) . '. El plugin está desactivado.</p></div>';
    } );
    return;
}

add_action( 'plugins_loaded', function() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>Stock Sync Pro</strong> requiere WooCommerce activo. El plugin está desactivado hasta que WooCommerce se active.</p></div>';
        } );
    }
}, 20 );

// ═══════════════════════════════════════════════════════════════════
//  CONSTANTS
// ═══════════════════════════════════════════════════════════════════
define( 'WEVICA_SYNC_VERSION', '4.9.2' );
define( 'WEVICA_SYNC_FILE',    __FILE__ );
define( 'WEVICA_SYNC_DIR',     plugin_dir_path( __FILE__ ) );
define( 'WEVICA_SYNC_URL',     plugin_dir_url( __FILE__ ) );
define( 'WEVICA_SYNC_TABLE',   'wevica_sync_log' );

// URL del servidor de actualizaciones (se puede sobreescribir en wp-config.php).
if ( ! defined( 'WEVICA_UPDATE_URL' ) ) {
    define( 'WEVICA_UPDATE_URL', 'https://wevica-plugin.vercel.app/api/wevica-stock-sync/info' );
}

// La configuración del motor de sincronización (URL + clave) se obtiene
// dinámicamente desde el Registry de Vercel (wevica-plugin.vercel.app).
// No hay secretos en este archivo ni en wp-config.php del cliente.


// ═══════════════════════════════════════════════════════════════════
//  DEPENDENCIAS
// ═══════════════════════════════════════════════════════════════════
require_once WEVICA_SYNC_DIR . 'includes/helpers.php';
require_once WEVICA_SYNC_DIR . 'includes/license.php';
require_once WEVICA_SYNC_DIR . 'includes/subscriptions.php';
require_once WEVICA_SYNC_DIR . 'includes/billing-settings.php';
require_once WEVICA_SYNC_DIR . 'includes/plan-validation.php';
require_once WEVICA_SYNC_DIR . 'includes/sync-engine-client.php';
require_once WEVICA_SYNC_DIR . 'includes/webhook.php';
require_once WEVICA_SYNC_DIR . 'includes/sync.php';
require_once WEVICA_SYNC_DIR . 'includes/cron.php';
require_once WEVICA_SYNC_DIR . 'includes/api.php';
require_once WEVICA_SYNC_DIR . 'includes/admin.php';

add_action( 'init', function() {
    load_plugin_textdomain( 'stock-sync-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

// ── Compatibilidad WooCommerce HPOS + Block Editor ──────────────────
add_action( 'before_woocommerce_init', function() {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables',  __FILE__, true );
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'product_block_editor', __FILE__, true );
    }
} );

// ═══════════════════════════════════════════════════════════════════
//  ACTIVACIÓN / DESACTIVACIÓN
// ═══════════════════════════════════════════════════════════════════
register_activation_hook( __FILE__, 'wevica_sync_activate' );
register_deactivation_hook( __FILE__, 'wevica_sync_deactivate' );

function wevica_sync_activate() {
    global $wpdb;
    $table   = $wpdb->prefix . WEVICA_SYNC_TABLE;
    $charset = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        tienda          VARCHAR(100) NOT NULL DEFAULT '',
        tipo            VARCHAR(20)  NOT NULL DEFAULT 'manual',
        total_productos INT          NOT NULL DEFAULT 0,
        actualizados    INT          NOT NULL DEFAULT 0,
        sin_sku         INT          NOT NULL DEFAULT 0,
        errores         INT          NOT NULL DEFAULT 0,
        detalles        LONGTEXT,
        fecha           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_tienda (tienda),
        KEY idx_fecha  (fecha)
    ) {$charset};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );

    // Create subscription tables
    ssp_create_subscription_tables();

    // Record activation date for trial (only on first activation).
    if ( ! get_option( 'ssp_activated_at' ) ) {
        update_option( 'ssp_activated_at', time() );
    }

    // Create default API key if none exist yet.
    if ( ! get_option( 'wevica_sync_api_key_hash' ) && ! get_option( 'wevica_sync_api_key' ) && empty( ssp_get_api_keys() ) ) {
        $plain_key = wp_generate_password( 40, false );
        ssp_create_api_key( 'Default', $plain_key );
        // Use an option (not a transient) so it never expires before the user sees it.
        update_option( 'ssp_setup_key', $plain_key, 'no' );
    }

    add_option( 'wevica_sync_stock_unknown', 'skip' );
    add_option( 'wevica_sync_dry_run',       '0' );
    add_option( 'wevica_sync_update_price',  '0' );
    add_option( 'wevica_sync_log_retention', '90' );
    add_option( 'ssp_webhook_queue', [], '', 'no' );
    add_option( 'ssp_notify_on_error',          '1' );
    add_option( 'ssp_notify_on_webhook_dead',   '1' );
    add_option( 'ssp_notify_email',             '' );
    add_option( 'ssp_exclude_skus',             '' );
    add_option( 'ssp_syncengine_key',           '' );
    add_option( 'ssp_syncengine_instance_id',   '' );
    if ( ! class_exists( 'WooCommerce' ) ) {
        set_transient( 'wevica_sync_notice_wc', true, 30 );
    }

    update_option( 'wevica_sync_version', WEVICA_SYNC_VERSION );

    // Instalar el watchdog MU-plugin automáticamente.
    ssp_watchdog_install();
}

function wevica_sync_deactivate() {
    wp_clear_scheduled_hook( 'wevica_sync_cleanup_logs' );
    wp_clear_scheduled_hook( 'ssp_auto_sync' );
    wp_clear_scheduled_hook( 'ssp_webhook_retry' );

    // Unregister from Registry if Sync Engine was active.
    if ( function_exists( 'ssp_unregister_from_registry' ) && ! empty( get_option( 'ssp_syncengine_key', '' ) ) ) {
        ssp_unregister_from_registry();
    }
}

/**
 * Copia el watchdog MU-plugin a wp-content/mu-plugins/ si no está ya ahí
 * o si la versión instalada es más antigua.
 *
 * Se llama en la activación del plugin y en cada actualización.
 */
function ssp_watchdog_install(): void {
    $origen  = WEVICA_SYNC_DIR . 'mu-watchdog/ssp-watchdog.php';
    $destino = WP_CONTENT_DIR . '/mu-plugins/ssp-watchdog.php';

    // Eliminar el watchdog con nombre antiguo si existe en clientes ya instalados.
    $destino_legacy = WP_CONTENT_DIR . '/mu-plugins/wevica-watchdog.php';
    if ( file_exists( $destino_legacy ) ) {
        @unlink( $destino_legacy );
    }

    if ( ! file_exists( $origen ) ) {
        return;
    }

    // Crear la carpeta mu-plugins si no existe.
    if ( ! is_dir( WP_CONTENT_DIR . '/mu-plugins' ) ) {
        wp_mkdir_p( WP_CONTENT_DIR . '/mu-plugins' );
    }

    // Solo copiar si el destino no existe o el origen es más nuevo.
    if ( ! file_exists( $destino ) || filemtime( $origen ) > filemtime( $destino ) ) {
        @copy( $origen, $destino );
    }
}

// Reinstalar el watchdog también en cada actualización del plugin.
add_action( 'upgrader_process_complete', function( $upgrader, $hook_extra ) {
    $plugins = $hook_extra['plugins'] ?? [];
    if ( in_array( plugin_basename( WEVICA_SYNC_FILE ), (array) $plugins, true ) ) {
        ssp_watchdog_install();
    }
}, 10, 2 );

// Auto-update: WordPress actualizará el plugin automáticamente.
add_filter( 'auto_update_plugin', function( $update, $item ) {
    if ( isset( $item->slug ) && $item->slug === 'wevica-stock-sync' ) {
        return true;
    }
    return $update;
}, 10, 2 );
