<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <!-- Header -->
    <div class="wv-page-header">
        <div class="wv-page-header-left">
            <a href="<?php echo esc_url( $back_url ); ?>" class="wv-back-link">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"/></svg>
                <?php esc_html_e( 'Historial', 'stock-sync-pro' ); ?>
            </a>
            <div>
                <h1 class="wv-page-title"><?php /* translators: %d: sync ID */ printf( esc_html__( 'Sync #%d', 'stock-sync-pro' ), (int) $id ); ?></h1>
                <p class="wv-page-subtitle"><?php echo esc_html( $log->fecha ); ?> · <?php echo esc_html( $log->tienda ?: esc_html__( 'Fuente no especificada', 'stock-sync-pro' ) ); ?></p>
            </div>
        </div>
    </div>

    <!-- Resumen numérico -->
    <div class="wv-summary-grid wv-fade-in">
        <div class="wv-summary-item">
            <div class="wv-summary-item-label"><?php esc_html_e( 'Total enviados', 'stock-sync-pro' ); ?></div>
            <div class="wv-summary-item-value"><?php echo esc_html( $log->total_productos ); ?></div>
        </div>
        <div class="wv-summary-item">
            <div class="wv-summary-item-label"><?php esc_html_e( 'Actualizados', 'stock-sync-pro' ); ?></div>
            <div class="wv-summary-item-value green"><?php echo esc_html( $log->actualizados ); ?></div>
        </div>
        <div class="wv-summary-item">
            <div class="wv-summary-item-label"><?php esc_html_e( 'Sin SKU', 'stock-sync-pro' ); ?></div>
            <div class="wv-summary-item-value"><?php echo esc_html( $log->sin_sku ); ?></div>
        </div>
        <div class="wv-summary-item">
            <div class="wv-summary-item-label"><?php esc_html_e( 'Errores', 'stock-sync-pro' ); ?></div>
            <div class="wv-summary-item-value <?php echo $log->errores > 0 ? 'red' : ''; ?>">
                <?php echo esc_html( $log->errores ); ?>
            </div>
        </div>
        <div class="wv-summary-item">
            <div class="wv-summary-item-label"><?php esc_html_e( 'Página', 'stock-sync-pro' ); ?></div>
            <div class="wv-summary-item-value" style="font-size:18px;">
                <?php echo (int) $current_page; ?> / <?php echo (int) $total_pages; ?>
            </div>
        </div>
        <div class="wv-summary-item">
            <div class="wv-summary-item-label"><?php esc_html_e( 'Items en página', 'stock-sync-pro' ); ?></div>
            <div class="wv-summary-item-value" style="font-size:18px;"><?php echo (int) $total_items; ?></div>
        </div>
    </div>

    <?php if ( $count_dry_run > 0 ) : ?>
        <div class="notice notice-warning wv-fade-in" style="margin:0 0 16px;padding:10px 14px;border-left-color:#f0b429;">
            <p><strong><?php esc_html_e( 'Modo prueba activo', 'stock-sync-pro' ); ?></strong> — <?php esc_html_e( 'Esta sync se ejecutó en modo vista previa. Los stocks NO se han modificado en WooCommerce. Desactiva "Modo prueba" en Ajustes para aplicar los cambios reales.', 'stock-sync-pro' ); ?></p>
        </div>
    <?php endif; ?>

    <?php if ( empty( $page_items ) && $total_items === 0 ) : ?>
        <div class="wv-empty">
            <div class="wv-empty-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5z" clip-rule="evenodd"/></svg>
            </div>
            <p class="wv-empty-title"><?php esc_html_e( 'Sin detalles guardados', 'stock-sync-pro' ); ?></p>
            <p class="wv-empty-sub"><?php esc_html_e( 'Esta sync no tiene datos de detalle almacenados.', 'stock-sync-pro' ); ?></p>
        </div>
    <?php else : ?>

        <!-- Toolbar: tabs + search -->
        <div class="wv-toolbar wv-fade-in">
            <div class="wv-tabs">
                <button class="wv-tab active" data-filter="all">
                    <?php esc_html_e( 'Todos', 'stock-sync-pro' ); ?>
                    <span class="wv-tab-count"><?php echo (int) $total_items; ?></span>
                </button>
                <?php if ( $count_actualizados ) : ?>
                <button class="wv-tab" data-filter="instock">
                    <?php esc_html_e( 'Con stock', 'stock-sync-pro' ); ?>
                    <span class="wv-tab-count"><?php echo (int) $count_actualizados; ?></span>
                </button>
                <?php endif; ?>
                <?php if ( $count_errores ) : ?>
                <button class="wv-tab" data-filter="error">
                    <?php esc_html_e( 'Errores', 'stock-sync-pro' ); ?>
                    <span class="wv-tab-count wv-tab-count-err"><?php echo (int) $count_errores; ?></span>
                </button>
                <?php endif; ?>
                <?php if ( $count_sin_sku ) : ?>
                <button class="wv-tab" data-filter="sin_sku">
                    <?php esc_html_e( 'Sin SKU', 'stock-sync-pro' ); ?>
                    <span class="wv-tab-count"><?php echo (int) $count_sin_sku; ?></span>
                </button>
                <?php endif; ?>
                <?php if ( $count_dry_run ) : ?>
                <button class="wv-tab" data-filter="dry_run">
                    <?php esc_html_e( 'Vista previa', 'stock-sync-pro' ); ?>
                    <span class="wv-tab-count"><?php echo (int) $count_dry_run; ?></span>
                </button>
                <?php endif; ?>
            </div>

            <div class="wv-search">
                <svg class="wv-search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"/></svg>
                <input type="text" id="wv-search" class="wv-search-input" placeholder="<?php esc_attr_e( 'Buscar SKU o nombre…', 'stock-sync-pro' ); ?>">
            </div>
        </div>

        <!-- Grid de productos -->
        <div class="wv-detail-grid wv-fade-in" id="wv-grid">

            <?php foreach ( $page_items as $item ) : ?>

                <?php if ( is_string( $item ) ) :
                    $clase_leg = strpos( $item, 'instock' ) !== false ? 'wv-stock-pill-in'
                        : ( strpos( $item, 'outofstock' ) !== false ? 'wv-stock-pill-out' : 'wv-stock-pill-err' );
                ?>
                    <div class="wv-product-card" data-stock="legacy">
                        <div class="wv-product-info">
                            <div class="wv-product-sku" style="font-size:11px;">
                                <span><?php echo esc_html( $item ); ?></span>
                                <span class="wv-stock-pill <?php echo esc_attr( $clase_leg ); ?>">legacy</span>
                            </div>
                        </div>
                    </div>

                <?php elseif ( is_array( $item ) ) :
                    $tipo   = $item['tipo']    ?? 'actualizado';
                    $sku    = $item['sku']     ?? '';
                    $nombre = $item['nombre']  ?? '';
                    $stock  = $item['stock']   ?? '';
                    $msg    = $item['mensaje'] ?? '';

                    if ( $tipo === 'actualizado' ) {
                        $data_stock  = $stock;
                        $pill_class  = $stock === 'instock' ? 'wv-stock-pill-in' : 'wv-stock-pill-out';
                        $pill_label  = $stock === 'instock' ? '✓ ' . __( 'Con stock', 'stock-sync-pro' ) : '✗ ' . __( 'Sin stock', 'stock-sync-pro' );
                    } elseif ( $tipo === 'dry_run_preview' ) {
                        $stock_preview = $item['stock'] ?? '';
                        $data_stock  = 'dry_run';
                        $pill_class  = 'wv-stock-pill-skip';
                        $pill_label  = '👁 ' . __( 'Vista previa', 'stock-sync-pro' );
                    } elseif ( $tipo === 'no_encontrado' ) {
                        $data_stock  = 'sin_sku';
                        $pill_class  = 'wv-stock-pill-skip';
                        $pill_label  = __( 'Sin SKU', 'stock-sync-pro' );
                    } elseif ( $tipo === 'error' ) {
                        $data_stock  = 'error';
                        $pill_class  = 'wv-stock-pill-err';
                        $pill_label  = '⚠ ' . __( 'Error', 'stock-sync-pro' ); // "Error" is the same in Spanish
                    } elseif ( $tipo === 'aviso' ) {
                        $data_stock  = 'aviso';
                        $pill_class  = 'wv-stock-pill-err';
                        $pill_label  = '⚠ ' . __( 'Aviso', 'stock-sync-pro' );
                    } else {
                        $data_stock  = 'sin_sku';
                        $pill_class  = 'wv-stock-pill-skip';
                        $pill_label  = __( 'Sin SKU', 'stock-sync-pro' );
                    }

                    $pdata           = $product_data_map[ $sku ] ?? null;
                    $prod_link       = $pdata ? $pdata['link'] : '';
                    $prod_price_html = '';
                    $prod_img        = '';

                    if ( $pdata ) {
                        if ( $pdata['price'] !== '' ) {
                            $prod_price_html = wc_price( $pdata['price'] );
                        }
                        if ( ! empty( $pdata['thumb_url'] ) ) {
                            $prod_img = '<img src="' . esc_url( $pdata['thumb_url'] ) . '" class="wv-product-img" alt="" loading="lazy" width="56" height="56">';
                        }
                        if ( empty( $nombre ) ) {
                            $nombre = $pdata['title'];
                        }
                    }
                    if ( empty( $prod_img ) && function_exists( 'wc_placeholder_img' ) ) {
                        $prod_img = wc_placeholder_img( 'thumbnail', [ 'class' => 'wv-product-img' ] );
                    }
                ?>
                    <div class="wv-product-card"
                         data-sku="<?php echo esc_attr( strtolower( $sku ) ); ?>"
                         data-nombre="<?php echo esc_attr( strtolower( $nombre ) ); ?>"
                         data-stock="<?php echo esc_attr( $data_stock ); ?>">

                        <?php echo wp_kses_post( $prod_img ); ?>

                        <div class="wv-product-info">
                            <div class="wv-product-sku">
                                <?php if ( $prod_link ) : ?>
                                    <a href="<?php echo esc_url( $prod_link ); ?>" target="_blank"><?php echo esc_html( $sku ); ?></a>
                                <?php else : ?>
                                    <span><?php echo esc_html( $sku ); ?></span>
                                <?php endif; ?>
                                <span class="wv-stock-pill <?php echo esc_attr( $pill_class ); ?>">
                                    <?php echo esc_html( $pill_label ); ?>
                                </span>
                            </div>
                            <?php if ( $nombre ) : ?>
                                <div class="wv-product-name"><?php echo esc_html( $nombre ); ?></div>
                            <?php endif; ?>
                            <?php if ( $prod_price_html ) : ?>
                                <div class="wv-product-price"><?php echo wp_kses_post( $prod_price_html ); ?></div>
                            <?php endif; ?>
                            <?php if ( $msg && $tipo !== 'actualizado' ) : ?>
                                <div class="wv-product-msg"><?php echo esc_html( $msg ); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endif; ?>
            <?php endforeach; ?>

            <div class="wv-no-results"><?php esc_html_e( 'Ningún producto coincide con el filtro.', 'stock-sync-pro' ); ?></div>
        </div>

        <!-- Paginación -->
        <?php if ( $total_pages > 1 ) :
            $base_url = admin_url( 'admin.php?page=wevica-sync-detail&id=' . $id );
        ?>
            <div style="margin-top:20px;">
                <div class="wv-table-wrap">
                    <div class="wv-pagination">
                        <span class="wv-pagination-info">
                            <?php /* translators: %1$d: página actual, %2$d: total de páginas */ printf( esc_html__( 'Página %1$d de %2$d', 'stock-sync-pro' ), (int) $current_page, (int) $total_pages ); ?>
                        </span>
                        <div class="wv-pagination-pages">
                            <?php if ( $current_page > 1 ) : ?>
                                <a href="<?php echo esc_url( $base_url . '&pag=' . ( $current_page - 1 ) ); ?>" class="wv-page-btn">←</a>
                            <?php endif; ?>

                            <?php
                            $start = max( 1, $current_page - 3 );
                            $end   = min( $total_pages, $current_page + 3 );
                            for ( $p = $start; $p <= $end; $p++ ) :
                            ?>
                                <a href="<?php echo esc_url( $base_url . '&pag=' . $p ); ?>"
                                   class="wv-page-btn <?php echo $p === $current_page ? 'wv-page-btn-active' : ''; ?>">
                                    <?php echo (int) $p; ?>
                                </a>
                            <?php endfor; ?>

                            <?php if ( $current_page < $total_pages ) : ?>
                                <a href="<?php echo esc_url( $base_url . '&pag=' . ( $current_page + 1 ) ); ?>" class="wv-page-btn">→</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    <?php endif; ?>
</div>
