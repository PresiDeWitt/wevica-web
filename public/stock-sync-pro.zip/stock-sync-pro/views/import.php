<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <!-- Header -->
    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title"><?php esc_html_e( 'Importar CSV', 'stock-sync-pro' ); ?></h1>
            <p class="wv-page-subtitle"><?php esc_html_e( 'Sube un archivo CSV para actualizar el stock de WooCommerce', 'stock-sync-pro' ); ?></p>
        </div>
    </div>

    <!-- Resultado -->
    <?php if ( $resultado ) : ?>
        <?php if ( isset( $resultado['error'] ) ) : ?>
            <div class="wv-notice wv-notice-error wv-fade-in" style="max-width:685px;">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.4１４L１０ ８．５８６ ８．７０７ ７．２９３z" clip-rule="evenodd"/></svg>
                <div><strong><?php esc_html_e( 'Error al importar', 'stock-sync-pro' ); ?></strong> <?php echo esc_html( $resultado['error'] ); ?></div>
            </div>
        <?php else : ?>
            <div style="max-width:720px;">
            <div class="wv-notice wv-notice-success wv-fade-in">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                <div style="display:flex;flex-direction:column;gap:4px;">
                    <strong style="display:block;"><?php esc_html_e( 'Importación completada', 'stock-sync-pro' ); ?></strong>
                    <span style="font-size:13px;"><?php
                        echo '<b style="display:inline;">' . esc_html( $resultado['actualizados'] ) . '</b> ' . esc_html__( 'productos actualizados de', 'stock-sync-pro' ) . ' <b style="display:inline;">' . esc_html( $resultado['total'] ) . '</b> ' . esc_html__( 'procesados', 'stock-sync-pro' ) . '.';
                        if ( $resultado['sin_sku'] > 0 )  echo ' · ' . esc_html__( 'Sin SKU:', 'stock-sync-pro' ) . ' <b style="display:inline;">' . esc_html( $resultado['sin_sku'] ) . '</b>';
                        if ( $resultado['errores']  > 0 ) echo ' · ' . esc_html__( 'Errores:', 'stock-sync-pro' ) . ' <b style="display:inline;">' . esc_html( $resultado['errores'] ) . '</b>';
                    ?></span>
                    <?php if ( ! empty( $resultado['dry_run'] ) ) : ?>
                    <span style="font-size:12px;opacity:.8;">⚠ <?php esc_html_e( 'Modo preview activo — no se han aplicado cambios reales.', 'stock-sync-pro' ); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" style="max-width:720px;">
        <?php wp_nonce_field( 'wevica_import_csv', 'wevica_import_nonce' ); ?>

        <!-- Fuente -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3z"/></svg>
                    <?php esc_html_e( 'Fuente', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <div class="wv-field" style="grid-template-columns:140px 1fr;">
                    <label class="wv-field-label" for="tienda"><?php esc_html_e( 'Nombre de fuente', 'stock-sync-pro' ); ?></label>
                    <div>
                        <input type="text" name="tienda" id="tienda" class="wv-input"
                               placeholder="<?php esc_attr_e( 'ej: mi-tienda', 'stock-sync-pro' ); ?>"
                               value="<?php echo esc_attr( get_option( 'wevica_last_import_tienda', '' ) ); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Archivo -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Archivo CSV', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <div class="wv-dropzone">
                    <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
                    <div class="wv-dropzone-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><polyline points="9 15 12 12 15 15"/></svg>
                    </div>
                    <div class="wv-dropzone-title"><?php esc_html_e( 'Arrastra tu CSV aquí o haz clic para seleccionar', 'stock-sync-pro' ); ?></div>
                    <div class="wv-dropzone-sub"><?php esc_html_e( 'Solo archivos .csv — encoding UTF-8 recomendado', 'stock-sync-pro' ); ?></div>
                    <span class="wv-dropzone-filename"></span>
                </div>
            </div>
        </div>

        <!-- Columnas -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Mapeo de columnas', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <p style="font-size:12px;color:var(--wv-gray-500);margin:0 0 14px;">
                    <?php esc_html_e( 'Indica el nombre exacto de cada columna en la cabecera de tu CSV.', 'stock-sync-pro' ); ?>
                </p>
                <div class="wv-col-grid">
                    <div class="wv-col-field">
                        <label for="col_sku"><?php esc_html_e( 'SKU', 'stock-sync-pro' ); ?></label>
                        <input type="text" name="col_sku" id="col_sku" value="sku_ixia" class="wv-input">
                    </div>
                    <div class="wv-col-field">
                        <label for="col_stock"><?php esc_html_e( 'Stock', 'stock-sync-pro' ); ?></label>
                        <input type="text" name="col_stock" id="col_stock" value="stock" class="wv-input">
                    </div>
                    <div class="wv-col-field">
                        <label for="col_price"><?php esc_html_e( 'Precio', 'stock-sync-pro' ); ?></label>
                        <input type="text" name="col_price" id="col_price" value="precio" class="wv-input">
                    </div>
                    <div class="wv-col-field">
                        <label for="col_name"><?php esc_html_e( 'Nombre', 'stock-sync-pro' ); ?></label>
                        <input type="text" name="col_name" id="col_name" value="nombre" class="wv-input">
                    </div>
                </div>
            </div>
        </div>

        <!-- Dry run -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Modo preview', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <label class="wv-toggle-row">
                    <label class="wv-toggle">
                        <input type="checkbox" name="dry_run_import" value="1" <?php checked( ! empty( $_POST['dry_run_import'] ) ); ?>>
                        <span class="wv-toggle-slider"></span>
                    </label>
                    <div class="wv-toggle-text">
                        <strong><?php esc_html_e( 'Solo previsualizar — no se guardará ningún cambio', 'stock-sync-pro' ); ?></strong>
                        <span><?php esc_html_e( 'Simula la importación para ver qué cambiaría sin tocar WooCommerce.', 'stock-sync-pro' ); ?></span>
                    </div>
                </label>
            </div>
        </div>

        <div style="margin-top:4px;">
            <button type="submit" class="wv-btn wv-btn-primary wv-btn-lg">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
                <?php esc_html_e( 'Importar y sincronizar stock', 'stock-sync-pro' ); ?>
            </button>
        </div>
    </form>

</div>
