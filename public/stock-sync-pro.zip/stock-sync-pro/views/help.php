<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title"><?php esc_html_e( 'Ayuda & Documentación', 'stock-sync-pro' ); ?></h1>
            <p class="wv-page-subtitle"><?php esc_html_e( 'Todo lo que necesitas para integrar Stock Sync Pro', 'stock-sync-pro' ); ?></p>
        </div>
    </div>

    <!-- Tab nav -->
    <div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:1px solid var(--wv-gray-200);padding-bottom:0;">
        <?php
        $tabs = [
            'start'    => __( 'Inicio rápido', 'stock-sync-pro' ),
            'api'      => __( 'API REST', 'stock-sync-pro' ),
            'csv'      => __( 'Importar CSV', 'stock-sync-pro' ),
            'cron'     => __( 'Auto-sync', 'stock-sync-pro' ),
            'webhooks' => __( 'Webhooks', 'stock-sync-pro' ),
            'faq'      => __( 'FAQ', 'stock-sync-pro' ),
        ];
        $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'start';
        foreach ( $tabs as $slug => $label ) :
            $is_active = ( $active_tab === $slug );
        ?>
            <a href="<?php echo esc_url( add_query_arg( 'tab', $slug ) ); ?>"
               style="padding:8px 16px;font-size:13px;font-weight:<?php echo $is_active ? '600' : '400'; ?>;color:<?php echo $is_active ? 'var(--wv-primary)' : 'var(--wv-gray-500)'; ?>;border-bottom:2px solid <?php echo $is_active ? 'var(--wv-primary)' : 'transparent'; ?>;text-decoration:none;transition:var(--wv-transition);">
                <?php echo esc_html( $label ); ?>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- ═══ INICIO RÁPIDO ═══ -->
    <?php if ( $active_tab === 'start' ) : ?>
    <div style="max-width:760px;" class="wv-fade-in">

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( '1. Obtén tu clave API', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'Ve a', 'stock-sync-pro' ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-apikeys' ) ); ?>"><?php esc_html_e( 'Stock Sync Pro → Claves API', 'stock-sync-pro' ); ?></a> <?php esc_html_e( 'y crea una nueva clave con un nombre descriptivo (ej: "Mi Scraper").', 'stock-sync-pro' ); ?></p>
                <p><?php esc_html_e( 'La clave se muestra una sola vez. Cópiala y guárdala en el', 'stock-sync-pro' ); ?> <code>.env</code> <?php esc_html_e( 'de tu integración.', 'stock-sync-pro' ); ?></p>
            </div>
        </div>

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( '2. Asegúrate de que tus productos tienen SKU', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'El plugin actualiza productos por SKU. En WooCommerce ve a cada producto y asegúrate de que el campo "SKU" (en la pestaña "Inventario") está relleno con un código único.', 'stock-sync-pro' ); ?></p>
                <p><?php esc_html_e( 'Los SKUs de las variaciones también funcionan — el plugin busca en productos simples y variaciones.', 'stock-sync-pro' ); ?></p>
            </div>
        </div>

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( '3. Envía tu primer sync', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'Haz una petición POST al endpoint de tu WordPress:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:16px;border-radius:var(--wv-radius);font-size:12px;overflow:auto;line-height:1.6;">curl -X POST \
  <?php echo esc_html( rest_url( 'stocksync/v1/sync' ) ); ?> \
  -H "Content-Type: application/json" \
  -H "X-StockSync-Key: TU_CLAVE_API" \
  -d '{
    "tienda": "mi-tienda",
    "productos": [
      {"sku": "ABC123", "stock": "SI"},
      {"sku": "DEF456", "stock": "NO"},
      {"sku": "GHI789", "stock": 5}
    ]
  }'</pre>
                <p><?php esc_html_e( 'Si todo va bien recibirás:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#86efac;padding:16px;border-radius:var(--wv-radius);font-size:12px;overflow:auto;">{"success":true,"total":3,"actualizados":3,"sin_sku":0,"errores":0,"dry_run":false}</pre>
            </div>
        </div>

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( '4. Sync Engine (opcional)', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php printf(
                    wp_kses(
                        __( 'El plugin es <strong>completamente gratuito</strong>. Si quieres que la sincronización ocurra de forma automática (sin intervención manual), contrata el %s.', 'stock-sync-pro' ),
                        [ 'strong' => [] ]
                    ),
                    '<a href="' . esc_url( admin_url( 'admin.php?page=ssp-license' ) ) . '">' . esc_html__( 'Sync Engine', 'stock-sync-pro' ) . '</a>'
                ); ?></p>
            </div>
        </div>

    </div>

    <!-- ═══ API REST ═══ -->
    <?php elseif ( $active_tab === 'api' ) : ?>
    <div style="max-width:800px;" class="wv-fade-in">

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Endpoints disponibles', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <table style="width:100%;border-collapse:collapse;font-size:13px;">
                    <tr style="border-bottom:1px solid var(--wv-gray-200);">
                        <td style="padding:10px 0;font-weight:600;"><code>POST /stocksync/v1/sync</code></td>
                        <td style="padding:10px 0;color:var(--wv-gray-500);"><?php esc_html_e( 'Actualiza stock (y precio opcional) por JSON', 'stock-sync-pro' ); ?></td>
                    </tr>
                    <tr style="border-bottom:1px solid var(--wv-gray-200);">
                        <td style="padding:10px 0;font-weight:600;"><code>POST /stocksync/v1/sync-csv</code></td>
                        <td style="padding:10px 0;color:var(--wv-gray-500);"><?php esc_html_e( 'Actualiza stock enviando el contenido CSV en el body', 'stock-sync-pro' ); ?></td>
                    </tr>
                    <tr>
                        <td style="padding:10px 0;font-weight:600;"><code>GET /stocksync/v1/status</code></td>
                        <td style="padding:10px 0;color:var(--wv-gray-500);"><?php esc_html_e( 'Devuelve versión, estado y lista de SKUs del catálogo', 'stock-sync-pro' ); ?></td>
                    </tr>
                </table>
                <p style="font-size:12px;color:var(--wv-gray-400);margin-top:12px;"><?php esc_html_e( 'También disponibles bajo /wevica/v1/ por compatibilidad con versiones anteriores (deprecado).', 'stock-sync-pro' ); ?></p>
            </div>
        </div>

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Autenticación', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'Todas las peticiones requieren el header:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:13px;">X-StockSync-Key: tu_clave_api</pre>
                <p><?php esc_html_e( 'El header legacy X-Wevica-Key también es aceptado (deprecado).', 'stock-sync-pro' ); ?></p>
            </div>
        </div>

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Valores de stock aceptados', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <table style="width:100%;border-collapse:collapse;font-size:13px;">
                    <thead><tr style="background:var(--wv-gray-50);"><th style="padding:8px 12px;text-align:left;"><?php esc_html_e( 'Valor', 'stock-sync-pro' ); ?></th><th style="padding:8px 12px;text-align:left;"><?php esc_html_e( 'Resultado', 'stock-sync-pro' ); ?></th></tr></thead>
                    <tbody>
                        <tr style="border-bottom:1px solid var(--wv-gray-100);"><td style="padding:8px 12px;"><code>SI</code>, <code>1</code>, <code>INSTOCK</code>, <code>IN_STOCK</code>, <code>PROBABLE_SI</code></td><td style="padding:8px 12px;color:var(--wv-success);"><?php esc_html_e( 'En stock', 'stock-sync-pro' ); ?></td></tr>
                        <tr style="border-bottom:1px solid var(--wv-gray-100);"><td style="padding:8px 12px;"><code>NO</code>, <code>0</code>, <code>OUTOFSTOCK</code>, <code>OUT_OF_STOCK</code></td><td style="padding:8px 12px;color:var(--wv-error);"><?php esc_html_e( 'Sin stock', 'stock-sync-pro' ); ?></td></tr>
                        <tr style="border-bottom:1px solid var(--wv-gray-100);"><td style="padding:8px 12px;"><code>5</code>, <code>100</code>, cualquier entero</td><td style="padding:8px 12px;color:var(--wv-primary);"><?php esc_html_e( 'Cantidad exacta', 'stock-sync-pro' ); ?></td></tr>
                        <tr><td style="padding:8px 12px;"><code>UNKNOWN</code>, <code>DESCONOCIDO</code>, <code>ERROR_HTTP</code>...</td><td style="padding:8px 12px;color:var(--wv-gray-500);"><?php esc_html_e( 'Según configuración (skip / en stock / sin stock)', 'stock-sync-pro' ); ?></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Batches / Lotes grandes', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'Para catálogos grandes divide la petición en lotes usando los campos:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:12px;overflow:auto;">{
  "tienda": "mi-tienda",
  "sync_id": "sync_20240101_143000",   // mismo ID en todos los lotes
  "is_last_batch": false,              // true solo en el último
  "productos": [...]
}</pre>
                <p><?php esc_html_e( 'El historial mostrará una sola entrada con los totales acumulados de todos los lotes.', 'stock-sync-pro' ); ?></p>
            </div>
        </div>
    </div>

    <!-- ═══ CSV ═══ -->
    <?php elseif ( $active_tab === 'csv' ) : ?>
    <div style="max-width:700px;" class="wv-fade-in">
        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Formato del CSV', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'El archivo debe tener encabezados en la primera fila. Las columnas mínimas son SKU y stock:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:12px;">sku,stock,precio,nombre
ABC123,SI,29.99,Producto A
DEF456,NO,,Producto B
GHI789,5,15.50,Producto C</pre>
                <ul style="font-size:13px;color:var(--wv-gray-600);line-height:2;">
                    <li><?php esc_html_e( 'Separador: coma (,) o punto y coma (;) — autodetectado', 'stock-sync-pro' ); ?></li>
                    <li><?php esc_html_e( 'Encoding: UTF-8 (con o sin BOM)', 'stock-sync-pro' ); ?></li>
                    <li><?php esc_html_e( 'Precios: formatos europeo (1.234,56) y americano (1,234.56) soportados', 'stock-sync-pro' ); ?></li>
                    <li><?php esc_html_e( 'Los nombres de columna son configurables en la pantalla de importación', 'stock-sync-pro' ); ?></li>
                </ul>
            </div>
        </div>
        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Vía API (CSV en el body)', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:12px;overflow:auto;">curl -X POST \
  <?php echo esc_html( rest_url( 'stocksync/v1/sync-csv' ) ); ?> \
  -H "X-StockSync-Key: TU_CLAVE_API" \
  -H "X-StockSync-Tienda: mi-tienda" \
  -H "X-StockSync-Col-Sku: sku_codigo" \
  -H "X-StockSync-Col-Stock: disponible" \
  --data-binary @catalogo.csv</pre>
            </div>
        </div>
    </div>

    <!-- ═══ CRON ═══ -->
    <?php elseif ( $active_tab === 'cron' ) : ?>
    <div style="max-width:700px;" class="wv-fade-in">
        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Cómo funciona el Auto-sync', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <ol style="font-size:13px;color:var(--wv-gray-600);line-height:2.2;padding-left:18px;">
                    <li><?php esc_html_e( 'El plugin hace un GET a la URL que configures en Ajustes → Auto-sync.', 'stock-sync-pro' ); ?></li>
                    <li><?php esc_html_e( 'Detecta automáticamente si la respuesta es JSON o CSV.', 'stock-sync-pro' ); ?></li>
                    <li><?php esc_html_e( 'Procesa los productos y actualiza WooCommerce.', 'stock-sync-pro' ); ?></li>
                    <li><?php esc_html_e( 'Registra el resultado en el historial.', 'stock-sync-pro' ); ?></li>
                    <li><?php esc_html_e( 'Si tienes webhook configurado, envía notificación de éxito o error.', 'stock-sync-pro' ); ?></li>
                </ol>
                <p style="font-size:13px;color:var(--wv-gray-500);"><?php esc_html_e( 'Usa el botón "Ejecutar ahora" en Ajustes para probar la configuración antes de activar el cron.', 'stock-sync-pro' ); ?></p>
            </div>
        </div>
        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Formato JSON esperado en la URL', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:12px;overflow:auto;">[
  {"sku": "ABC123", "stock": "SI", "precio": "29.99"},
  {"sku": "DEF456", "stock": "NO"}
]
// o con wrapper:
{
  "productos": [...]
}</pre>
            </div>
        </div>
    </div>

    <!-- ═══ WEBHOOKS ═══ -->
    <?php elseif ( $active_tab === 'webhooks' ) : ?>
    <div style="max-width:700px;" class="wv-fade-in">
        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Payload del webhook', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'El plugin envía un POST con Content-Type: application/json. Ejemplo para sync_complete:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:12px;overflow:auto;">{
  "event": "sync_complete",
  "site_url": "https://tu-tienda.com",
  "timestamp": "2024-01-15T14:30:00+00:00",
  "tienda": "mi-tienda",
  "tipo": "cron",
  "total": 250,
  "actualizados": 48,
  "sin_sku": 12,
  "errores": 0
}</pre>
            </div>
        </div>
        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Verificar firma HMAC (opcional)', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <p><?php esc_html_e( 'Si configuras un secreto en Ajustes, cada petición incluirá el header:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:12px;">X-StockSync-Signature: sha256=<hash></pre>
                <p><?php esc_html_e( 'Para verificarlo en tu receptor:', 'stock-sync-pro' ); ?></p>
                <pre style="background:var(--wv-gray-900);color:#e5e7eb;padding:12px 16px;border-radius:var(--wv-radius);font-size:12px;overflow:auto;">$body      = file_get_contents('php://input');
$signature = 'sha256=' . hash_hmac('sha256', $body, $secret);
$received  = $_SERVER['HTTP_X_STOCKSYNC_SIGNATURE'] ?? '';
if (!hash_equals($signature, $received)) {
    http_response_code(401);
    exit;
}</pre>
            </div>
        </div>
        <div class="wv-section">
            <div class="wv-section-header"><h2 class="wv-section-title"><?php esc_html_e( 'Eventos', 'stock-sync-pro' ); ?></h2></div>
            <div class="wv-section-body">
                <table style="width:100%;border-collapse:collapse;font-size:13px;">
                    <tr style="border-bottom:1px solid var(--wv-gray-100);"><td style="padding:8px 0;"><code>sync_complete</code></td><td style="padding:8px 0;color:var(--wv-gray-500);"><?php esc_html_e( 'Sync completada (API, cron o CSV)', 'stock-sync-pro' ); ?></td></tr>
                    <tr style="border-bottom:1px solid var(--wv-gray-100);"><td style="padding:8px 0;"><code>sync_error</code></td><td style="padding:8px 0;color:var(--wv-gray-500);"><?php esc_html_e( 'Error durante la sync (cron)', 'stock-sync-pro' ); ?></td></tr>
                    <tr><td style="padding:8px 0;"><code>ping</code></td><td style="padding:8px 0;color:var(--wv-gray-500);"><?php esc_html_e( 'Prueba manual desde Ajustes', 'stock-sync-pro' ); ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <!-- ═══ FAQ ═══ -->
    <?php elseif ( $active_tab === 'faq' ) : ?>
    <div style="max-width:700px;" class="wv-fade-in">
        <?php
        $faqs = [
            [ __( '¿El plugin necesita WooCommerce?', 'stock-sync-pro' ), __( 'Sí. WooCommerce debe estar instalado y activo. El plugin mostrará un aviso si no lo detecta.', 'stock-sync-pro' ) ],
            [ __( '¿Cómo se emparejan los productos?', 'stock-sync-pro' ), __( 'Por SKU. El plugin busca el SKU en productos simples y variaciones. Los productos sin SKU o con SKU que no existe en WooCommerce se cuentan como "sin_sku" en el log.', 'stock-sync-pro' ) ],
            [ __( '¿Puedo tener múltiples scrapers o fuentes?', 'stock-sync-pro' ), __( 'Sí. Crea una clave API por cada fuente de datos. Puedes revocar una clave individualmente sin afectar al resto. Usa el campo "tienda" en cada petición para diferenciarlas en el historial.', 'stock-sync-pro' ) ],
            [ __( '¿Qué pasa si el trial expira?', 'stock-sync-pro' ), __( 'Las sincronizaciones se bloquean y se muestra un aviso en el admin. El historial y la configuración se conservan. Suscribirte restaura inmediatamente todo el funcionamiento.', 'stock-sync-pro' ) ],
            [ __( '¿Funciona con productos variables?', 'stock-sync-pro' ), __( 'Sí. Tanto productos simples como variaciones se actualizan por SKU.', 'stock-sync-pro' ) ],
            [ __( '¿El WP-Cron es fiable?', 'stock-sync-pro' ), __( 'WP-Cron se dispara cuando hay visitas al sitio. En tiendas con tráfico bajo puede retrasarse. Para máxima fiabilidad, configura un cron real del servidor que haga un GET a la URL de WordPress.', 'stock-sync-pro' ) ],
        ];
        foreach ( $faqs as $i => [$q, $a] ) :
        ?>
        <div class="wv-section" style="margin-bottom:12px;">
            <div class="wv-section-header" style="cursor:default;">
                <h2 class="wv-section-title" style="font-size:14px;"><?php echo esc_html( $q ); ?></h2>
            </div>
            <div class="wv-section-body">
                <p style="margin:0;font-size:13px;color:var(--wv-gray-600);"><?php echo esc_html( $a ); ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</div>
