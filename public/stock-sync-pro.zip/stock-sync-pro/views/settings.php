<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <!-- Header -->
    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title">Ajustes</h1>
            <p class="wv-page-subtitle">Configuración de Stock Sync Pro</p>
        </div>
    </div>

    <?php
    $settings_error = get_transient( 'ssp_settings_error' );
    if ( $settings_error ) {
        delete_transient( 'ssp_settings_error' );
    }
    ?>
    <?php if ( $settings_error ) : ?>
        <div class="wv-notice wv-notice-error wv-fade-in">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
            <div><strong><?php esc_html_e( 'Error', 'stock-sync-pro' ); ?></strong> — <?php echo esc_html( $settings_error ); ?></div>
        </div>
    <?php elseif ( $saved && ! empty( $_POST['ssp_send_onboarding'] ) ) : ?>
        <div class="wv-notice wv-notice-success wv-fade-in">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
            <div><strong><?php esc_html_e( 'Solicitud enviada', 'stock-sync-pro' ); ?></strong> — <?php esc_html_e( 'Hemos recibido tu información. Configuraremos tu scraper personalizado en menos de 24 horas.', 'stock-sync-pro' ); ?></div>
        </div>
    <?php elseif ( $saved ) : ?>
        <div class="wv-notice wv-notice-success wv-fade-in">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
            <div><strong><?php esc_html_e( 'Guardado', 'stock-sync-pro' ); ?></strong> <?php esc_html_e( 'Los ajustes se han actualizado correctamente.', 'stock-sync-pro' ); ?></div>
        </div>
    <?php endif; ?>

    <form method="post" style="max-width:760px;">
        <?php wp_nonce_field( 'wevica_save_settings', 'wevica_settings_nonce' ); ?>

        <!-- Proveedor -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M8 9a3 3 0 100-6 3 3 0 000 6zM8 11a6 6 0 016 6H2a6 6 0 016-6zM16 7a1 1 0 10-2 0v1h-1a1 1 0 100 2h1v1a1 1 0 102 0v-1h1a1 1 0 100-2h-1V7z"/></svg>
                    <?php esc_html_e( 'Proveedor', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <div class="wv-field">
                    <div class="wv-field-label">
                        <?php esc_html_e( 'URL del proveedor', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Sitio web de tu proveedor desde donde el Sync Engine obtiene el stock. Indícalo para que podamos configurar tu scraper personalizado.', 'stock-sync-pro' ); ?></div>
                    </div>
                    <input type="url" name="ssp_supplier_url" id="ssp_supplier_url"
                           value="<?php echo esc_attr( $supplier_url ?? '' ); ?>"
                           placeholder="https://www.miproveedor.com"
                           class="wv-input"
                           style="width:100%;max-width:480px;">
                </div>

                <!-- Tipo de fuente -->
                <div class="wv-field" style="margin-top:12px;">
                    <label class="wv-field-label" for="ssp_supplier_type">
                        <?php esc_html_e( 'Tipo de fuente', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Cómo obtenemos el stock de tu proveedor.', 'stock-sync-pro' ); ?></div>
                    </label>
                    <select name="ssp_supplier_type" id="ssp_supplier_type" class="wv-select" style="max-width:320px;">
                        <option value=""             <?php selected( $supplier_type, '' ); ?>><?php esc_html_e( '— Selecciona —', 'stock-sync-pro' ); ?></option>
                        <option value="web_scraper"  <?php selected( $supplier_type, 'web_scraper' ); ?>><?php esc_html_e( 'Página web del proveedor (requiere login)', 'stock-sync-pro' ); ?></option>
                        <option value="csv_url"      <?php selected( $supplier_type, 'csv_url' ); ?>><?php esc_html_e( 'CSV / Excel accesible por URL', 'stock-sync-pro' ); ?></option>
                        <option value="google_sheets" <?php selected( $supplier_type, 'google_sheets' ); ?>><?php esc_html_e( 'Google Sheets', 'stock-sync-pro' ); ?></option>
                        <option value="ftp"          <?php selected( $supplier_type, 'ftp' ); ?>><?php esc_html_e( 'FTP del proveedor', 'stock-sync-pro' ); ?></option>
                        <option value="api_rest"     <?php selected( $supplier_type, 'api_rest' ); ?>><?php esc_html_e( 'API REST del proveedor', 'stock-sync-pro' ); ?></option>
                        <option value="otro"         <?php selected( $supplier_type, 'otro' ); ?>><?php esc_html_e( 'Otro (explicar en notas)', 'stock-sync-pro' ); ?></option>
                    </select>
                </div>

                <!-- Notas -->
                <div class="wv-field">
                    <label class="wv-field-label" for="ssp_supplier_notes">
                        <?php esc_html_e( 'Notas para la configuración', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Cualquier detalle que nos ayude: columnas del CSV, formato del SKU, URL exacta del catálogo, frecuencia deseada, etc.', 'stock-sync-pro' ); ?></div>
                    </label>
                    <textarea name="ssp_supplier_notes" id="ssp_supplier_notes"
                              class="wv-input" rows="4"
                              style="width:100%;"
                              placeholder="<?php esc_attr_e( 'Ej: Los SKUs en el CSV están en la columna "codigo". El stock está en "disponible". Quiero sync cada 48h.', 'stock-sync-pro' ); ?>"><?php echo esc_textarea( $supplier_notes ?? '' ); ?></textarea>
                </div>

                <!-- Google Sheets (si el tipo de fuente es Google Sheets) -->
                <div class="wv-field">
                    <div class="wv-field-label">
                        <?php esc_html_e( 'URL de Google Sheets', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Si tu proveedor usa Google Sheets, pega aquí la URL del sheet (debe estar compartido como "Cualquiera con el enlace puede ver").', 'stock-sync-pro' ); ?></div>
                    </div>
                    <div style="display:flex;flex-direction:column;gap:6px;flex:1;">
                        <input type="url" name="ssp_catalog_sheets_url" id="ssp_catalog_sheets_url"
                               value="<?php echo esc_attr( $catalog_sheets_url ?? '' ); ?>"
                               placeholder="https://docs.google.com/spreadsheets/d/..."
                               class="wv-input"
                               style="width:100%;">
                        <?php if ( ! empty( $catalog_sheets_id ) ) : ?>
                            <span style="font-size:11px;color:var(--wv-gray-500);">
                                <?php esc_html_e( 'ID extraído:', 'stock-sync-pro' ); ?>
                                <code style="background:#f1f5f9;padding:1px 6px;border-radius:4px;"><?php echo esc_html( $catalog_sheets_id ); ?></code>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="wv-field">
                    <div class="wv-field-label">
                        <?php esc_html_e( 'Nombre de hoja (opcional)', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Si el Sheet tiene varias pestañas y solo quieres usar una, escribe su nombre exacto. Vacío = leer todas.', 'stock-sync-pro' ); ?></div>
                    </div>
                    <input type="text" name="ssp_catalog_excel_hoja" id="ssp_catalog_excel_hoja"
                           value="<?php echo esc_attr( $catalog_excel_hoja ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Ej: Catálogo 2025  (vacío = todas)', 'stock-sync-pro' ); ?>"
                           class="wv-input"
                           style="max-width:320px;">
                </div>

                <!-- Botón enviar solicitud -->
                <div style="margin-top:6px;padding:16px 20px;background:linear-gradient(135deg,#f5f3ff,#eef2ff);border:1px solid #c7d2fe;border-radius:var(--wv-radius,8px);">
                    <?php if ( ! empty( $onboarding_sent ) ) : ?>
                        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:14px;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:18px;height:18px;color:#16a34a;flex-shrink:0;margin-top:1px;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                            <div>
                                <strong style="font-size:13px;color:#15803d;display:block;margin-bottom:2px;"><?php esc_html_e( 'Solicitud enviada', 'stock-sync-pro' ); ?></strong>
                                <span style="font-size:12px;color:#16a34a;">
                                    <?php printf(
                                        /* translators: %s: date */
                                        esc_html__( 'Recibimos tu solicitud el %s. Te contactaremos en menos de 24h.', 'stock-sync-pro' ),
                                        esc_html( wp_date( get_option( 'date_format' ), strtotime( $onboarding_sent ) ) )
                                    ); ?>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                    <p style="margin:0 0 12px;font-size:13px;color:#4338ca;line-height:1.5;">
                        <strong><?php esc_html_e( 'Configuración del scraper personalizado', 'stock-sync-pro' ); ?></strong><br>
                        <span style="font-weight:400;"><?php esc_html_e( 'Rellena los campos de arriba y haz clic en el botón. Recibiremos tu información y configuraremos la sincronización automática en menos de 24 horas.', 'stock-sync-pro' ); ?></span>
                    </p>
                    <button type="submit" name="ssp_send_onboarding" value="1"
                            class="wv-btn wv-btn-primary"
                            style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:16px;height:16px;"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
                        <?php empty( $onboarding_sent ) ? esc_html_e( 'Solicitar configuración de scraper', 'stock-sync-pro' ) : esc_html_e( 'Reenviar solicitud', 'stock-sync-pro' ); ?>
                    </button>
                </div>
            </div>
        </div>

        <!-- Stock -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3z"/></svg>
                    Comportamiento del stock
                </h2>
            </div>
            <div class="wv-section-body">

                <div class="wv-field">
                    <div class="wv-field-label">
                        Stock desconocido
                        <div class="wv-field-desc">Qué hacer con valores DESCONOCIDO, NO_AUTENTICADO, etc.</div>
                    </div>
                    <div>
                        <select name="stock_unknown" id="stock_unknown" class="wv-select">
                            <option value="skip"       <?php selected( $stock_unknown, 'skip' ); ?>>No modificar (recomendado)</option>
                            <option value="outofstock" <?php selected( $stock_unknown, 'outofstock' ); ?>>Marcar sin stock</option>
                            <option value="instock"    <?php selected( $stock_unknown, 'instock' ); ?>>Marcar con stock</option>
                        </select>
                    </div>
                </div>

                <div class="wv-field">
                    <div class="wv-field-label">
                        Actualizar precios
                        <div class="wv-field-desc">Aplica el precio del CSV/JSON al producto de WooCommerce.</div>
                    </div>
                    <div>
                        <label class="wv-toggle-row">
                            <label class="wv-toggle">
                                <input type="checkbox" name="update_price" id="update_price" value="1" <?php checked( $update_price, '1' ); ?>>
                                <span class="wv-toggle-slider"></span>
                            </label>
                            <div class="wv-toggle-text">
                                <strong>Activar actualización de precios</strong>
                                <span>Si el CSV incluye columna de precio.</span>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="wv-field">
                    <div class="wv-field-label">
                        Modo prueba
                        <div class="wv-field-desc">Simula la sync sin aplicar cambios reales.</div>
                    </div>
                    <div>
                        <label class="wv-toggle-row">
                            <label class="wv-toggle">
                                <input type="checkbox" name="dry_run" id="dry_run" value="1" <?php checked( $dry_run, '1' ); ?>>
                                <span class="wv-toggle-slider"></span>
                            </label>
                            <div class="wv-toggle-text">
                                <strong>Dry run activo</strong>
                                <span>Solo registra qué se actualizaría, sin modificar nada.</span>
                            </div>
                        </label>
                    </div>
                </div>

            </div>
        </div>

        <!-- Mantenimiento -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    Mantenimiento de logs
                </h2>
            </div>
            <div class="wv-section-body">
                <div class="wv-field">
                    <div class="wv-field-label">
                        Retención de logs
                        <div class="wv-field-desc">Los registros más antiguos se eliminan automáticamente.</div>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <input type="number" name="log_retention" id="log_retention"
                               value="<?php echo esc_attr( $retention ); ?>"
                               min="7" max="365"
                               class="wv-input"
                               style="width:90px;">
                        <span style="font-size:13px;color:var(--wv-gray-500);">días</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Auto-sync Cron (solo visible cuando Sync Engine está activo) -->
        <?php
        $cron_locked = $cron_locked ?? ! ssp_autosync_is_active();
        $lock_attr   = '';
        $lock_style  = '';
        if ( ! $cron_locked ) :
        ?>
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header" style="gap:10px;">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Auto-sync (Cron)', 'stock-sync-pro' ); ?>
                </h2>
                <?php if ( $cron_locked ) : ?>
                    <span style="display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.04em;background:#fef2f2;color:#dc2626;flex-shrink:0;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:11px;height:11px;"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/></svg>
                        <?php esc_html_e( 'SYNC ENGINE', 'stock-sync-pro' ); ?>
                    </span>
                <?php else : ?>
                    <span style="display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;background:#f0fdf4;color:#16a34a;flex-shrink:0;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:11px;height:11px;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <?php esc_html_e( 'Sync Engine activo', 'stock-sync-pro' ); ?>
                    </span>
                <?php endif; ?>
            </div>

            <div style="position:relative;">

                <?php if ( $cron_locked ) : ?>
                <!-- Lock overlay -->
                <div style="position:absolute;inset:0;background:rgba(255,255,255,0.93);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);z-index:5;display:flex;align-items:center;justify-content:center;border-bottom-left-radius:var(--wv-radius,8px);border-bottom-right-radius:var(--wv-radius,8px);">
                    <div style="text-align:center;padding:32px 24px;max-width:320px;">
                        <div style="width:52px;height:52px;border-radius:50%;background:#fef2f2;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:26px;height:26px;color:#dc2626;"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/></svg>
                        </div>
                        <h3 style="margin:0 0 8px;font-size:16px;font-weight:700;color:var(--wv-gray-900);"><?php esc_html_e( 'Sync Engine', 'stock-sync-pro' ); ?></h3>
                        <p style="margin:0 0 20px;font-size:13px;color:var(--wv-gray-500);line-height:1.55;">
                            <?php esc_html_e( 'El auto-sync automático requiere el servicio Sync Engine. Es una suscripción independiente del plugin.', 'stock-sync-pro' ); ?>
                        </p>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-license' ) ); ?>"
                           class="wv-btn wv-btn-primary"
                           style="display:inline-flex;gap:6px;align-items:center;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:15px;height:15px;"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3z"/></svg>
                            <?php esc_html_e( 'Contratar Sync Engine →', 'stock-sync-pro' ); ?>
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <div class="wv-section-body" style="<?php echo esc_attr( $lock_style ); ?>">

                    <div class="wv-field">
                        <div class="wv-field-label">
                            <?php esc_html_e( 'Intervalo', 'stock-sync-pro' ); ?>
                            <div class="wv-field-desc"><?php esc_html_e( 'Con qué frecuencia obtener y procesar datos de la URL configurada.', 'stock-sync-pro' ); ?></div>
                        </div>
                        <select name="ssp_cron_interval" class="wv-select" <?php echo esc_attr( $lock_attr ); ?>>
                            <option value="off"        <?php selected( $cron_interval, 'off' ); ?>><?php esc_html_e( 'Desactivado', 'stock-sync-pro' ); ?></option>
                            <option value="ssp_30min"  <?php selected( $cron_interval, 'ssp_30min' ); ?>><?php esc_html_e( 'Cada 30 minutos', 'stock-sync-pro' ); ?></option>
                            <option value="hourly"     <?php selected( $cron_interval, 'hourly' ); ?>><?php esc_html_e( 'Cada hora', 'stock-sync-pro' ); ?></option>
                            <option value="ssp_2hours" <?php selected( $cron_interval, 'ssp_2hours' ); ?>><?php esc_html_e( 'Cada 2 horas', 'stock-sync-pro' ); ?></option>
                            <option value="twicedaily" <?php selected( $cron_interval, 'twicedaily' ); ?>><?php esc_html_e( '2 veces al día', 'stock-sync-pro' ); ?></option>
                            <option value="daily"      <?php selected( $cron_interval, 'daily' ); ?>><?php esc_html_e( 'Cada día', 'stock-sync-pro' ); ?></option>
                            <option value="weekly"     <?php selected( $cron_interval, 'weekly' ); ?>><?php esc_html_e( 'Cada semana', 'stock-sync-pro' ); ?></option>
                        </select>
                        <?php if ( $cron_next_run ) : ?>
                            <div style="font-size:11px;color:var(--wv-gray-400);margin-top:4px;">
                                <?php printf( esc_html__( 'Próxima ejecución: %s', 'stock-sync-pro' ), esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $cron_next_run ) ) ); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="wv-field">
                        <label class="wv-field-label" for="ssp_cron_source_url">
                            <?php esc_html_e( 'URL de datos', 'stock-sync-pro' ); ?>
                            <div class="wv-field-desc"><?php esc_html_e( 'El cron hará GET a esta URL. Debe devolver JSON o CSV con los datos de stock.', 'stock-sync-pro' ); ?></div>
                        </label>
                        <input type="url" name="ssp_cron_source_url" id="ssp_cron_source_url"
                               class="wv-input" style="width:100%;"
                               value="<?php echo esc_attr( $cron_source_url ); ?>"
                               placeholder="https://mi-scraper.com/api/stock.json"
                               <?php echo esc_attr( $lock_attr ); ?>>
                    </div>

                    <div class="wv-field" style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;">
                        <div>
                            <label class="wv-field-label" for="ssp_cron_source_type"><?php esc_html_e( 'Formato', 'stock-sync-pro' ); ?></label>
                            <select name="ssp_cron_source_type" id="ssp_cron_source_type" class="wv-select" style="width:100%;" <?php echo esc_attr( $lock_attr ); ?>>
                                <option value="auto" <?php selected( $cron_source_type, 'auto' ); ?>><?php esc_html_e( 'Auto', 'stock-sync-pro' ); ?></option>
                                <option value="json" <?php selected( $cron_source_type, 'json' ); ?>>JSON</option>
                                <option value="csv"  <?php selected( $cron_source_type, 'csv' ); ?>>CSV</option>
                            </select>
                        </div>
                        <div>
                            <label class="wv-field-label" for="ssp_cron_tienda"><?php esc_html_e( 'Tienda', 'stock-sync-pro' ); ?></label>
                            <input type="text" name="ssp_cron_tienda" id="ssp_cron_tienda" class="wv-input" style="width:100%;" value="<?php echo esc_attr( $cron_tienda ); ?>" placeholder="cron" <?php echo esc_attr( $lock_attr ); ?>>
                        </div>
                        <div>
                            <label class="wv-field-label" for="ssp_cron_col_sku"><?php esc_html_e( 'Col. SKU', 'stock-sync-pro' ); ?></label>
                            <input type="text" name="ssp_cron_col_sku" id="ssp_cron_col_sku" class="wv-input" style="width:100%;" value="<?php echo esc_attr( $cron_col_sku ); ?>" placeholder="sku" <?php echo esc_attr( $lock_attr ); ?>>
                        </div>
                        <div>
                            <label class="wv-field-label" for="ssp_cron_col_stock"><?php esc_html_e( 'Col. Stock', 'stock-sync-pro' ); ?></label>
                            <input type="text" name="ssp_cron_col_stock" id="ssp_cron_col_stock" class="wv-input" style="width:100%;" value="<?php echo esc_attr( $cron_col_stock ); ?>" placeholder="stock" <?php echo esc_attr( $lock_attr ); ?>>
                        </div>
                        <div>
                            <label class="wv-field-label" for="ssp_cron_col_price"><?php esc_html_e( 'Col. Precio', 'stock-sync-pro' ); ?></label>
                            <input type="text" name="ssp_cron_col_price" id="ssp_cron_col_price" class="wv-input" style="width:100%;" value="<?php echo esc_attr( $cron_col_price ); ?>" placeholder="precio" <?php echo esc_attr( $lock_attr ); ?>>
                        </div>
                    </div>

                    <div style="margin-top:8px;">
                        <button type="button" id="ssp-run-cron-btn" class="wv-btn wv-btn-ghost wv-btn-sm" <?php echo esc_attr( $lock_attr ); ?>>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
                            <?php esc_html_e( 'Ejecutar ahora', 'stock-sync-pro' ); ?>
                        </button>
                        <span id="ssp-run-cron-msg" style="font-size:12px;margin-left:8px;"></span>
                    </div>

                </div><!-- /.wv-section-body -->
            </div><!-- /position:relative wrapper -->
        </div>
        <?php endif; ?>

        <!-- Webhooks -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                <h2 class="wv-section-title" style="margin:0;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/></svg>
                    <?php esc_html_e( 'Notificaciones (Webhook)', 'stock-sync-pro' ); ?>
                </h2>
                <span style="display:inline-flex;align-items:center;gap:5px;padding:3px 10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:11px;font-weight:600;border-radius:20px;letter-spacing:.3px;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" style="width:11px;height:11px;"><path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/></svg>
                    <?php esc_html_e( 'Starter+', 'stock-sync-pro' ); ?>
                </span>
            </div>
            <div class="wv-section-body">

                <div class="wv-field">
                    <label class="wv-field-label" for="ssp_webhook_url">
                        <?php esc_html_e( 'URL del webhook', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Recibe notificaciones JSON en cada sync. Compatible con Slack, Make, Zapier, etc.', 'stock-sync-pro' ); ?></div>
                    </label>
                    <input type="url" name="ssp_webhook_url" id="ssp_webhook_url"
                           class="wv-input" style="width:100%;"
                           value="<?php echo esc_attr( $webhook_url ); ?>"
                           placeholder="https://hooks.slack.com/...">
                </div>

                <div class="wv-field">
                    <label class="wv-field-label" for="ssp_webhook_secret">
                        <?php esc_html_e( 'Secreto HMAC (opcional)', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Si se configura, cada petición incluirá el header X-StockSync-Signature para verificar autenticidad.', 'stock-sync-pro' ); ?></div>
                    </label>
                    <input type="text" name="ssp_webhook_secret" id="ssp_webhook_secret"
                           class="wv-input" style="width:100%;"
                           value="<?php echo esc_attr( $webhook_secret ); ?>"
                           placeholder="<?php esc_attr_e( 'Dejar vacío para no firmar', 'stock-sync-pro' ); ?>">
                </div>

                <div style="margin-top:8px;display:flex;gap:10px;align-items:center;">
                    <button type="button" id="ssp-test-webhook-btn" class="wv-btn wv-btn-ghost wv-btn-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/></svg>
                        <?php esc_html_e( 'Probar webhook', 'stock-sync-pro' ); ?>
                    </button>
                    <span id="ssp-webhook-test-msg" style="font-size:12px;"></span>
                </div>

                <?php if ( $webhook_queue_count > 0 ) : ?>
                <div style="margin-top:14px;padding:10px 14px;background:var(--wv-warning-light,#fffbeb);border:1px solid var(--wv-warning,#f59e0b);border-radius:var(--wv-radius);display:flex;align-items:center;gap:12px;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:16px;height:16px;color:var(--wv-warning,#f59e0b);flex-shrink:0;"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <div style="flex:1;font-size:12px;color:var(--wv-gray-700);">
                        <?php printf(
                            esc_html( _n( '%d webhook pendiente de reintento.', '%d webhooks pendientes de reintento.', $webhook_queue_count, 'stock-sync-pro' ) ),
                            $webhook_queue_count
                        ); ?>
                        <?php if ( $webhook_queue_next > 0 ) : ?>
                            <?php printf( esc_html__( ' Próximo intento: %s.', 'stock-sync-pro' ), esc_html( wp_date( get_option( 'time_format' ), $webhook_queue_next ) ) ); ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" id="ssp-clear-webhook-queue-btn" class="wv-btn wv-btn-ghost wv-btn-sm" style="flex-shrink:0;">
                        <?php esc_html_e( 'Vaciar cola', 'stock-sync-pro' ); ?>
                    </button>
                    <span id="ssp-clear-queue-msg" style="font-size:12px;"></span>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- Notificaciones por email -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/></svg>
                    <?php esc_html_e( 'Notificaciones por email', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">

                <div class="wv-field">
                    <label class="wv-field-label" for="ssp_notify_email">
                        <?php esc_html_e( 'Email de notificaciones', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Deja vacío para usar el email del administrador del sitio.', 'stock-sync-pro' ); ?></div>
                    </label>
                    <input type="email" name="ssp_notify_email" id="ssp_notify_email"
                           class="wv-input" style="width:100%;"
                           value="<?php echo esc_attr( $notify_email ); ?>"
                           placeholder="<?php echo esc_attr( get_option( 'admin_email', '' ) ); ?>">
                </div>

                <div class="wv-field">
                    <div class="wv-field-label"><?php esc_html_e( 'Alertas de error', 'stock-sync-pro' ); ?></div>
                    <div>
                        <label class="wv-toggle-row">
                            <label class="wv-toggle">
                                <input type="checkbox" name="ssp_notify_on_error" value="1" <?php checked( $notify_on_error, '1' ); ?>>
                                <span class="wv-toggle-slider"></span>
                            </label>
                            <div class="wv-toggle-text">
                                <strong><?php esc_html_e( 'Notificar errores del cron', 'stock-sync-pro' ); ?></strong>
                                <span><?php esc_html_e( 'Envía un email cuando el cron de sincronización falla.', 'stock-sync-pro' ); ?></span>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="wv-field">
                    <div class="wv-field-label"><?php esc_html_e( 'Alertas de webhook muerto', 'stock-sync-pro' ); ?></div>
                    <div>
                        <label class="wv-toggle-row">
                            <label class="wv-toggle">
                                <input type="checkbox" name="ssp_notify_on_webhook_dead" value="1" <?php checked( $notify_on_webhook_dead, '1' ); ?>>
                                <span class="wv-toggle-slider"></span>
                            </label>
                            <div class="wv-toggle-text">
                                <strong><?php esc_html_e( 'Notificar webhooks sin entregar', 'stock-sync-pro' ); ?></strong>
                                <span><?php esc_html_e( 'Envía un email cuando un webhook agota los 5 reintentos.', 'stock-sync-pro' ); ?></span>
                            </div>
                        </label>
                    </div>
                </div>

            </div>
        </div>

        <!-- Exclusión de SKUs -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524l8.367 8.368zm1.414-1.414L6.524 5.11a6 6 0 018.367 8.367zM18 10a8 8 0 11-16 0 8 8 0 0116 0z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'SKUs excluidos', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <div class="wv-field">
                    <label class="wv-field-label" for="ssp_exclude_skus">
                        <?php esc_html_e( 'Lista de SKUs a ignorar', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'Un SKU por línea (o separados por coma). Estos productos nunca serán modificados por la sincronización.', 'stock-sync-pro' ); ?></div>
                    </label>
                    <textarea name="ssp_exclude_skus" id="ssp_exclude_skus"
                              class="wv-input" rows="6"
                              style="width:100%;font-family:monospace;font-size:12px;"
                              placeholder="SKU-001&#10;SKU-002&#10;PROMO-ABC"><?php echo esc_textarea( $exclude_skus ); ?></textarea>
                </div>
            </div>
        </div>

        <!-- Exportar / Importar configuración -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Exportar / Importar configuración', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <p style="font-size:13px;color:var(--wv-gray-500);margin-bottom:16px;">
                    <?php esc_html_e( 'Guarda todos los ajustes en un archivo JSON para hacer copias de seguridad o migrar entre sitios. Las claves API no se exportan por seguridad.', 'stock-sync-pro' ); ?>
                </p>
                <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-start;">
                    <button type="button" id="ssp-export-settings-btn" class="wv-btn wv-btn-ghost wv-btn-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:14px;height:14px;"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                        <?php esc_html_e( 'Exportar ajustes', 'stock-sync-pro' ); ?>
                    </button>
                    <div>
                        <label class="wv-btn wv-btn-ghost wv-btn-sm" for="ssp-import-file" style="cursor:pointer;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:14px;height:14px;"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg>
                            <?php esc_html_e( 'Importar ajustes', 'stock-sync-pro' ); ?>
                        </label>
                        <input type="file" id="ssp-import-file" accept=".json" style="display:none;">
                    </div>
                    <span id="ssp-settings-io-msg" style="font-size:12px;align-self:center;"></span>
                </div>
            </div>
        </div>

        <div style="margin-top:4px;">
            <button type="submit" class="wv-btn wv-btn-primary wv-btn-lg">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M7.707 10.293a1 1 0 10-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 11.586V6h5a2 2 0 012 2v7a2 2 0 01-2 2H4a2 2 0 01-2-2V8a2 2 0 012-2h5v5.586l-1.293-1.293zM9 4a1 1 0 012 0v2H9V4z"/></svg>
                <?php esc_html_e( 'Guardar ajustes', 'stock-sync-pro' ); ?>
            </button>
        </div>
    </form>

</div>

<script>
(function(){
    // Run cron now
    var cronBtn = document.getElementById('ssp-run-cron-btn');
    if (cronBtn) {
        cronBtn.addEventListener('click', function(){
            var msg = document.getElementById('ssp-run-cron-msg');
            cronBtn.disabled = true;
            msg.textContent = '<?php echo esc_js( __( 'Ejecutando...', 'stock-sync-pro' ) ); ?>';
            msg.style.color = 'var(--wv-gray-500)';
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=ssp_run_cron_now&nonce=<?php echo esc_js( wp_create_nonce( 'ssp_cron_nonce' ) ); ?>'
            })
            .then(r => r.json())
            .then(function(res){
                msg.textContent = res.data.message;
                msg.style.color = res.success ? 'var(--wv-success)' : 'var(--wv-error)';
                cronBtn.disabled = false;
            });
        });
    }

    // Test webhook
    var webhookBtn = document.getElementById('ssp-test-webhook-btn');
    if (webhookBtn) {
        webhookBtn.addEventListener('click', function(){
            var url    = document.getElementById('ssp_webhook_url').value.trim();
            var secret = document.getElementById('ssp_webhook_secret').value.trim();
            var msg    = document.getElementById('ssp-webhook-test-msg');
            if (!url) {
                msg.textContent = '<?php echo esc_js( __( 'Introduce una URL primero.', 'stock-sync-pro' ) ); ?>';
                msg.style.color = 'var(--wv-error)';
                return;
            }
            webhookBtn.disabled = true;
            msg.textContent = '<?php echo esc_js( __( 'Enviando...', 'stock-sync-pro' ) ); ?>';
            msg.style.color = 'var(--wv-gray-500)';
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=ssp_test_webhook&nonce=<?php echo esc_js( wp_create_nonce( 'ssp_webhook_nonce' ) ); ?>&url=' + encodeURIComponent(url) + '&secret=' + encodeURIComponent(secret)
            })
            .then(r => r.json())
            .then(function(res){
                msg.textContent = res.data.message;
                msg.style.color = res.success ? 'var(--wv-success)' : 'var(--wv-error)';
                webhookBtn.disabled = false;
            });
        });
    }

    // Clear webhook retry queue
    var clearQueueBtn = document.getElementById('ssp-clear-webhook-queue-btn');
    if (clearQueueBtn) {
        clearQueueBtn.addEventListener('click', function(){
            var msg = document.getElementById('ssp-clear-queue-msg');
            clearQueueBtn.disabled = true;
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=ssp_clear_webhook_queue&nonce=<?php echo esc_js( wp_create_nonce( 'ssp_webhook_nonce' ) ); ?>'
            })
            .then(r => r.json())
            .then(function(res){
                msg.textContent = res.data.message;
                msg.style.color = res.success ? 'var(--wv-success)' : 'var(--wv-error)';
                if (res.success) {
                    clearQueueBtn.closest('div[style]').style.display = 'none';
                } else {
                    clearQueueBtn.disabled = false;
                }
            });
        });
    }
    // Export settings
    var exportBtn = document.getElementById('ssp-export-settings-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', function(){
            var msg = document.getElementById('ssp-settings-io-msg');
            exportBtn.disabled = true;
            msg.textContent = '<?php echo esc_js( __( 'Exportando...', 'stock-sync-pro' ) ); ?>';
            msg.style.color = 'var(--wv-gray-500)';
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=ssp_export_settings&nonce=<?php echo esc_js( wp_create_nonce( 'ssp_settings_io' ) ); ?>'
            })
            .then(r => r.json())
            .then(function(res){
                exportBtn.disabled = false;
                if (res.success) {
                    var blob = new Blob([res.data.json], {type:'application/json'});
                    var a    = document.createElement('a');
                    a.href   = URL.createObjectURL(blob);
                    a.download = 'ssp-settings-' + new Date().toISOString().slice(0,10) + '.json';
                    a.click();
                    msg.textContent = '<?php echo esc_js( __( 'Exportado correctamente.', 'stock-sync-pro' ) ); ?>';
                    msg.style.color = 'var(--wv-success)';
                } else {
                    msg.textContent = res.data.message;
                    msg.style.color = 'var(--wv-error)';
                }
            });
        });
    }

    // Import settings
    var importFile = document.getElementById('ssp-import-file');
    if (importFile) {
        importFile.addEventListener('change', function(){
            var msg = document.getElementById('ssp-settings-io-msg');
            var file = importFile.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function(e){
                msg.textContent = '<?php echo esc_js( __( 'Importando...', 'stock-sync-pro' ) ); ?>';
                msg.style.color = 'var(--wv-gray-500)';
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type':'application/x-www-form-urlencoded'},
                    body: 'action=ssp_import_settings&nonce=<?php echo esc_js( wp_create_nonce( 'ssp_settings_io' ) ); ?>&json=' + encodeURIComponent(e.target.result)
                })
                .then(r => r.json())
                .then(function(res){
                    msg.textContent = res.data.message;
                    msg.style.color = res.success ? 'var(--wv-success)' : 'var(--wv-error)';
                    if (res.success) { setTimeout(function(){ location.reload(); }, 1200); }
                    importFile.value = '';
                });
            };
            reader.readAsText(file);
        });
    }
})();
</script>
