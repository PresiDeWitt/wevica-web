<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title"><?php esc_html_e( 'Claves API', 'stock-sync-pro' ); ?></h1>
            <p class="wv-page-subtitle"><?php esc_html_e( 'Gestiona las claves de autenticación para tus integraciones', 'stock-sync-pro' ); ?></p>
        </div>
    </div>

    <!-- Setup key notice (shown once on first activation) -->
    <?php $setup_key = get_option( 'ssp_setup_key', '' ); ?>
    <?php if ( $setup_key ) : ?>
        <div class="wv-notice wv-notice-warning wv-fade-in" style="margin-bottom:20px;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
            <div>
                <strong><?php esc_html_e( '¡Clave API generada al activar el plugin! Cópiala ahora, no se volverá a mostrar.', 'stock-sync-pro' ); ?></strong>
                <div class="wv-apikey-wrap" style="margin-top:8px;">
                    <span class="wv-apikey-value" id="ssp-setup-key-value"><?php echo esc_html( $setup_key ); ?></span>
                    <button class="wv-apikey-copy" type="button" data-target="ssp-setup-key-value">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/></svg>
                        <?php esc_html_e( 'Copiar', 'stock-sync-pro' ); ?>
                    </button>
                </div>
                <p style="font-size:12px;margin:6px 0 0;opacity:.8;">
                    <?php esc_html_e( 'Úsala en el header:', 'stock-sync-pro' ); ?>
                    <code>X-StockSync-Key: <?php echo esc_html( $setup_key ); ?></code>
                </p>
            </div>
        </div>
        <?php delete_option( 'ssp_setup_key' ); ?>
    <?php endif; ?>

    <!-- New key notice -->
    <?php $new_key_data = get_transient( 'ssp_new_api_key' ); ?>
    <?php if ( $new_key_data ) : ?>
        <div class="wv-notice wv-notice-warning wv-fade-in" style="margin-bottom:20px;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
            <div>
                <strong><?php esc_html_e( '¡Copia esta clave ahora! No se volverá a mostrar.', 'stock-sync-pro' ); ?></strong>
                <div class="wv-apikey-wrap" style="margin-top:8px;">
                    <span class="wv-apikey-value" id="ssp-new-key-value"><?php echo esc_html( $new_key_data['plain'] ); ?></span>
                    <button class="wv-apikey-copy" type="button" data-target="ssp-new-key-value">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/></svg>
                        <?php esc_html_e( 'Copiar', 'stock-sync-pro' ); ?>
                    </button>
                </div>
                <p style="font-size:12px;margin:6px 0 0;opacity:.8;">
                    <?php esc_html_e( 'Úsala en el header:', 'stock-sync-pro' ); ?>
                    <code>X-StockSync-Key: <?php echo esc_html( $new_key_data['plain'] ); ?></code>
                </p>
            </div>
        </div>
        <?php delete_transient( 'ssp_new_api_key' ); ?>
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start;">

        <!-- Keys table -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 2 2 0 012 2 1 1 0 102 0 4 4 0 00-4-4z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Claves activas', 'stock-sync-pro' ); ?>
                </h2>
                <?php
                $plan_config = ssp_get_plan_config( ssp_get_current_plan() );
                $key_limit   = $plan_config['api_keys'] ?? 1;
                $key_count   = count( $keys );
                $plan_name   = $plan_config['name'] ?? 'Free';
                $at_limit    = $key_count >= $key_limit;
                $color       = $at_limit ? 'var(--wv-error)' : 'var(--wv-gray-400)';
                ?>
                <span style="font-size:11px;color:<?php echo esc_attr( $color ); ?>;font-weight:500;">
                    <?php
                    if ( $key_limit >= 999 ) {
                        echo esc_html( $key_count ) . ' ' . esc_html__( 'claves · Ilimitadas', 'stock-sync-pro' );
                    } else {
                        printf(
                            esc_html__( '%1$d de %2$d · Plan %3$s', 'stock-sync-pro' ),
                            esc_html( $key_count ),
                            esc_html( $key_limit ),
                            esc_html( $plan_name )
                        );
                    }
                    ?>
                </span>
            </div>

            <?php if ( empty( $keys ) ) : ?>
                <div class="wv-empty">
                    <div class="wv-empty-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 2 2 0 012 2 1 1 0 102 0 4 4 0 00-4-4z" clip-rule="evenodd"/></svg>
                    </div>
                    <p class="wv-empty-title"><?php esc_html_e( 'Sin claves todavía', 'stock-sync-pro' ); ?></p>
                    <p class="wv-empty-sub"><?php esc_html_e( 'Crea tu primera clave API para conectar tus integraciones.', 'stock-sync-pro' ); ?></p>
                </div>
            <?php else : ?>
                <div class="wv-section-body" style="padding:0;">
                    <table style="width:100%;border-collapse:collapse;font-size:13px;">
                        <thead>
                            <tr style="background:var(--wv-gray-50);border-bottom:1px solid var(--wv-gray-200);">
                                <th style="padding:10px 16px;text-align:left;font-weight:600;color:var(--wv-gray-600);"><?php esc_html_e( 'Nombre', 'stock-sync-pro' ); ?></th>
                                <th style="padding:10px 16px;text-align:left;font-weight:600;color:var(--wv-gray-600);"><?php esc_html_e( 'Creada', 'stock-sync-pro' ); ?></th>
                                <th style="padding:10px 16px;text-align:left;font-weight:600;color:var(--wv-gray-600);"><?php esc_html_e( 'Último uso', 'stock-sync-pro' ); ?></th>
                                <th style="padding:10px 16px;text-align:right;font-weight:600;color:var(--wv-gray-600);"><?php esc_html_e( 'Acciones', 'stock-sync-pro' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ( $keys as $key ) : ?>
                            <tr style="border-bottom:1px solid var(--wv-gray-100);">
                                <td style="padding:12px 16px;">
                                    <strong style="color:var(--wv-gray-800);"><?php echo esc_html( $key['name'] ); ?></strong>
                                    <div style="font-size:11px;color:var(--wv-gray-400);margin-top:2px;font-family:monospace;"><?php echo esc_html( substr( $key['id'], 0, 12 ) ); ?>…</div>
                                </td>
                                <td style="padding:12px 16px;color:var(--wv-gray-500);">
                                    <?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $key['created_at'] ) ) ); ?>
                                </td>
                                <td style="padding:12px 16px;color:var(--wv-gray-500);">
                                    <?php if ( $key['last_used'] ) : ?>
                                        <?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $key['last_used'] ) ) ); ?>
                                    <?php else : ?>
                                        <span style="color:var(--wv-gray-300);"><?php esc_html_e( 'Nunca', 'stock-sync-pro' ); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:12px 16px;text-align:right;">
                                    <form method="post" style="display:inline;" onsubmit="return confirm('<?php echo esc_js( __( '¿Revocar esta clave? Las integraciones que la usen dejarán de funcionar.', 'stock-sync-pro' ) ); ?>')">
                                        <?php wp_nonce_field( 'ssp_revoke_key_' . $key['id'], 'ssp_revoke_nonce' ); ?>
                                        <input type="hidden" name="ssp_revoke_key_id" value="<?php echo esc_attr( $key['id'] ); ?>">
                                        <button type="submit" class="wv-btn wv-btn-ghost wv-btn-sm" style="color:var(--wv-error);" name="ssp_action" value="revoke_key">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="12" height="12"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                                            <?php esc_html_e( 'Revocar', 'stock-sync-pro' ); ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Create new key form / upgrade CTA -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Nueva clave', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">

                <?php if ( $at_limit && $key_limit < 999 ) : ?>

                    <!-- At limit: show upgrade CTA -->
                    <div style="text-align:center;padding:8px 0 4px;">
                        <div style="width:48px;height:48px;background:linear-gradient(135deg,#fef3c7,#fde68a);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:24px;height:24px;color:#d97706;"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/></svg>
                        </div>
                        <p style="font-size:13px;font-weight:600;color:var(--wv-gray-700);margin:0 0 4px;">
                            <?php
                            printf(
                                esc_html__( 'Límite de %d clave(s) alcanzado', 'stock-sync-pro' ),
                                $key_limit
                            );
                            ?>
                        </p>
                        <p style="font-size:12px;color:var(--wv-gray-400);margin:0 0 16px;line-height:1.5;">
                            <?php esc_html_e( 'Tu plan actual no permite más claves. Actualiza para conectar más integraciones.', 'stock-sync-pro' ); ?>
                        </p>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-billing' ) ); ?>"
                           class="wv-btn wv-btn-primary" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width: 14px;height:14px;"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>
                            <?php esc_html_e( 'Ver planes →', 'stock-sync-pro' ); ?>
                        </a>
                        <ul style="list-style:none;margin:14px 0 0;padding:0;font-size:11px;color:var(--wv-gray-400);line-height:2;text-align:left;">
                            <li>✓ <?php esc_html_e( 'Business: hasta 10 claves API', 'stock-sync-pro' ); ?></li>
                            <li>✓ <?php esc_html_e( 'Agency: claves ilimitadas', 'stock-sync-pro' ); ?></li>
                            <li>✓ <?php esc_html_e( 'Webhooks y auto-sync incluidos', 'stock-sync-pro' ); ?></li>
                        </ul>
                    </div>

                <?php else : ?>

                    <form method="post">
                        <?php wp_nonce_field( 'ssp_create_key', 'ssp_create_nonce' ); ?>
                        <div class="wv-field">
                            <label class="wv-field-label" for="ssp_key_name">
                                <?php esc_html_e( 'Nombre de la clave', 'stock-sync-pro' ); ?>
                                <div class="wv-field-desc"><?php esc_html_e( 'Ej: Scraper Tienda 1, ERP, Zapier...', 'stock-sync-pro' ); ?></div>
                            </label>
                            <input type="text" name="ssp_key_name" id="ssp_key_name"
                                   class="wv-input" style="width:100%;"
                                   placeholder="<?php esc_attr_e( 'Mi integración', 'stock-sync-pro' ); ?>"
                                   maxlength="80" required>
                        </div>
                        <button type="submit" name="ssp_action" value="create_key" class="wv-btn wv-btn-primary" style="width:100%;margin-top:8px;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/></svg>
                            <?php esc_html_e( 'Generar clave', 'stock-sync-pro' ); ?>
                        </button>
                    </form>

                    <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--wv-gray-100);">
                        <p style="font-size:12px;color:var(--wv-gray-400);margin:0;">
                            <?php esc_html_e( 'Cada clave es independiente. Puedes revocar una sin afectar al resto.', 'stock-sync-pro' ); ?>
                        </p>
                        <div class="wv-endpoint-pill" style="margin-top:10px;font-size:11px;">
                            <?php esc_html_e( 'Endpoint:', 'stock-sync-pro' ); ?>
                            <?php echo esc_html( rest_url( 'stocksync/v1/sync' ) ); ?>
                        </div>
                    </div>

                <?php endif; ?>

            </div>
        </div>

    </div>
</div>
