<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title"><?php esc_html_e( 'Sync Engine', 'stock-sync-pro' ); ?></h1>
            <p class="wv-page-subtitle"><?php esc_html_e( 'Activa el servicio de sincronización automática para tu tienda', 'stock-sync-pro' ); ?></p>
        </div>
    </div>

    <?php
    $autosync_active = ssp_autosync_is_active();
    $current_plan    = function_exists( 'ssp_get_current_plan' ) ? ssp_get_current_plan() : 'free';
    $plan_config     = function_exists( 'ssp_get_plan_config' ) ? ssp_get_plan_config( $current_plan ) : null;
    $plan_name       = get_option( 'ssp_plan_name', $plan_config['name'] ?? ucfirst( $current_plan ) );
    ?>

    <?php if ( $autosync_active && $plan_config && $current_plan !== 'free' ) : ?>
    <!-- Plan activo: mostrar detalles del plan -->
    <div class="wv-section wv-fade-in" style="max-width:900px;margin-bottom:20px;background:linear-gradient(135deg,#eef2ff,#f5f3ff);border:1px solid #c7d2fe;">
        <div class="wv-section-body" style="padding:20px;">
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:16px;">
                <div>
                    <strong style="font-size:16px;color:#3730a3;"><?php echo esc_html( $plan_name ); ?></strong>
                    <span style="margin-left:8px;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700;background:#e0e7ff;color:#3730a3;"><?php esc_html_e( 'ACTIVO', 'stock-sync-pro' ); ?></span>
                </div>
                <a href="<?php echo esc_url( SSP_PURCHASE_URL ); ?>" target="_blank" rel="noopener"
                   style="font-size:12px;color:#6366f1;text-decoration:none;">
                    <?php esc_html_e( 'Gestionar suscripción →', 'stock-sync-pro' ); ?>
                </a>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;">
                <?php
                $features = [
                    'api_keys'          => [ 'label' => __( 'Claves API', 'stock-sync-pro' ),      'value' => $plan_config['api_keys'] === PHP_INT_MAX ? __( 'Ilimitadas', 'stock-sync-pro' ) : $plan_config['api_keys'] ],
                    'products_monthly'  => [ 'label' => __( 'Productos/mes', 'stock-sync-pro' ),   'value' => number_format( $plan_config['products_monthly'] ?? 0 ) ],
                    'api_calls_monthly' => [ 'label' => __( 'Llamadas API/mes', 'stock-sync-pro' ), 'value' => number_format( $plan_config['api_calls_monthly'] ?? 0 ) ],
                    'webhooks'          => [ 'label' => __( 'Webhooks', 'stock-sync-pro' ),        'value' => ! empty( $plan_config['webhooks'] ) ? __( 'Incluidos', 'stock-sync-pro' ) : __( 'No incluidos', 'stock-sync-pro' ) ],
                    'custom_scrapers'   => [ 'label' => __( 'Scrapers custom', 'stock-sync-pro' ), 'value' => ! empty( $plan_config['custom_scrapers'] ) ? __( 'Incluidos', 'stock-sync-pro' ) : __( 'No incluidos', 'stock-sync-pro' ) ],
                    'priority_support'  => [ 'label' => __( 'Soporte prioritario', 'stock-sync-pro' ), 'value' => ! empty( $plan_config['priority_support'] ) ? __( 'Sí', 'stock-sync-pro' ) : __( 'No', 'stock-sync-pro' ) ],
                ];
                foreach ( $features as $key => $feat ) :
                    $active = is_numeric( $feat['value'] ) ? ( (int) $feat['value'] > 0 ) : ! in_array( $feat['value'], [ __( 'No incluidos', 'stock-sync-pro' ), __( 'No', 'stock-sync-pro' ) ], true );
                ?>
                <div style="padding:12px;background:<?php echo $active ? '#fff' : '#f5f5f5'; ?>;border:1px solid <?php echo $active ? '#c7d2fe' : '#e5e7eb'; ?>;border-radius:8px;">
                    <div style="font-size:11px;color:#6b7280;margin-bottom:2px;"><?php echo esc_html( $feat['label'] ); ?></div>
                    <div style="font-size:14px;font-weight:700;color:<?php echo $active ? '#3730a3' : '#9ca3af'; ?>;">
                        <?php echo esc_html( $feat['value'] ); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php else : ?>
    <!-- Plugin libre: aviso informativo -->
    <div class="wv-section wv-fade-in" style="max-width:900px;margin-bottom:20px;background:linear-gradient(135deg,#f0fdf4,#ecfdf5);border:1px solid #bbf7d0;">
        <div class="wv-section-body" style="display:flex;align-items:center;gap:14px;padding:16px 20px;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="color:#16a34a;flex-shrink:0;width:24px;height:24px;">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <div>
                <strong style="color:#15803d;font-size:14px;"><?php esc_html_e( 'El plugin es completamente gratuito', 'stock-sync-pro' ); ?></strong>
                <p style="margin:2px 0 0;font-size:12px;color:#166534;">
                    <?php esc_html_e( 'No necesitas licencia para usar Stock Sync Pro. La suscripción es únicamente para el servicio Sync Engine (sincronización automática programada).', 'stock-sync-pro' ); ?>
                </p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Sync Engine service card -->
    <div class="wv-section wv-fade-in" style="max-width:900px;">
        <div class="wv-section-header">
            <h2 class="wv-section-title">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
                <?php esc_html_e( 'Sync Engine', 'stock-sync-pro' ); ?>
            </h2>
            <?php if ( $autosync_active ) : ?>
                <span style="display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:#f0fdf4;color:#16a34a;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:11px;height:11px;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'ACTIVO', 'stock-sync-pro' ); ?>
                </span>
            <?php else : ?>
                <span style="display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:#fef2f2;color:#dc2626;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:11px;height:11px;"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'NO ACTIVO', 'stock-sync-pro' ); ?>
                </span>
            <?php endif; ?>
        </div>
        <div class="wv-section-body">

            <p style="margin:0 0 20px;font-size:13px;color:var(--wv-gray-500);line-height:1.6;">
                <?php esc_html_e( 'El Sync Engine es el servicio que extrae el stock de tu proveedor automáticamente y lo envía a tu WooCommerce, aunque el proveedor no tenga API. Al contratar un plan recibirás tu clave de Sync Engine por email.', 'stock-sync-pro' ); ?>
            </p>

            <?php if ( $autosync_active ) : ?>

                <!-- Estado activo -->
                <div style="display:flex;align-items:center;gap:10px;padding:16px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:var(--wv-radius);margin-bottom:16px;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="color:#16a34a;flex-shrink:0;width:24px;height:24px;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                    <div>
                        <strong style="color:#15803d;"><?php esc_html_e( 'Sync Engine activo — Auto-sync desbloqueado', 'stock-sync-pro' ); ?></strong>
                        <div style="font-size:12px;color:#15803d;opacity:.8;">
                            <?php
                            $se_key = get_option( 'ssp_syncengine_key', '' );
                            if ( $se_key ) {
                                echo esc_html( substr( $se_key, 0, 8 ) . str_repeat( '•', max( 0, strlen( $se_key ) - 12 ) ) . substr( $se_key, -4 ) );
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-settings' ) ); ?>"
                       class="wv-btn wv-btn-primary wv-btn-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:14px;height:14px;"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>
                        <?php esc_html_e( 'Configurar Auto-sync', 'stock-sync-pro' ); ?>
                    </a>
                    <button type="button" id="ssp-deactivate-se-btn" class="wv-btn wv-btn-ghost wv-btn-sm" style="color:var(--wv-gray-400);">
                        <?php esc_html_e( 'Desactivar Sync Engine', 'stock-sync-pro' ); ?>
                    </button>
                    <span id="ssp-se-msg" style="font-size:12px;"></span>
                </div>

            <?php else : ?>

                <!-- Sin Sync Engine: formulario de activación -->
                <div id="ssp-se-msg" style="display:none;margin-bottom:12px;"></div>

                <div class="wv-field">
                    <label class="wv-field-label" for="ssp-se-key-input">
                        <?php esc_html_e( 'Clave de Sync Engine', 'stock-sync-pro' ); ?>
                        <div class="wv-field-desc"><?php esc_html_e( 'La recibirás por email tras contratar un plan.', 'stock-sync-pro' ); ?></div>
                    </label>
                    <input type="text" id="ssp-se-key-input" class="wv-input" style="width:100%;max-width:480px;"
                           placeholder="SE-XXXX-XXXX-XXXX" autocomplete="off">
                </div>

                <button type="button" id="ssp-activate-se-btn" class="wv-btn wv-btn-primary" style="margin-top:8px;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Activar Sync Engine', 'stock-sync-pro' ); ?>
                </button>

                <div style="margin-top:24px;padding:20px;background:linear-gradient(135deg,#eef2ff,#f5f3ff);border-radius:var(--wv-radius);">
                    <strong style="display:block;font-size:14px;color:#4338ca;margin-bottom:6px;">
                        <?php esc_html_e( '¿Aún no tienes un plan?', 'stock-sync-pro' ); ?>
                    </strong>
                    <p style="font-size:12px;color:#6366f1;margin:0 0 14px;line-height:1.6;">
                        <?php esc_html_e( 'El plugin es gratuito. Contrata el Sync Engine para automatizar la sincronización de stock sin intervención manual.', 'stock-sync-pro' ); ?>
                    </p>
                    <a href="<?php echo esc_url( SSP_SYNCENGINE_PURCHASE_URL ); ?>" target="_blank" rel="noopener"
                       class="wv-btn wv-btn-primary wv-btn-sm" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);display:inline-flex;gap:6px;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:14px;height:14px;"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3z"/></svg>
                        <?php esc_html_e( 'Ver planes del Sync Engine →', 'stock-sync-pro' ); ?>
                    </a>
                </div>

            <?php endif; ?>

        </div>
    </div>

</div>

<?php
// Mostrar API key del Sync Engine solo si acaba de activarse (transient de 24 h).
$se_setup_key = get_transient( 'ssp_syncengine_setup_key' );
if ( $autosync_active && $se_setup_key ) :
?>
<div class="wrap wevica-wrap" style="margin-top:0;">
    <div class="wv-section wv-fade-in" style="max-width:900px;margin-top:4px;border:2px solid #fbbf24;background:#fffbeb;">
        <div class="wv-section-header" style="background:#fef3c7;">
            <h2 class="wv-section-title" style="color:#92400e;">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="color:#d97706;"><path fill-rule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 2 2 0 012 2 1 1 0 102 0 4 4 0 00-4-4z" clip-rule="evenodd"/></svg>
                <?php esc_html_e( 'API Key para el Sync Engine — Guárdala ahora', 'stock-sync-pro' ); ?>
            </h2>
            <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:#fde68a;color:#92400e;">
                <?php esc_html_e( 'VISIBLE SOLO 24 H', 'stock-sync-pro' ); ?>
            </span>
        </div>
        <div class="wv-section-body">
            <p style="font-size:13px;color:#78350f;margin:0 0 14px;line-height:1.6;">
                <?php esc_html_e( 'Esta es la clave API de Stock Sync Pro que el Sync Engine usará para comunicarse con tu tienda. Ya hemos recibido los datos automáticamente para configurar tu scraper. Guárdala por si la necesitas más adelante.', 'stock-sync-pro' ); ?>
            </p>
            <div style="display:flex;align-items:center;gap:10px;">
                <code id="ssp-se-apikey-display" style="flex:1;padding:10px 14px;background:#fff;border:1px solid #fcd34d;border-radius:6px;font-size:13px;word-break:break-all;">
                    <?php echo esc_html( $se_setup_key ); ?>
                </code>
                <button type="button" id="ssp-se-copy-key" class="wv-btn wv-btn-primary wv-btn-sm" style="background:#d97706;flex-shrink:0;" onclick="navigator.clipboard.writeText('<?php echo esc_js( $se_setup_key ); ?>').then(function(){document.getElementById('ssp-se-copy-key').textContent='<?php echo esc_js( __( '¡Copiada!', 'stock-sync-pro' ) ); ?>';setTimeout(function(){document.getElementById('ssp-se-copy-key').textContent='<?php echo esc_js( __( 'Copiar', 'stock-sync-pro' ) ); ?>';},2000);});">
                    <?php esc_html_e( 'Copiar', 'stock-sync-pro' ); ?>
                </button>
            </div>
            <p style="font-size:11px;color:#92400e;margin:10px 0 0;">
                <?php esc_html_e( 'Esta clave desaparecerá de aquí en 24 horas (está guardada de forma segura en el sistema). Si necesitas regenerarla, ve a Stock Sync Pro → Claves API.', 'stock-sync-pro' ); ?>
            </p>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
(function(){
    var nonce = '<?php echo esc_js( wp_create_nonce( 'ssp_license_nonce' ) ); ?>';

    // ── Sync Engine: activar ──────────────────────────────────────────────────
    var seActivateBtn = document.getElementById('ssp-activate-se-btn');
    if (seActivateBtn) {
        seActivateBtn.addEventListener('click', function(){
            var keyInput = document.getElementById('ssp-se-key-input');
            var key = keyInput ? keyInput.value.trim() : '';
            var msg = document.getElementById('ssp-se-msg');
            if (!key) return;

            seActivateBtn.disabled = true;
            seActivateBtn.textContent = '<?php echo esc_js( __( 'Verificando...', 'stock-sync-pro' ) ); ?>';

            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=ssp_activate_syncengine&nonce=' + encodeURIComponent(nonce) + '&syncengine_key=' + encodeURIComponent(key)
            })
            .then(r => r.json())
            .then(function(res){
                msg.style.display = 'block';
                if (res.success) {
                    msg.className = 'wv-notice wv-notice-success';
                    msg.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg><div>' + res.data.message + '</div>';
                    setTimeout(function(){ location.reload(); }, 1500);
                } else {
                    msg.className = 'wv-notice wv-notice-error';
                    msg.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/></svg><div>' + res.data.message + '</div>';
                    seActivateBtn.disabled = false;
                    seActivateBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg> <?php echo esc_js( __( 'Activar Sync Engine', 'stock-sync-pro' ) ); ?>';
                }
            });
        });
    }

    // ── Sync Engine: desactivar ───────────────────────────────────────────────
    var seDeactivateBtn = document.getElementById('ssp-deactivate-se-btn');
    if (seDeactivateBtn) {
        seDeactivateBtn.addEventListener('click', function(){
            if (!confirm('<?php echo esc_js( __( '¿Desactivar el Sync Engine en este sitio?', 'stock-sync-pro' ) ); ?>')) return;
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=ssp_deactivate_syncengine&nonce=' + encodeURIComponent(nonce)
            })
            .then(r => r.json())
            .then(function(){ location.reload(); });
        });
    }
})();
</script>
