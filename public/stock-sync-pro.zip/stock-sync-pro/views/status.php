<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title"><?php esc_html_e( 'Estado del sistema', 'stock-sync-pro' ); ?></h1>
            <p class="wv-page-subtitle"><?php esc_html_e( 'Diagnóstico rápido del entorno y la configuración del plugin.', 'stock-sync-pro' ); ?></p>
        </div>
        <div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=ssp-status' ) ); ?>" class="wv-btn wv-btn-ghost wv-btn-sm">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
                <?php esc_html_e( 'Actualizar', 'stock-sync-pro' ); ?>
            </a>
        </div>
    </div>

    <div class="wv-section wv-fade-in" style="max-width:760px;">
        <div class="wv-section-header">
            <h2 class="wv-section-title">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                <?php esc_html_e( 'Comprobaciones', 'stock-sync-pro' ); ?>
            </h2>
        </div>
        <div class="wv-section-body" style="padding:0;">
            <?php foreach ( $checks as $check ) :
                $ok = $check['ok'];
            ?>
            <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--wv-gray-100);">
                <?php if ( $ok ) : ?>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:18px;height:18px;color:#16a34a;flex-shrink:0;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                <?php else : ?>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:18px;height:18px;color:#dc2626;flex-shrink:0;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/></svg>
                <?php endif; ?>
                <span style="flex:1;font-weight:500;font-size:13px;color:var(--wv-gray-800);"><?php echo esc_html( $check['label'] ); ?></span>
                <span style="font-size:12px;color:var(--wv-gray-400);font-family:monospace;"><?php echo esc_html( $check['detail'] ); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Plugin info + SE state + última sync -->
    <div class="wv-section wv-fade-in" style="max-width:760px;">
        <div class="wv-section-header">
            <h2 class="wv-section-title">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
                <?php esc_html_e( 'Información del plugin', 'stock-sync-pro' ); ?>
            </h2>
        </div>
        <div class="wv-section-body" style="padding:0;">
            <?php
            // Sync Engine state
            $se_label  = $se_active ? __( 'Activo', 'stock-sync-pro' ) : __( 'No activo', 'stock-sync-pro' );
            $se_color  = $se_active ? '#16a34a' : '#dc2626';

            // Last sync summary
            if ( $last_sync ) {
                $last_sync_label = sprintf(
                    /* translators: 1: fecha, 2: actualizados, 3: errores */
                    __( '%1$s — %2$d actualizados, %3$d errores', 'stock-sync-pro' ),
                    esc_html( $last_sync->fecha ?? '' ),
                    (int) ( $last_sync->actualizados ?? 0 ),
                    (int) ( $last_sync->errores ?? 0 )
                );
            } else {
                $last_sync_label = __( 'Sin sincronizaciones aún', 'stock-sync-pro' );
            }

            $info_rows = [
                [ __( 'Versión', 'stock-sync-pro' ),         WEVICA_SYNC_VERSION, '' ],
                [ __( 'Sync Engine', 'stock-sync-pro' ),     $se_label,           $se_color ],
                [ __( 'Última sync', 'stock-sync-pro' ),     $last_sync_label,    '' ],
                [ __( 'Zona horaria WP', 'stock-sync-pro' ), wp_timezone_string(), '' ],
            ];
            foreach ( $info_rows as [ $label, $value, $color ] ) :
            ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 16px;border-bottom:1px solid var(--wv-gray-100);">
                <span style="font-size:13px;color:var(--wv-gray-600);"><?php echo esc_html( $label ); ?></span>
                <span style="font-size:13px;font-family:monospace;<?php echo $color ? 'color:' . esc_attr( $color ) . ';font-weight:600;' : 'color:var(--wv-gray-800);'; ?>"><?php echo esc_html( $value ); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

</div>
