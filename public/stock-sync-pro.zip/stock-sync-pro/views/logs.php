<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <!-- Header -->
    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title"><?php esc_html_e( 'Historial', 'stock-sync-pro' ); ?></h1>
            <p class="wv-page-subtitle"><?php esc_html_e( 'Registro de todas las sincronizaciones', 'stock-sync-pro' ); ?></p>
        </div>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-import' ) ); ?>" class="wv-btn wv-btn-primary wv-btn-sm">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg>
            <?php esc_html_e( 'Importar CSV', 'stock-sync-pro' ); ?>
        </a>
    </div>

    <?php if ( empty( $logs ) ) : ?>
        <div class="wv-empty wv-fade-in">
            <div class="wv-empty-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/></svg>
            </div>
            <p class="wv-empty-title"><?php esc_html_e( 'Sin registros aún', 'stock-sync-pro' ); ?></p>
            <p class="wv-empty-sub"><?php esc_html_e( 'Las sincronizaciones aparecerán aquí cuando se ejecuten.', 'stock-sync-pro' ); ?></p>
        </div>
    <?php else : ?>

        <div class="wv-table-wrap wv-fade-in">
            <table class="wv-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php esc_html_e( 'Fecha', 'stock-sync-pro' ); ?></th>
                        <th><?php esc_html_e( 'Fuente', 'stock-sync-pro' ); ?></th>
                        <th><?php esc_html_e( 'Tipo', 'stock-sync-pro' ); ?></th>
                        <th><?php esc_html_e( 'Total', 'stock-sync-pro' ); ?></th>
                        <th><?php esc_html_e( 'Actualizados', 'stock-sync-pro' ); ?></th>
                        <th><?php esc_html_e( 'Sin SKU', 'stock-sync-pro' ); ?></th>
                        <th><?php esc_html_e( 'Errores', 'stock-sync-pro' ); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $logs as $log ) :
                        $badge_key = wevica_sync_badge_class( $log->tipo );
                        $badge_key = str_replace( 'wevica-badge-', 'wv-badge-', $badge_key );
                    ?>
                    <tr>
                        <td class="wv-table-id"><?php echo esc_html( $log->id ); ?></td>
                        <td class="wv-table-date"><?php echo esc_html( $log->fecha ); ?></td>
                        <td class="wv-table-store"><?php echo esc_html( $log->tienda ?: '—' ); ?></td>
                        <td>
                            <span class="wv-badge <?php echo esc_attr( $badge_key ); ?>">
                                <?php echo esc_html( strtoupper( $log->tipo ) ); ?>
                            </span>
                        </td>
                        <td class="wv-table-num"><?php echo esc_html( $log->total_productos ); ?></td>
                        <td class="wv-table-num-bold"><?php echo esc_html( $log->actualizados ); ?></td>
                        <td class="wv-table-num"><?php echo esc_html( $log->sin_sku ); ?></td>
                        <td class="<?php echo $log->errores > 0 ? 'wv-table-err' : 'wv-table-num'; ?>">
                            <?php echo esc_html( $log->errores ); ?>
                        </td>
                        <td>
                            <?php
                            $detalles_data = json_decode( $log->detalles, true );
                            if ( ! empty( $detalles_data ) ) :
                                $detail_url = admin_url( 'admin.php?page=wevica-sync-detail&id=' . absint( $log->id ) );
                            ?>
                                <a href="<?php echo esc_url( $detail_url ); ?>" class="wv-btn wv-btn-secondary wv-btn-sm">
                                    <?php esc_html_e( 'Ver detalle →', 'stock-sync-pro' ); ?>
                                </a>
                            <?php else : ?>
                                <span style="color:var(--wv-gray-300);font-size:12px;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php if ( $total_pages > 1 ) : ?>
                <div class="wv-pagination">
                    <span class="wv-pagination-info"><?php echo esc_html( $total ); ?> <?php esc_html_e( 'registros', 'stock-sync-pro' ); ?></span>
                    <div class="wv-pagination-pages">
                        <?php if ( $paged > 1 ) : ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-logs&paged=' . ( $paged - 1 ) ) ); ?>" class="wv-page-btn">←</a>
                        <?php endif; ?>

                        <?php
                        $start = max( 1, $paged - 3 );
                        $end   = min( $total_pages, $paged + 3 );
                        for ( $p = $start; $p <= $end; $p++ ) :
                        ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-logs&paged=' . $p ) ); ?>"
                               class="wv-page-btn <?php echo $p === $paged ? 'wv-page-btn-active' : ''; ?>">
                                <?php echo (int) $p; ?>
                            </a>
                        <?php endfor; ?>

                        <?php if ( $paged < $total_pages ) : ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-logs&paged=' . ( $paged + 1 ) ) ); ?>" class="wv-page-btn">→</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    <?php endif; ?>
</div>
