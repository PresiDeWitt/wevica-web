<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <!-- Header -->
    <div class="wv-page-header">
        <div class="wv-page-header-left">
            <div>
                <h1 class="wv-page-title"><?php esc_html_e( 'Stock Sync Pro', 'stock-sync-pro' ); ?></h1>
                <p class="wv-page-subtitle"><?php esc_html_e( 'Panel de control de sincronización de stock', 'stock-sync-pro' ); ?></p>
            </div>
            <span class="wv-version-badge">v<?php echo esc_html( WEVICA_SYNC_VERSION ); ?></span>
        </div>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-settings' ) ); ?>" class="wv-btn wv-btn-secondary wv-btn-sm">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>
            <?php esc_html_e( 'Ajustes', 'stock-sync-pro' ); ?>
        </a>
    </div>

    <!-- Banner de actualización disponible -->
    <?php if ( ! empty( $update_available ) && ! empty( $update_info ) ) : ?>
    <div class="wv-notice wv-notice-info wv-fade-in" style="margin-bottom:20px;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;" id="ssp-update-banner">
        <div style="display:flex;align-items:center;gap:10px;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:20px;height:20px;flex-shrink:0;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clip-rule="evenodd"/></svg>
            <div>
                <strong><?php echo esc_html( sprintf( __( 'Nueva versión disponible: v%s', 'stock-sync-pro' ), $update_info['version'] ) ); ?></strong>
                <div style="font-size:12px;opacity:.8;margin-top:2px;"><?php esc_html_e( 'Versión actual:', 'stock-sync-pro' ); ?> v<?php echo esc_html( WEVICA_SYNC_VERSION ); ?></div>
            </div>
        </div>
        <button
            id="ssp-update-btn"
            class="wv-btn wv-btn-primary wv-btn-sm"
            data-nonce="<?php echo esc_attr( $update_nonce ); ?>"
            data-version="<?php echo esc_attr( $update_info['version'] ); ?>"
        >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" style="width:14px;height:14px;"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
            <?php esc_html_e( 'Actualizar ahora', 'stock-sync-pro' ); ?>
        </button>
    </div>
    <script>
    (function(){
        var btn = document.getElementById('ssp-update-btn');
        if (!btn) return;
        btn.addEventListener('click', function(){
            btn.disabled = true;
            btn.textContent = '<?php echo esc_js( __( 'Actualizando...', 'stock-sync-pro' ) ); ?>';
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: new URLSearchParams({
                    action: 'ssp_do_update',
                    nonce:  btn.dataset.nonce
                })
            })
            .then(function(r){ return r.json(); })
            .then(function(data){
                if (data.success) {
                    document.getElementById('ssp-update-banner').innerHTML =
                        '<div style="color:#166534;font-weight:600;">&#10003; ' + data.data.message + '</div>';
                    setTimeout(function(){ location.reload(); }, 2000);
                } else {
                    btn.disabled = false;
                    btn.textContent = '<?php echo esc_js( __( 'Actualizar ahora', 'stock-sync-pro' ) ); ?>';
                    alert('Error: ' + (data.data && data.data.message ? data.data.message : 'Error desconocido'));
                }
            })
            .catch(function(){
                btn.disabled = false;
                btn.textContent = '<?php echo esc_js( __( 'Actualizar ahora', 'stock-sync-pro' ) ); ?>';
                alert('<?php echo esc_js( __( 'Error de conexión. Inténtalo de nuevo.', 'stock-sync-pro' ) ); ?>');
            });
        });
    })();
    </script>
    <?php endif; ?>

    <!-- Setup key notice -->
    <?php $setup_key = get_option( 'ssp_setup_key', '' ); ?>
    <?php if ( $setup_key ) : ?>
        <div class="wv-notice wv-notice-warning wv-fade-in" style="margin-bottom:20px;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
            <div>
                <strong><?php esc_html_e( '¡Copia tu clave API ahora! No se volverá a mostrar.', 'stock-sync-pro' ); ?></strong>
                <div class="wv-apikey-wrap" style="margin-top:8px;">
                    <span class="wv-apikey-value" id="ssp-dashboard-key-value"><?php echo esc_html( $setup_key ); ?></span>
                    <button class="wv-apikey-copy" type="button" data-target="ssp-dashboard-key-value">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/></svg>
                        <?php esc_html_e( 'Copiar', 'stock-sync-pro' ); ?>
                    </button>
                </div>
                <p style="font-size:12px;margin:6px 0 0;opacity:.8;">
                    <?php esc_html_e( 'Úsala en tu .env como:', 'stock-sync-pro' ); ?>
                    <code>PADELPOINT_WOO_API_KEY=<?php echo esc_html( $setup_key ); ?></code>
                </p>
            </div>
        </div>
        <?php delete_option( 'ssp_setup_key' ); ?>
    <?php endif; ?>

    <!-- Stat cards -->
    <div class="wv-cards wv-fade-in">
        <div class="wv-card">
            <div class="wv-card-accent wv-card-accent-indigo"></div>
            <div class="wv-card-inner">
                <div class="wv-card-icon wv-card-icon-indigo">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/></svg>
                </div>
                <div class="wv-card-label"><?php esc_html_e( 'Syncs', 'stock-sync-pro' ); ?></div>
                <div class="wv-card-value"><?php echo esc_html( $total_syncs ); ?></div>
                <div class="wv-card-meta"><?php esc_html_e( 'Total acumulado', 'stock-sync-pro' ); ?></div>
            </div>
        </div>

        <div class="wv-card">
            <div class="wv-card-accent wv-card-accent-green"></div>
            <div class="wv-card-inner">
                <div class="wv-card-icon wv-card-icon-green">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                </div>
                <div class="wv-card-label"><?php esc_html_e( 'Actualizados', 'stock-sync-pro' ); ?></div>
                <div class="wv-card-value"><?php echo esc_html( $total_updated ); ?></div>
                <div class="wv-card-meta"><?php esc_html_e( 'Productos en total', 'stock-sync-pro' ); ?></div>
            </div>
        </div>

        <div class="wv-card">
            <div class="wv-card-accent <?php echo $total_errors > 0 ? 'wv-card-accent-red' : 'wv-card-accent-green'; ?>"></div>
            <div class="wv-card-inner">
                <div class="wv-card-icon <?php echo $total_errors > 0 ? 'wv-card-icon-red' : 'wv-card-icon-green'; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                </div>
                <div class="wv-card-label"><?php esc_html_e( 'Errores', 'stock-sync-pro' ); ?></div>
                <div class="wv-card-value" style="color:<?php echo $total_errors > 0 ? 'var(--wv-error)' : 'var(--wv-success)'; ?>">
                    <?php echo esc_html( $total_errors ); ?>
                </div>
                <div class="wv-card-meta"><?php echo $total_errors > 0 ? esc_html__( 'Requieren atención', 'stock-sync-pro' ) : esc_html__( 'Todo correcto', 'stock-sync-pro' ); ?></div>
            </div>
        </div>

        <div class="wv-card">
            <div class="wv-card-accent wv-card-accent-orange"></div>
            <div class="wv-card-inner">
                <div class="wv-card-icon wv-card-icon-orange">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3z"/></svg>
                </div>
                <div class="wv-card-label"><?php esc_html_e( 'Fuentes', 'stock-sync-pro' ); ?></div>
                <div class="wv-card-value"><?php echo count( $tiendas ); ?></div>
                <div class="wv-card-meta"><?php echo $tiendas ? esc_html( implode( ', ', $tiendas ) ) : esc_html__( 'Sin datos aún', 'stock-sync-pro' ); ?></div>
            </div>
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start;">

        <!-- Última sincronización -->
        <?php if ( $last_sync ) : ?>
        <div class="wv-panel wv-fade-in">
            <div class="wv-panel-header">
                <h2 class="wv-panel-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 20 20" fill="currentColor" style="color:var(--wv-primary)"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Última sincronización', 'stock-sync-pro' ); ?>
                </h2>
                <span class="wv-badge <?php echo esc_attr( 'wv-badge-' . ( wevica_sync_badge_class( $last_sync->tipo ) === 'wevica-badge-api' ? 'api' : ( wevica_sync_badge_class( $last_sync->tipo ) === 'wevica-badge-cron' ? 'cron' : ( wevica_sync_badge_class( $last_sync->tipo ) === 'wevica-badge-err' ? 'err' : 'csv' ) ) ) ); ?>">
                    <?php echo esc_html( strtoupper( $last_sync->tipo ) ); ?>
                </span>
            </div>
            <div class="wv-info-grid">
                <div class="wv-info-grid-item">
                    <div class="wv-info-label"><?php esc_html_e( 'Fecha', 'stock-sync-pro' ); ?></div>
                    <div class="wv-info-value"><?php echo esc_html( $last_sync->fecha ); ?></div>
                </div>
                <div class="wv-info-grid-item">
                    <div class="wv-info-label"><?php esc_html_e( 'Fuente', 'stock-sync-pro' ); ?></div>
                    <div class="wv-info-value"><?php echo esc_html( $last_sync->tienda ?: '—' ); ?></div>
                </div>
                <div class="wv-info-grid-item">
                    <div class="wv-info-label"><?php esc_html_e( 'Actualizados', 'stock-sync-pro' ); ?></div>
                    <div class="wv-info-value" style="color:var(--wv-success)"><?php echo esc_html( $last_sync->actualizados ); ?> / <?php echo esc_html( $last_sync->total_productos ); ?></div>
                </div>
                <div class="wv-info-grid-item">
                    <div class="wv-info-label"><?php esc_html_e( 'Errores', 'stock-sync-pro' ); ?></div>
                    <div class="wv-info-value" style="color:<?php echo $last_sync->errores > 0 ? 'var(--wv-error)' : 'var(--wv-success)'; ?>">
                        <?php echo esc_html( $last_sync->errores ); ?>
                    </div>
                </div>
            </div>
            <div style="padding:12px 20px;border-top:1px solid var(--wv-gray-100);">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-logs' ) ); ?>" class="wv-btn wv-btn-ghost wv-btn-sm">
                    <?php esc_html_e( 'Ver historial completo →', 'stock-sync-pro' ); ?>
                </a>
            </div>
        </div>
        <?php else : ?>
        <div class="wv-panel wv-fade-in" style="background:linear-gradient(135deg,#fafafa 0%,#f5f3ff 100%);border:1px solid #e0e7ff;">
            <div class="wv-panel-header" style="border-bottom:1px solid #e0e7ff;">
                <h2 class="wv-panel-title" style="color:#4f46e5;">
                    🚀 <?php esc_html_e( 'Empieza en 3 pasos', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-panel-body" style="padding:20px;">
                <ol style="margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:14px;">
                    <li style="display:flex;align-items:flex-start;gap:12px;">
                        <span style="flex-shrink:0;width:24px;height:24px;border-radius:50%;background:#4f46e5;color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;">1</span>
                        <div>
                            <strong style="font-size:13px;color:#1f2937;"><?php esc_html_e( 'Crea tu clave API', 'stock-sync-pro' ); ?></strong>
                            <p style="margin:2px 0 0;font-size:12px;color:#6b7280;"><?php esc_html_e( 'Ve a Claves API y genera una clave para tu integración.', 'stock-sync-pro' ); ?></p>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-apikeys' ) ); ?>"
                               style="font-size:12px;color:#4f46e5;font-weight:500;"><?php esc_html_e( 'Ir a Claves API →', 'stock-sync-pro' ); ?></a>
                        </div>
                    </li>
                    <li style="display:flex;align-items:flex-start;gap:12px;">
                        <span style="flex-shrink:0;width:24px;height:24px;border-radius:50%;background:#4f46e5;color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;">2</span>
                        <div>
                            <strong style="font-size:13px;color:#1f2937;"><?php esc_html_e( 'Conecta tu fuente de datos', 'stock-sync-pro' ); ?></strong>
                            <p style="margin:2px 0 0;font-size:12px;color:#6b7280;"><?php esc_html_e( 'Sube un CSV, configura una URL de auto-sync o integra tu ERP.', 'stock-sync-pro' ); ?></p>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-import' ) ); ?>"
                               style="font-size:12px;color:#4f46e5;font-weight:500;"><?php esc_html_e( 'Importar CSV →', 'stock-sync-pro' ); ?></a>
                            &nbsp;·&nbsp;
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-settings' ) ); ?>"
                               style="font-size:12px;color:#4f46e5;font-weight:500;"><?php esc_html_e( 'Auto-sync →', 'stock-sync-pro' ); ?></a>
                        </div>
                    </li>
                    <li style="display:flex;align-items:flex-start;gap:12px;">
                        <span style="flex-shrink:0;width:24px;height:24px;border-radius:50%;background:#4f46e5;color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;">3</span>
                        <div>
                            <strong style="font-size:13px;color:#1f2937;"><?php esc_html_e( 'Haz tu primera sincronización', 'stock-sync-pro' ); ?></strong>
                            <p style="margin:2px 0 0;font-size:12px;color:#6b7280;"><?php esc_html_e( 'Envía datos a la API con tu clave y el stock se actualizará automáticamente.', 'stock-sync-pro' ); ?></p>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-help' ) ); ?>"
                               style="font-size:12px;color:#4f46e5;font-weight:500;"><?php esc_html_e( 'Ver documentación →', 'stock-sync-pro' ); ?></a>
                        </div>
                    </li>
                </ol>
            </div>
        </div>
        <?php endif; ?>

        <!-- API Key -->
        <div class="wv-panel wv-fade-in">
            <div class="wv-panel-header">
                <h2 class="wv-panel-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 20 20" fill="currentColor" style="color:var(--wv-primary)"><path fill-rule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 2 2 0 012 2 1 1 0 102 0 4 4 0 00-4-4z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'API Key', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-panel-body">
                <p style="font-size:13px;color:var(--wv-gray-500);margin:0 0 12px;">
                    <?php esc_html_e( 'Envíala en el header HTTP de cada petición:', 'stock-sync-pro' ); ?>
                    <code>X-StockSync-Key: tu-clave</code>
                </p>

                <?php if ( $setup_key ) : // $setup_key set at top of page; delete_option already called in the banner above ?>
                    <div class="wv-notice wv-notice-warning" style="margin-bottom:10px;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                        <div><strong><?php esc_html_e( '¡Copia esta clave ahora!', 'stock-sync-pro' ); ?></strong> <?php esc_html_e( 'No se volverá a mostrar.', 'stock-sync-pro' ); ?></div>
                    </div>
                    <div class="wv-apikey-wrap">
                        <span class="wv-apikey-value"><?php echo esc_html( $setup_key ); ?></span>
                        <button class="wv-apikey-copy" type="button">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/><path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/></svg>
                            <?php esc_html_e( 'Copiar', 'stock-sync-pro' ); ?>
                        </button>
                    </div>
                <?php else : ?>
                    <div class="wv-apikey-wrap">
                        <span class="wv-apikey-value" style="color:var(--wv-gray-400);letter-spacing:3px;">
                            ••••••••••••••••••••••••••••••••••••••••
                        </span>
                    </div>
                    <p style="font-size:12px;color:var(--wv-gray-400);margin:6px 0 0;">
                        <?php esc_html_e( 'Almacenada como hash seguro.', 'stock-sync-pro' ); ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wevica-sync-apikeys' ) ); ?>" style="color:var(--wv-primary);"><?php esc_html_e( 'Gestionar claves →', 'stock-sync-pro' ); ?></a>
                    </p>
                <?php endif; ?>

                <div class="wv-endpoint-pill">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                    <?php echo esc_url( rest_url( 'wevica/v1/sync' ) ); ?>
                </div>
            </div>
        </div>

    </div>
</div>
