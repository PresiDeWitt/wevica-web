<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap wevica-wrap">

    <div class="wv-page-header">
        <div>
            <h1 class="wv-page-title"><?php esc_html_e( 'Analytics', 'stock-sync-pro' ); ?></h1>
            <p class="wv-page-subtitle"><?php esc_html_e( 'Resumen de toda la actividad de sincronización', 'stock-sync-pro' ); ?></p>
        </div>
    </div>

    <!-- Stat cards -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-bottom:24px;">

        <div class="wv-section wv-fade-in" style="padding:0;">
            <div style="padding:20px 22px;">
                <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--wv-gray-400);margin-bottom:6px;"><?php esc_html_e( 'Syncs totales', 'stock-sync-pro' ); ?></div>
                <div style="font-size:28px;font-weight:700;color:var(--wv-gray-900);line-height:1;"><?php echo esc_html( number_format_i18n( $total_syncs ) ); ?></div>
            </div>
        </div>

        <div class="wv-section wv-fade-in" style="padding:0;">
            <div style="padding:20px 22px;">
                <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--wv-gray-400);margin-bottom:6px;"><?php esc_html_e( 'Productos actualizados', 'stock-sync-pro' ); ?></div>
                <div style="font-size:28px;font-weight:700;color:var(--wv-primary);line-height:1;"><?php echo esc_html( number_format_i18n( $total_updated ) ); ?></div>
            </div>
        </div>

        <div class="wv-section wv-fade-in" style="padding:0;">
            <div style="padding:20px 22px;">
                <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--wv-gray-400);margin-bottom:6px;"><?php esc_html_e( 'Media por sync', 'stock-sync-pro' ); ?></div>
                <div style="font-size:28px;font-weight:700;color:var(--wv-gray-900);line-height:1;"><?php echo esc_html( number_format_i18n( $avg_per_sync, 1 ) ); ?></div>
            </div>
        </div>

        <div class="wv-section wv-fade-in" style="padding:0;">
            <div style="padding:20px 22px;">
                <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--wv-gray-400);margin-bottom:6px;"><?php esc_html_e( 'Tasa de errores', 'stock-sync-pro' ); ?></div>
                <div style="font-size:28px;font-weight:700;color:<?php echo $error_rate > 5 ? 'var(--wv-error)' : 'var(--wv-success)'; ?>;line-height:1;"><?php echo esc_html( $error_rate ); ?>%</div>
            </div>
        </div>

    </div>

    <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;align-items:start;">

        <!-- Daily chart -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"/></svg>
                    <?php esc_html_e( 'Syncs — últimos 30 días', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body">
                <?php if ( empty( $daily_rows ) ) : ?>
                    <div class="wv-empty" style="padding:40px 0;">
                        <p class="wv-empty-title"><?php esc_html_e( 'Sin datos aún', 'stock-sync-pro' ); ?></p>
                        <p class="wv-empty-sub"><?php esc_html_e( 'Haz tu primera sincronización para ver actividad aquí.', 'stock-sync-pro' ); ?></p>
                    </div>
                <?php else : ?>
                    <canvas id="ssp-daily-chart" height="90"></canvas>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sync type breakdown -->
        <div class="wv-section wv-fade-in">
            <div class="wv-section-header">
                <h2 class="wv-section-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/></svg>
                    <?php esc_html_e( 'Por tipo', 'stock-sync-pro' ); ?>
                </h2>
            </div>
            <div class="wv-section-body" style="padding:0;">
                <?php if ( empty( $type_rows ) ) : ?>
                    <div style="padding:20px;color:var(--wv-gray-400);font-size:13px;text-align:center;"><?php esc_html_e( 'Sin datos aún', 'stock-sync-pro' ); ?></div>
                <?php else : ?>
                    <table style="width:100%;border-collapse:collapse;font-size:13px;">
                        <thead>
                            <tr style="background:var(--wv-gray-50);border-bottom:1px solid var(--wv-gray-200);">
                                <th style="padding:8px 14px;text-align:left;font-weight:600;color:var(--wv-gray-600);"><?php esc_html_e( 'Tipo', 'stock-sync-pro' ); ?></th>
                                <th style="padding:8px 14px;text-align:right;font-weight:600;color:var(--wv-gray-600);"><?php esc_html_e( 'Syncs', 'stock-sync-pro' ); ?></th>
                                <th style="padding:8px 14px;text-align:right;font-weight:600;color:var(--wv-gray-600);"><?php esc_html_e( 'Actualizados', 'stock-sync-pro' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ( $type_rows as $row ) : ?>
                            <tr style="border-bottom:1px solid var(--wv-gray-100);">
                                <td style="padding:10px 14px;">
                                    <span style="display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;background:var(--wv-gray-100);color:var(--wv-gray-600);">
                                        <?php echo esc_html( $row->tipo ); ?>
                                    </span>
                                </td>
                                <td style="padding:10px 14px;text-align:right;font-weight:600;color:var(--wv-gray-800);"><?php echo esc_html( number_format_i18n( (int) $row->syncs ) ); ?></td>
                                <td style="padding:10px 14px;text-align:right;color:var(--wv-gray-500);"><?php echo esc_html( number_format_i18n( (int) $row->updated ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

    </div>

</div>

<?php if ( ! empty( $daily_rows ) ) : ?>
<script>
(function(){
    var raw  = <?php echo wp_json_encode( $daily_rows ); ?>;
    var labels   = raw.map(function(r){ return r.day; });
    var syncs    = raw.map(function(r){ return parseInt(r.syncs, 10); });
    var updated  = raw.map(function(r){ return parseInt(r.updated, 10); });

    var ctx = document.getElementById('ssp-daily-chart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '<?php echo esc_js( __( 'Productos actualizados', 'stock-sync-pro' ) ); ?>',
                    data: updated,
                    backgroundColor: 'rgba(99,102,241,0.15)',
                    borderColor: 'rgba(99,102,241,0.8)',
                    borderWidth: 1.5,
                    borderRadius: 3,
                    order: 2,
                },
                {
                    label: '<?php echo esc_js( __( 'Syncs', 'stock-sync-pro' ) ); ?>',
                    data: syncs,
                    type: 'line',
                    borderColor: 'rgba(16,185,129,0.9)',
                    backgroundColor: 'rgba(16,185,129,0.08)',
                    borderWidth: 2,
                    pointRadius: 3,
                    tension: 0.3,
                    fill: true,
                    order: 1,
                    yAxisID: 'y2',
                }
            ]
        },
        options: {
            responsive: true,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { position: 'top', labels: { font: { size: 11 }, boxWidth: 12 } }
            },
            scales: {
                x: { grid: { display: false }, ticks: { font: { size: 10 }, maxTicksLimit: 10 } },
                y:  { beginAtZero: true, ticks: { font: { size: 10 } }, title: { display: true, text: '<?php echo esc_js( __( 'Actualizados', 'stock-sync-pro' ) ); ?>', font: { size: 10 } } },
                y2: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false }, ticks: { font: { size: 10 } }, title: { display: true, text: '<?php echo esc_js( __( 'Syncs', 'stock-sync-pro' ) ); ?>', font: { size: 10 } } }
            }
        }
    });
})();
</script>
<?php endif; ?>
