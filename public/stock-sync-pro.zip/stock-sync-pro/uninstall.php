<?php
/**
 * Wévica Stock Sync — Uninstall
 *
 * Limpia todos los datos del plugin al desinstalarlo desde WordPress.
 * Se ejecuta automáticamente cuando el admin usa "Borrar" en Plugins.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Eliminar tablas del plugin
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tablas construidas desde prefijo de WP (no hay input de usuario).
$wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}wevica_sync_log`" );
$wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}ssp_subscriptions`" );
$wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}ssp_usage`" );
$wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}ssp_scrapers`" );
$wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}ssp_metrics`" );
// phpcs:enable

// Eliminar opciones (todos los prefijos del plugin)
$options = [
    'wevica_sync_api_key',
    'wevica_sync_api_key_hash',
    'wevica_sync_stock_unknown',
    'wevica_sync_dry_run',
    'wevica_sync_update_price',
    'wevica_sync_log_retention',
    'wevica_sync_version',
    'wevica_sync_timeout_normal',
    'wevica_sync_timeout_final',
    'wevica_sync_detail_limit',
    'wevica_sync_json_max_size',
    'ssp_webhook_url',
    'ssp_webhook_secret',
    'ssp_notify_email',
    'ssp_license_key',
    'ssp_license_instance_id',
    'ssp_license_status',
    'ssp_syncengine_key',
    'ssp_syncengine_instance_id',
    'ssp_syncengine_status',
    'ssp_autosync_active',
    'ssp_activated_at',
    'ssp_cron_interval',
    'ssp_cron_source_url',
    'ssp_cron_tienda',
    'ssp_cron_source_type',
    'ssp_cron_col_sku',
    'ssp_cron_col_stock',
    'ssp_cron_col_price',
    // Registry options
    'ssp_registry_site_hash',
    'ssp_registry_woo_api_key',
    'ssp_registry_subscription_id',
    // API keys & webhook queue
    'ssp_api_keys',
    'ssp_webhook_queue',
    'ssp_notify_on_error',
    'ssp_notify_on_webhook_dead',
    'ssp_exclude_skus',
    // License & trial extras
    'ssp_setup_key',
    'ssp_license_last_known_active',
    'ssp_trial_reminder_sent',
    // Sync Engine provisioning
    'ssp_vps_provisioned',
    'ssp_syncengine_woo_key_id',
    // Lemon Squeezy config
    'ssp_lemon_squeezy_api_key',
    'ssp_lemon_squeezy_webhook_secret',
    'ssp_lemon_squeezy_plan_mapping',
    // Catalog / cron extra
    'ssp_catalog_sheets_id',
    'ssp_catalog_excel_hoja',
    'ssp_cron_col_name',
    'ssp_supplier_url',
    'ssp_github_pat',
    // Table name references
    'ssp_table_subscriptions',
    'ssp_table_usage',
    // Monitoring / alertas
    'ssp_alert_error_threshold',
    'ssp_alert_quota_threshold',
    'ssp_alert_no_sync_hours',
];

foreach ( $options as $option ) {
    delete_option( $option );
}

// Eliminar transients
$transients = [
    'wevica_sync_new_key',
    'wevica_sync_migrated_key',
    'wevica_sync_notice_wc',
    'wevica_sync_notice_migrated',
    'ssp_update_info_vercel',
    'ssp_github_release_cache',
    'ssp_engine_config',
    'ssp_syncengine_setup_key',
    'ssp_vps_provision_key',
    'ssp_last_alert_sent',
];

foreach ( $transients as $transient ) {
    delete_transient( $transient );
}

// Limpiar cron programado
wp_clear_scheduled_hook( 'wevica_sync_cleanup_logs' );
wp_clear_scheduled_hook( 'ssp_auto_sync' );
wp_clear_scheduled_hook( 'ssp_webhook_retry' );

// Limpiar transients de rate limiting
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
        '_transient_wevica_rate_%',
        '_transient_timeout_wevica_rate_%'
    )
);
