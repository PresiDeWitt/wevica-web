<?php
/**
 * Stock Sync Pro Watchdog — MU-Plugin
 *
 * Se instala en wp-content/mu-plugins/ssp-watchdog.php
 * Los MU-plugins siempre se cargan y no pueden desactivarse desde el panel.
 *
 * Qué hace:
 *  1. Detecta si Stock Sync Pro está desactivado.
 *  2. Lo reactiva automáticamente (con cooldown de 1h para no entrar en bucle).
 *  3. Notifica por email al administrador y por Telegram si está configurado.
 *
 * Instalación (una sola vez por cliente):
 *  Copia este archivo a: wp-content/mu-plugins/wevica-watchdog.php
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SSP_WATCHDOG_PLUGIN',    'wevica-stock-sync/wevica-stock-sync.php' );
define( 'SSP_WATCHDOG_COOLDOWN',  HOUR_IN_SECONDS );  // 1h entre reactivaciones
define( 'SSP_WATCHDOG_TRANSIENT', 'ssp_watchdog_last_reactivation' );
define( 'SSP_WATCHDOG_PAUSED',    'ssp_watchdog_paused' );  // opción persistente

// ── Detectar desactivación manual (usuario en el panel) ──────────────────────
// Cuando un admin desactiva el plugin intencionalmente, pausamos el watchdog
// para no volver a activarlo contra la voluntad del cliente.
add_action( 'deactivating_plugin', 'ssp_watchdog_on_deactivating' );

function ssp_watchdog_on_deactivating( string $plugin ): void {
    if ( $plugin === SSP_WATCHDOG_PLUGIN ) {
        update_option( SSP_WATCHDOG_PAUSED, '1', 'no' );
    }
}

// ── Detectar reactivación manual → reanudar watchdog ─────────────────────────
add_action( 'activated_plugin', 'ssp_watchdog_on_activated' );

function ssp_watchdog_on_activated( string $plugin ): void {
    if ( $plugin === SSP_WATCHDOG_PLUGIN ) {
        delete_option( SSP_WATCHDOG_PAUSED );
        delete_transient( SSP_WATCHDOG_TRANSIENT );
    }
}

// ── Vigilar en cada request ───────────────────────────────────────────────────
add_action( 'plugins_loaded', 'ssp_watchdog_check', 1 );

function ssp_watchdog_check(): void {
    // No intervenir en contexto WP-CLI: las desactivaciones manuales vía CLI
    // no deben consumir el cooldown ni bloquear la reactivación en HTTP.
    if ( defined( 'WP_CLI' ) && WP_CLI ) {
        return;
    }

    if ( ! function_exists( 'is_plugin_active' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    if ( is_plugin_active( SSP_WATCHDOG_PLUGIN ) ) {
        return; // Todo bien.
    }

    // Si el cliente lo desactivó manualmente, respetar esa decisión.
    if ( get_option( SSP_WATCHDOG_PAUSED ) ) {
        return;
    }

    // Cooldown para no entrar en bucle si activate() causa un fatal error.
    if ( get_transient( SSP_WATCHDOG_TRANSIENT ) ) {
        return;
    }

    // Marcar intento ANTES de activar.
    set_transient( SSP_WATCHDOG_TRANSIENT, time(), SSP_WATCHDOG_COOLDOWN );

    $resultado = activate_plugin( SSP_WATCHDOG_PLUGIN, '', false, true );

    if ( is_wp_error( $resultado ) ) {
        ssp_watchdog_notificar(
            'reactivación fallida',
            sprintf(
                "El watchdog intentó reactivar Stock Sync Pro pero falló.\n\nError: %s\n\nPosible causa: error PHP en el plugin. Revisa el log de errores de PHP.",
                $resultado->get_error_message()
            )
        );
    } else {
        ssp_watchdog_notificar(
            'reactivado automáticamente',
            "Stock Sync Pro estaba inactivo (desactivado por WordPress, no por el admin) y el watchdog lo ha reactivado.\n\nSi esto ocurre repetidamente, revisa el log de errores PHP del servidor."
        );
    }
}

/**
 * Envía notificación por email y por Telegram (si está configurado).
 */
function ssp_watchdog_notificar( string $asunto_corto, string $mensaje ): void {
    $site    = get_bloginfo( 'name' ) . ' (' . home_url() . ')';
    $hora    = gmdate( 'd/m/Y H:i' ) . ' UTC';
    $asunto  = "[Wévica Watchdog] Stock Sync Pro {$asunto_corto} — {$site}";
    $cuerpo  = "Sitio: {$site}\nFecha: {$hora}\n\n{$mensaje}";

    // ── Email ────────────────────────────────────────────────────────────────
    $email = get_option( 'ssp_notify_email', '' ) ?: get_option( 'admin_email', '' );
    if ( $email ) {
        wp_mail( $email, $asunto, $cuerpo );
    }

}
