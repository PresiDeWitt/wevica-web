=== Stock Sync Pro ===
Contributors: alejandrochaconwevica
Tags: woocommerce, stock, sync, inventory, automation, api, scraper
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 4.9.2
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Syncs WooCommerce product stock automatically from any external source (scrapers, ERPs, APIs) via a secure REST endpoint.

== Description ==

**Stock Sync Pro** keeps your WooCommerce stock up to date automatically by accepting data from any external source — scrapers, ERPs, price aggregators, or custom scripts — through a secure REST API.

No more manual CSV uploads or out-of-stock products that were actually available. Connect once, sync continuously.

= Key Features =

* **REST API** — Push stock and price updates via JSON or CSV to `/wp-json/stocksync/v1/sync`
* **Auto-sync (Cron)** — Schedule automatic fetches from any URL every 30 min, hourly, daily, or weekly
* **Multi-API keys** — Create named keys for each integration; revoke individually without disrupting others
* **Webhooks** — Get notified on sync completion or errors via HTTP POST to any endpoint (Slack, Make, Zapier...)
* **CSV Import** — Drag-and-drop CSV upload directly from the admin panel
* **Sync History** — Full log of every synchronization with product-level detail and pagination
* **Dry Run Mode** — Simulate a sync to preview changes before applying them
* **Price Updates** — Optionally update WooCommerce regular prices alongside stock
* **7-day Free Trial** — Full access to all features before subscribing (plans from $29/month)

= How It Works =

1. Install & activate — a 7-day free trial starts automatically
2. Go to **Stock Sync Pro > API Keys** and copy your first key
3. Connect your data source (scraper, ERP, spreadsheet export) to the REST endpoint
4. Stock updates are applied to WooCommerce products matched by SKU

= API Quick Start =

**Endpoint:** `POST /wp-json/stocksync/v1/sync`
**Auth header:** `X-StockSync-Key: your-api-key`

**JSON body example:**
`{"tienda":"my-store","productos":[{"sku":"ABC123","stock":"SI"},{"sku":"DEF456","stock":"NO"},{"sku":"GHI789","stock":5}]}`

= Accepted Stock Values =

* `SI` / `1` / `INSTOCK` / `IN_STOCK` → In stock
* `NO` / `0` / `OUTOFSTOCK` / `OUT_OF_STOCK` → Out of stock
* Any integer → Set exact stock quantity
* `UNKNOWN` / `DESCONOCIDO` / `ERROR_HTTP` → Configurable (skip, in-stock, or out-of-stock)

= CSV Import =

Upload a CSV file with columns for SKU, stock, and optionally price and product name. Column names are configurable.

= Batch Processing =

For large catalogs, split updates into batches using the `sync_id` and `is_last_batch` fields. All batches are accumulated and logged as a single sync entry.

== Installation ==

1. Upload the `wevica-stock-sync` folder to `/wp-content/plugins/`
2. Activate the plugin from **Plugins > Installed Plugins**
3. Go to **Stock Sync Pro > API Keys** to get your first API key
4. Configure your data source to POST to the REST endpoint

== Frequently Asked Questions ==

= Does it require WooCommerce? =

Yes. WooCommerce must be installed and active. The plugin will show a notice if WooCommerce is missing.

= How are products matched? =

By SKU. Each product (and product variation) in WooCommerce must have a unique SKU set. Products without a matching SKU are counted as `sin_sku` in the sync log.

= Can I use it with multiple stores or data sources? =

Yes. Create a separate API key for each source in **Stock Sync Pro > API Keys**. Each sync request can include a `tienda` (store) identifier which appears in the history log.

= Is the API key stored securely? =

Yes. Keys are stored as HMAC-SHA256 hashes using WordPress's own salt. The plain-text key is only shown once at creation time and never again.

= What happens when the trial expires? =

After 7 days, sync operations are blocked and an admin notice is shown. Existing data and history are preserved. Subscribe to a plan (Personal €9/mo, Business €15/mo, or Agency €29/mo) to resume — cancel anytime.

= Can I automate sync without writing a scraper? =

Yes. Use the **Cron** feature to fetch data from any URL on a schedule. The plugin auto-detects JSON or CSV format.

= Does it support product variations? =

Yes. Both simple products and product variations are matched by SKU.

= Can I be notified when a sync completes? =

Yes. Configure a **Webhook URL** in Settings > Webhooks. The plugin will POST a JSON payload to that URL after every sync (Slack incoming webhooks, Make/Zapier HTTP triggers, and custom endpoints all work).

== Screenshots ==

1. Dashboard with live statistics
2. Multi-API key management
3. Sync history with per-product detail
4. Settings — cron, webhooks, stock behavior
5. License activation page
6. Help & documentation

== Changelog ==



= 4.9.2 =
* NEW: updater robusto con ZipArchive + botón "Actualizar ahora" en dashboard
* NEW: return plan, plan_name and limits in activate/validate responses
* NEW: show active plan details on license page (plan name, API key limit, features)
* FIX: corregir límites de plan y añadir plan free en SaaS

= 4.9.1 =
* FIX: move Python script to .github/scripts to avoid YAML heredoc parse error
* FIX: use expect()->with()->andReturn() for argument-matched get_option stub
* FIX: replace withArgs() with with() in LicenseTest (Brain\Monkey API)

= 4.9.0 =
* NEW: Unified plugin + Sync Engine activation under a single license key
* NEW: Onboarding form for scraper configuration sent via email after activation
* IMPROVED: Plan structure simplified — Sync Engine now included in all paid plans
* IMPROVED: Settings page cleanup — removed redundant sections (Updates, Telegram, API Key redirect)
* FIX: License API 500 error on activation
* FIX: Codebase audit — resolved redundant logic and broken conditions
* SECURITY: Added security headers to all REST responses

= 4.8.2 =
* FIX: Google Sheets URL extraction from Drive share links
* FIX: `manage_stock` now correctly disabled when no quantity is sent
* FIX: Dry Run mode shows "Preview" label instead of "Sin SKU" in sync log
* SECURITY: bcrypt hashing for API keys (replaces HMAC-SHA256 storage)
* SECURITY: Rate limiting on license and Sync Engine endpoints (Vercel layer)
* IMPROVED: Transient cleanup on plugin deactivation

= 4.7.0 =
* NEW: Registry API — plugin auto-registers with central Vercel backend on Sync Engine activation
* NEW: Sync Engine lifecycle management (activate/deactivate from admin panel)
* NEW: Simplified settings UI — data source URL, connection test, format auto-detection
* NEW: `/stocksync/v1/config` endpoint for Sync Engine to fetch plugin configuration
* NEW: Status page simplified with real-time Sync Engine status and last sync info
* NEW: Help page rebuilt for non-technical users (4-step quick start, FAQ, formats guide)
* IMPROVED: uninstall.php cleans all registry and cron options on plugin removal
* IMPROVED: 170+ PHPUnit unit tests across 14 test classes (Pure PHP, WP Stubs, WC Mocks)
* SECURITY: SSRF prevention on source URLs, HMAC-SHA256 registry authentication

= 4.4.0 =
* NEW: Plan validation middleware — feature access control per subscription tier
* NEW: Usage tracking (products, API calls) with monthly limits enforcement
* NEW: Dashboard stats — real-time usage vs limits with percentage-based warnings
* NEW: Lemon Squeezy webhook handler (subscription_created, updated, cancelled, expired)
* NEW: Email notifications for subscription lifecycle events
* NEW: Billing settings admin page for Lemon Squeezy configuration

= 4.0.1 =
* FIX: Admin CSS not loading on API Keys, License, and Help pages (icons were oversized, code blocks had white background)
* FIX: Code blocks in Help page now display correctly with dark background
* FIX: Purchase button alignment on License page
* CHANGED: Pricing model updated to tiered monthly subscription (Starter $29, Professional $79, Enterprise $149)
* IMPROVED: All admin views fully translation-ready (i18n complete)

= 4.0.0 =
* NEW: Multi-API key support — create, name, and revoke keys individually
* NEW: Auto-sync cron — configure interval and fetch URL (JSON or CSV, auto-detected)
* NEW: Webhooks — HTTP notifications on sync_complete and sync_error events
* NEW: 7-day free trial with license activation
* NEW: Help & Documentation page
* IMPROVED: Generic, rebrandable plugin (no vendor lock-in)
* IMPROVED: Full i18n / translation-ready (text domain: stock-sync-pro)
* IMPROVED: REST API available under both `/stocksync/v1/` and `/wevica/v1/` (backward compatible)

= 3.3.1 =
* Fix: auto-update trigger (version bump)
* Fix: ZIP structure for WordPress plugin updater

= 3.3.0 =
* Premium UI redesign with design system
* Modular architecture (11 files)
* 10 bug fixes (price parsing, HTML escaping, temp file cleanup, etc.)

= 3.2.0 =
* Fix: AUTH_FAIL, rate limiting, and memory exhaustion issues

== Upgrade Notice ==

= 4.9.0 =
Unified license system — one key activates both the plugin and the Sync Engine. API keys now use bcrypt hashing; existing keys remain valid.

= 4.0.0 =
Major feature release. Multi-key, cron, webhooks, and license system. Fully backward compatible — existing API keys and REST routes continue to work.
