/* Wévica Stock Sync — Admin JS */
(function () {
    'use strict';

    /* ── Copy API key ───────────────────────────────────────────── */
    document.querySelectorAll('.wv-apikey-copy').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var text = btn.closest('.wv-apikey-wrap')
                .querySelector('.wv-apikey-value')
                .textContent.trim();

            navigator.clipboard.writeText(text).then(function () {
                var orig = btn.innerHTML;
                btn.classList.add('copied');
                btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414L8.414 15l-4.121-4.121a1 1 0 011.414-1.414L8.414 12.172l6.879-6.879a1 1 0 011.414 0z" clip-rule="evenodd"/></svg> Copiado';
                setTimeout(function () {
                    btn.classList.remove('copied');
                    btn.innerHTML = orig;
                }, 2000);
            });
        });
    });

    /* ── Dropzone ───────────────────────────────────────────────── */
    var dropzone = document.querySelector('.wv-dropzone');
    if (dropzone) {
        var fileInput = dropzone.querySelector('input[type="file"]');
        var filename  = dropzone.querySelector('.wv-dropzone-filename');

        fileInput.addEventListener('change', function () {
            if (fileInput.files.length) {
                filename.textContent = '✓ ' + fileInput.files[0].name;
                filename.style.display = 'inline-block';
            }
        });

        ['dragenter', 'dragover'].forEach(function (evt) {
            dropzone.addEventListener(evt, function (e) {
                e.preventDefault();
                dropzone.classList.add('drag-over');
            });
        });
        ['dragleave', 'drop'].forEach(function (evt) {
            dropzone.addEventListener(evt, function (e) {
                e.preventDefault();
                dropzone.classList.remove('drag-over');
                if (evt === 'drop' && e.dataTransfer.files.length) {
                    var dt = new DataTransfer();
                    dt.items.add(e.dataTransfer.files[0]);
                    fileInput.files = dt.files;
                    filename.textContent = '✓ ' + e.dataTransfer.files[0].name;
                    filename.style.display = 'inline-block';
                }
            });
        });
    }

    /* ── Detail page: filter tabs + live search ─────────────────── */
    var grid = document.getElementById('wv-grid');
    if (!grid) return;

    var cards      = Array.from(grid.querySelectorAll('.wv-product-card'));
    var tabs       = Array.from(document.querySelectorAll('.wv-tab'));
    var searchInput = document.getElementById('wv-search');
    var noResults  = grid.querySelector('.wv-no-results');
    var activeFilter = 'all';
    var searchTerm   = '';

    function applyFilters() {
        var visible = 0;
        cards.forEach(function (card) {
            var stock  = card.dataset.stock  || '';
            var sku    = card.dataset.sku    || '';
            var nombre = card.dataset.nombre || '';

            var matchesTab =
                activeFilter === 'all' ||
                (activeFilter === 'instock'    && stock === 'instock') ||
                (activeFilter === 'outofstock' && stock === 'outofstock') ||
                (activeFilter === 'error'      && (stock === 'error' || stock === 'aviso')) ||
                (activeFilter === 'sin_sku'    && stock === 'sin_sku');

            var matchesSearch =
                searchTerm === '' ||
                sku.includes(searchTerm) ||
                nombre.includes(searchTerm);

            if (matchesTab && matchesSearch) {
                card.classList.remove('wv-hidden');
                visible++;
            } else {
                card.classList.add('wv-hidden');
            }
        });

        if (noResults) {
            noResults.style.display = visible === 0 ? 'block' : 'none';
        }
    }

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            tabs.forEach(function (t) { t.classList.remove('active'); });
            tab.classList.add('active');
            activeFilter = tab.dataset.filter || 'all';
            applyFilters();
        });
    });

    if (searchInput) {
        searchInput.addEventListener('input', function () {
            searchTerm = searchInput.value.toLowerCase().trim();
            applyFilters();
        });
    }

}());
